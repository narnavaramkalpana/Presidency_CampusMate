@echo off
title Push Project to GitHub
color 0b
echo ============================================================
echo      Presidency College FAQ Chatbot - Push to GitHub
echo ============================================================
echo.
echo Make sure you have created an empty repository on GitHub first!
echo (Go to: https://github.com/new - name it e.g. college-faq-chatbot)
echo.
set /p REPO_URL="Enter your GitHub Repository URL (HTTPS): "

if "%REPO_URL%"=="" (
    echo No URL entered. Aborting.
    pause
    exit /b
)

echo.
echo Setting remote origin to: %REPO_URL%
git remote remove origin 2>nul
git remote add origin %REPO_URL%
git branch -M main

echo.
echo Pushing project to GitHub (branch: main)...
echo You may be prompted to sign in to GitHub in your browser.
echo.
git push -u origin main

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ============================================================
    echo [SUCCESS] Your project has been pushed to GitHub!
    echo ============================================================
    echo Next Step to activate GitHub Pages:
    echo 1. Go to your repo on GitHub -^> Settings -^> Pages
    echo 2. Under 'Source', select 'GitHub Actions'
    echo 3. Your site will automatically build and go live!
    echo ============================================================
) else (
    echo.
    echo [ERROR] Git push encountered an error. Please verify your URL and permissions.
)

pause
