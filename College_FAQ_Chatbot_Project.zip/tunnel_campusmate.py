import subprocess
import re
import time
import os
import sys

PORT = 3001
cloudflared_bin = r"C:\Users\ASUS\.gemini\antigravity\scratch\cloudflared.exe"

# Terminate any stray cloudflared instances first
os.system("taskkill /F /IM cloudflared.exe 2>nul")
time.sleep(1)

print(f"Starting Cloudflare Tunnel for http://127.0.0.1:{PORT}...")
proc = subprocess.Popen(
    [cloudflared_bin, "tunnel", "--url", f"http://127.0.0.1:{PORT}"],
    stderr=subprocess.PIPE,
    stdout=subprocess.PIPE,
    text=True,
    bufsize=1
)

tunnel_url = None
start = time.time()
while time.time() - start < 35:
    line = proc.stderr.readline()
    if not line:
        time.sleep(0.1)
        continue
    match = re.search(r'https:\/\/[a-zA-Z0-9\-]+\.trycloudflare\.com', line)
    if match:
        tunnel_url = match.group(0)
        print("PUBLIC_URL_CAMPUSMATE:", tunnel_url)
        sys.stdout.flush()
        with open(r"C:\Users\ASUS\.gemini\antigravity\scratch\campusmate-presidency\public_url.txt", "w") as f:
            f.write(tunnel_url)
        break

if tunnel_url:
    print(f"SUCCESS: CampusMate AI is live worldwide at: {tunnel_url}")
    sys.stdout.flush()
    while True:
        time.sleep(60)
else:
    print("Could not obtain trycloudflare URL in 35 seconds.")
