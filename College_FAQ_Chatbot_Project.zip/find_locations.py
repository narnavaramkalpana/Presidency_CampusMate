import re

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    text = f.read()

pattern = re.compile(r'\{\s*"id":\s*(\d+),\s*"question":\s*"([^"]+)"', re.DOTALL)
matches = pattern.findall(text)
print(f"Total entries found: {len(matches)}")
for eid, q in matches:
    ql = q.lower()
    if any(k in ql for k in ['location', 'where', 'cafeteria', 'canteen', 'food court', 'directions', 'reach', 'address', 'gate', 'block', 'library', 'hostel']):
        print(f"ID {eid}: {q}")
