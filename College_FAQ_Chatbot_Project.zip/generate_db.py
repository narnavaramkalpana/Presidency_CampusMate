# Python script to generate comprehensive verified university database for CampusMate AI
import json
import os

database = [
    # 1. University Overview
    {
        "question": "What is Presidency University, Bengaluru?",
        "answer": "Presidency University, Bengaluru is a premier private university established in Karnataka by the Presidency Group of Institutions under the Presidency University Act, 2013 (Karnataka Act No. 41 of 2013). It is approved by AICTE, recognized by UGC, and member of the Association of Indian Universities (AIU).",
        "category": "University overview",
        "keywords": ["presidency university", "overview", "what is", "about", "bengaluru", "karnataka", "ugc", "aicte"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Presidency University Official Portal",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is Presidency University recognized by UGC and approved by AICTE?",
        "answer": "Yes, Presidency University Bengaluru is fully recognized by the University Grants Commission (UGC) under section 2(f) of the UGC Act, 1956, and its engineering and technical programs are approved by the All India Council for Technical Education (AICTE), New Delhi.",
        "category": "University overview",
        "keywords": ["ugc recognition", "aicte approval", "accreditation", "validity", "govt recognized"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Accreditation & Approvals - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Who is the Chancellor of Presidency University?",
        "answer": "Dr. Nissar Ahmed is the Founder-Chairman of Presidency Group of Institutions and the Chancellor of Presidency University Bengaluru. He is a prominent educationist and visionary leader who has steered the institution since its inception.",
        "category": "University overview",
        "keywords": ["chancellor", "dr nissar ahmed", "founder", "chairman", "leadership"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Leadership - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the motto and vision of Presidency University?",
        "answer": "The motto is 'Gain More Knowledge, Reach Greater Heights'. The vision of Presidency University is to be an innovative, research-driven, and value-oriented university dedicated to imparting quality global education and creating socially responsible global citizens.",
        "category": "University overview",
        "keywords": ["motto", "vision", "mission", "values", "goals"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Vision & Mission - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the legacy of the Presidency Group of Institutions (PGI)?",
        "answer": "Presidency Group of Institutions was founded in 1976 and spans over 48 years of academic excellence. It encompasses multiple pre-university colleges, K-12 schools across Bangalore and Mangalore, and Presidency College (Hebbal), educating over 50,000 students.",
        "category": "University overview",
        "keywords": ["presidency group of institutions", "pgi", "legacy", "1976", "history", "sister schools"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "About PGI Legacy",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What awards and rankings has Presidency University received?",
        "answer": "Presidency University has been ranked among the top emerging engineering and management institutions in South India by prestigious surveys including Times Engineering, Education World, India Today, and Competition Success Review (CSR).",
        "category": "University overview",
        "keywords": ["rankings", "awards", "times ranking", "nirf", "accolades", "rating"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Awards & Rankings - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 2. History and Establishment
    {
        "question": "When was Presidency University established?",
        "answer": "Presidency University Bengaluru was established in 2013 under the Presidency University Act, 2013 passed by the Karnataka State Legislature (Karnataka Act No. 41 of 2013).",
        "category": "History and establishment",
        "keywords": ["establishment", "founded", "year 2013", "karnataka act 41", "legislation"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Statutory Status - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Under which Act was Presidency University constituted?",
        "answer": "Presidency University was constituted by the Karnataka Act No. 41 of 2013, notified by the Government of Karnataka in the Karnataka Gazette.",
        "category": "History and establishment",
        "keywords": ["act 41", "karnataka act", "constitution", "gazette notification", "legal status"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Governance & Act - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How did Presidency Group evolve into Presidency University?",
        "answer": "Starting with a single school in 1976, Presidency Group built premier institutions like Presidency College, Hebbal (re-accredited NAAC 'A+'). Recognizing its track record, the Government of Karnataka sanctioned the establishment of Presidency University in 2013.",
        "category": "History and establishment",
        "keywords": ["evolution", "growth", "heritage", "from school to university", "milestones"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Our Journey - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is Presidency University a private or deemed university?",
        "answer": "Presidency University is a State Private University enacted by the Karnataka Legislative Assembly under Act No. 41 of 2013, empowering it to award its own degrees recognized across India and globally.",
        "category": "History and establishment",
        "keywords": ["private university", "state university", "deemed", "degree awarding power"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Statutory Approvals - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 3. Location and Campus
    {
        "question": "Where is Presidency University campus located?",
        "answer": "The main campus is located at Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064, Karnataka, India. It is situated off the Doddaballapur Main Road, approximately 12 km from Yelahanka New Town.",
        "category": "Location and campus",
        "keywords": ["location", "address", "where is", "itgalpur", "rajanakunte", "yelahanka", "bengaluru", "pincode"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Campus Location - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How large is the Presidency University campus?",
        "answer": "Presidency University Bengaluru is set amidst a sprawling, lush green 65+ acre campus equipped with modern architectural academic blocks, advanced research laboratories, open-air amphitheaters, sports complexes, and student residential zones.",
        "category": "Location and campus",
        "keywords": ["campus size", "65 acres", "campus area", "green campus", "infrastructure"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Campus Infrastructure - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Where is the Presidency University City Admissions Office located?",
        "answer": "The City Admissions Office is located at University House, 8/1, King Street, Richmond Town, Bengaluru – 560025, Karnataka, India.",
        "category": "Location and campus",
        "keywords": ["city office", "richmond town", "king street", "urban center", "city admissions"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "City Office - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How far is Presidency University from Kempegowda International Airport (BLR)?",
        "answer": "The university campus in Rajanakunte is approximately 28 km from Kempegowda International Airport (BLR), Devanahalli, Bengaluru, and can be reached in about 35–45 minutes via the NH 44 / State Highway 9 route.",
        "category": "Location and campus",
        "keywords": ["airport distance", "kempegowda airport", "blr distance", "travel time", "flight connectivity"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Travel & Directions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How far is Presidency University from Majestic (KSR Bengaluru) Railway Station?",
        "answer": "The campus is approximately 30 km from KSR Bengaluru (Majestic) City Railway Station and Kempegowda Bus Station. Dedicated university buses and BMTC public buses ply regularly between Majestic/Hebbal and Rajanakunte.",
        "category": "Location and campus",
        "keywords": ["majestic distance", "railway station", "ksr distance", "bus connectivity"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "How to Reach - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is public transportation available to Presidency University campus?",
        "answer": "Yes, BMTC buses regularly run from Yelahanka, Majestic, and Hebbal toward Doddaballapur with stops at Rajanakunte. The university also operates a dedicated feeder shuttle between Rajanakunte bus stop / railway station and the campus entrance.",
        "category": "Location and campus",
        "keywords": ["public transport", "bmtc", "shuttle", "rajanakunte stop", "train to rajanakunte"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Public Transport Guide - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 4. Courses and Departments
    {
        "question": "What schools and faculties exist at Presidency University Bengaluru?",
        "answer": "Presidency University operates through 9 specialized schools: School of Engineering (SOE), School of Management (SOM), School of Law (SOL), School of Design (SOD), School of Computer Science & Information Science, School of Commerce (SOC), School of Media Studies, School of Allied Health Sciences, and School of Basic Sciences & Humanities.",
        "category": "Courses and departments",
        "keywords": ["schools", "faculties", "departments", "soe", "som", "sol", "sod", "all schools"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Academic Schools - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What courses are offered by the School of Engineering (SOE)?",
        "answer": "The School of Engineering offers 4-year B.Tech programs in Computer Science & Engineering (CSE), Artificial Intelligence & Machine Learning (AI & ML), Data Science, Cyber Security, Blockchain & IoT, Information Science, Electronics & Communication (ECE), Electrical & Electronics (EEE), Mechanical Engineering, Mechatronics, Petroleum Engineering, and Civil Engineering, plus M.Tech and Ph.D. programs.",
        "category": "Courses and departments",
        "keywords": ["engineering courses", "btech branches", "soe", "cse", "ece", "mechatronics", "petroleum"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "School of Engineering - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What courses are offered by the School of Management (SOM)?",
        "answer": "The School of Management offers MBA (Master of Business Administration) with diverse dual specializations, and Undergraduate BBA programs in General Management, Aviation Management, Business Analytics, Digital Marketing, and Supply Chain Management.",
        "category": "Courses and departments",
        "keywords": ["management courses", "mba", "bba", "som", "aviation", "business analytics"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "School of Management - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What courses are offered by the School of Law (SOL)?",
        "answer": "The School of Law is approved by the Bar Council of India (BCI) and offers 5-year integrated law degrees: B.A. LL.B. (Hons.), B.B.A. LL.B. (Hons.), B.Com. LL.B. (Hons.), 1-year LL.M. (Master of Laws) in Intellectual Property Rights & Corporate Law, and Ph.D. in Law.",
        "category": "Courses and departments",
        "keywords": ["law courses", "sol", "bci approved", "ba llb", "bba llb", "llm", "law honors"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "School of Law - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What programs are offered by the School of Design (SOD)?",
        "answer": "The School of Design offers 4-year Bachelor of Design (B.Des) programs in Product Design, Fashion Design, Communication Design, Game Design & Augmented Reality, and Space / Interior Design.",
        "category": "Courses and departments",
        "keywords": ["design courses", "bdes", "sod", "fashion design", "product design", "game design"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "School of Design - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What programs are offered by the School of Allied Health Sciences?",
        "answer": "The School of Allied Health Sciences offers 3 to 4-year B.Sc. programs in Medical Laboratory Technology (MLT), Anesthesia and Operation Theatre Technology, Medical Imaging Technology (Radiology), Optometry, Renal Dialysis Technology, and Cardiac Care Technology.",
        "category": "Courses and departments",
        "keywords": ["allied health", "medical technology", "paramedical", "mlt", "dialysis", "radiology", "optometry"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "School of Allied Health Sciences - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University offer BCA and MCA programs?",
        "answer": "Yes, through the School of Computer Science & Information Science, Presidency University offers a 3-year BCA (Bachelor of Computer Applications) with tracks in AI/ML, Cloud Computing, and Cyber Security, as well as a 2-year MCA (Master of Computer Applications) program.",
        "category": "Courses and departments",
        "keywords": ["bca", "mca", "computer applications", "it courses", "bca cloud", "mca admission"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Computer Applications - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 5. Undergraduate Programs
    {
        "question": "What B.Tech specializations are available in Computer Science?",
        "answer": "Under Computer Science, Presidency University offers B.Tech in: (1) Computer Science and Engineering (CSE), (2) CSE with AI & Machine Learning, (3) CSE with Data Science, (4) CSE with Cyber Security, (5) CSE with Internet of Things (IoT), and (6) Information Science and Engineering (ISE).",
        "category": "Undergraduate programs",
        "keywords": ["btech cse specializations", "cse ai ml", "cse data science", "cse cyber security", "btech cse options"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "B.Tech Computer Science - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the duration of undergraduate B.Tech programs?",
        "answer": "The B.Tech program is a 4-year, 8-semester full-time degree program. For diploma holders admitted via lateral entry directly into the second year, the duration is 3 years (6 semesters).",
        "category": "Undergraduate programs",
        "keywords": ["btech duration", "4 years", "semesters", "lateral entry duration"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "B.Tech Academic Structure - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What undergraduate business and commerce degrees are offered?",
        "answer": "Presidency University offers BBA (General, Aviation, Business Analytics, Digital Marketing), B.Com (Honours), B.Com (Banking & Finance), and B.Com (Corporate Accounting & Taxation). All these are 3-year full-time undergraduate degree courses.",
        "category": "Undergraduate programs",
        "keywords": ["ug commerce", "ug business", "bba programs", "bcom honors", "bcom banking"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Undergraduate Business Programs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the duration and structure of 5-year Integrated Law degrees?",
        "answer": "The B.A. LL.B. (Hons.), B.B.A. LL.B. (Hons.), and B.Com. LL.B. (Hons.) are 5-year integrated law programs divided into 10 semesters. They incorporate continuous moot court training, legal aid clinics, judicial internships, and law seminars approved by BCI.",
        "category": "Undergraduate programs",
        "keywords": ["5 year law", "integrated law", "ba llb duration", "bba llb", "moot court"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Integrated Law Programs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University offer B.Sc. in Forensic Science or Biotechnology?",
        "answer": "Yes, the School of Basic Sciences & Humanities offers a 3-year B.Sc. in Forensic Science and a B.Sc. in Biotechnology, featuring modern forensic laboratories, crime scene simulation setups, and biotechnology bio-safety hoods.",
        "category": "Undergraduate programs",
        "keywords": ["bsc forensic science", "bsc biotechnology", "sciences ug", "crime lab"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "B.Sc. Programs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 6. Postgraduate Programs
    {
        "question": "What specializations are available in MBA at Presidency University?",
        "answer": "The 2-year MBA program at Presidency University offers dual specializations in Marketing, Finance, Human Resource Management (HRM), Business Analytics, Operations & Supply Chain Management, Digital Marketing, and Banking & Financial Services.",
        "category": "Postgraduate programs",
        "keywords": ["mba specializations", "dual specialization", "mba marketing", "mba finance", "mba hr", "mba analytics"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "MBA Program - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What M.Tech programs are offered at Presidency University?",
        "answer": "Presidency University offers 2-year M.Tech programs in Computer Science & Engineering, Artificial Intelligence, Data Science, Embedded Systems & VLSI, and Product Design & Manufacturing.",
        "category": "Postgraduate programs",
        "keywords": ["mtech courses", "mtech cse", "mtech vlsi", "mtech ai", "postgraduate engineering"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "M.Tech Programs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the duration and focus of the LL.M. program?",
        "answer": "The LL.M. is a 1-year postgraduate master's degree in Law offered in specializations like Intellectual Property Rights (IPR) and Corporate & Commercial Laws, aimed at legal research, academic careers, and corporate legal consulting.",
        "category": "Postgraduate programs",
        "keywords": ["llm", "master of laws", "1 year llm", "ipr law", "corporate law masters"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "LL.M. Curriculum - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University offer Ph.D. programs?",
        "answer": "Yes, Presidency University offers Full-Time and Part-Time Ph.D. doctoral programs across Engineering, Management, Commerce, Law, Physics, Chemistry, Mathematics, and Humanities under UGC norms.",
        "category": "Postgraduate programs",
        "keywords": ["phd", "doctoral", "research programs", "phd engineering", "phd management", "phd law"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Research & Ph.D. - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What M.Sc. programs are offered at Presidency University?",
        "answer": "The university offers 2-year M.Sc. programs in Physics, Chemistry (Organic & Analytical), Applied Mathematics, and Biotechnology.",
        "category": "Postgraduate programs",
        "keywords": ["msc courses", "msc chemistry", "msc physics", "msc biotechnology", "msc mathematics"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Postgraduate Science Programs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 7. Admission Process
    {
        "question": "What is the overall admission process at Presidency University?",
        "answer": "The admission process involves: 1) Online registration and form submission; 2) Submitting academic scores and qualifying entrance test results; 3) Evaluation by the Admissions Committee (with Personal Interview / Design Aptitude where required); 4) Provisional Admission Offer letter generation; 5) Verification of documents and initial fee payment to secure seat.",
        "category": "Admission process",
        "keywords": ["admission process", "how to get admission", "steps for admission", "admission procedure"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Admissions Overview - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Which entrance examinations are accepted for B.Tech admission?",
        "answer": "For B.Tech, Presidency University accepts scores from: Karnataka CET (KCET), COMEDK UGET, JEE Main, or the Presidency University Evaluation Test / Merit Assessment.",
        "category": "Admission process",
        "keywords": ["btech entrance exam", "kcet", "comedk", "jee main", "accepted tests"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Engineering Admissions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Which entrance examinations are accepted for MBA admission?",
        "answer": "For MBA, Presidency University accepts Karnataka PGCET, CAT, MAT, XAT, CMAT, ATMA, or KMAT scores, followed by a personal interview / micro-presentation round.",
        "category": "Admission process",
        "keywords": ["mba entrance exam", "pgcet", "cat", "mat", "xat", "cmat", "kmat"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "MBA Admissions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Which entrance exams are accepted for School of Law admissions?",
        "answer": "School of Law accepts Common Law Admission Test (CLAT), LSAT-India, or the Presidency University Law Admission Test (PULAT), along with candidate performance in 10+2.",
        "category": "Admission process",
        "keywords": ["law entrance exam", "clat", "lsat india", "pulat", "law admission"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Law Admissions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the admission procedure for the School of Design (B.Des)?",
        "answer": "Applicants must qualify 10+2 and clear the Presidency University Design Aptitude Test (DAT) / UCEED score, followed by a Portfolio Presentation and personal interview.",
        "category": "Admission process",
        "keywords": ["bdes admission", "design entrance", "dat", "uceed", "portfolio review"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Design Admissions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Can I apply for direct admission through Management Quota?",
        "answer": "Yes, Presidency University offers direct admissions through the Institutional / Management Quota for eligible students meeting university academic cut-offs. Candidates can apply online or visit the campus admission desk.",
        "category": "Admission process",
        "keywords": ["management quota", "direct admission", "institutional quota", "seat booking"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Direct Admissions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is lateral entry available for B.Tech programs?",
        "answer": "Yes, diploma holders in engineering or B.Sc. graduates with Mathematics with at least 45% aggregate (40% for SC/ST/OBC Karnataka) can apply for Lateral Entry directly into the 2nd year (3rd semester) of B.Tech.",
        "category": "Admission process",
        "keywords": ["lateral entry", "btech lateral entry", "diploma to btech", "3rd semester admission"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Lateral Entry Admissions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 8. Eligibility Requirements
    {
        "question": "What is the eligibility criteria for B.Tech Computer Science and Engineering (CSE)?",
        "answer": "Candidates must have passed 10+2 (PUC / CBSE / ISC or equivalent) with at least 45% aggregate marks (40% for Karnataka SC/ST/OBC) in Physics and Mathematics as compulsory subjects, along with Chemistry, Biotechnology, Biology, Computer Science, or Electronics.",
        "category": "Eligibility requirements",
        "keywords": ["eligibility btech cse", "percentage required for cse", "12th marks for engineering", "puc cut off"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "B.Tech Eligibility - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the eligibility criteria for MBA at Presidency University?",
        "answer": "Candidates must hold a Bachelor's Degree of minimum 3-year duration from a recognized university with an aggregate of at least 50% marks (45% for Karnataka SC/ST/OBC candidates) and a valid entrance score (PGCET/CAT/MAT/KMAT/CMAT).",
        "category": "Eligibility requirements",
        "keywords": ["mba eligibility", "graduation marks for mba", "mba cutoff", "bachelor degree percentage"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "MBA Eligibility - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the eligibility for 5-Year Integrated Law (BA LLB / BBA LLB / B.Com LLB)?",
        "answer": "Candidates must have passed 10+2 / PUC or equivalent examination from a recognized board with a minimum of 45% aggregate marks (40% for SC/ST candidates). The maximum age limit conforms to Bar Council of India regulations.",
        "category": "Eligibility requirements",
        "keywords": ["law eligibility", "ba llb marks", "bci age limit", "12th marks for law"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Law Eligibility - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the eligibility criteria for BBA and B.Com programs?",
        "answer": "Candidates must have passed 10+2 / Karnataka PUC / CBSE / ISC or equivalent examination in any stream (Commerce, Science, or Arts) from a recognized board with a minimum aggregate of 45% to 50%.",
        "category": "Eligibility requirements",
        "keywords": ["bba eligibility", "bcom eligibility", "12th commerce percentage", "puc commerce criteria"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "BBA & B.Com Eligibility - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the eligibility criteria for BCA (Bachelor of Computer Applications)?",
        "answer": "Candidates must have passed 10+2 / PUC or equivalent examination with a minimum of 45% aggregate marks with Mathematics, Computer Science, Statistics, or Business Mathematics as one of the preferred subjects.",
        "category": "Eligibility requirements",
        "keywords": ["bca eligibility", "bca math required", "bca 12th percentage", "computer applications eligibility"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "BCA Eligibility - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the eligibility criteria for Allied Health Sciences (B.Sc. MLT, Imaging, etc.)?",
        "answer": "Candidates must have completed 10+2 / PUC with Physics, Chemistry, and Biology (PCB) as mandatory subjects with a minimum of 45% to 50% aggregate marks from a recognized board.",
        "category": "Eligibility requirements",
        "keywords": ["allied health eligibility", "bsc mlt criteria", "pcb required", "paramedical eligibility"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Allied Health Sciences Eligibility - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 9. Application Procedure
    {
        "question": "How can I apply online for Presidency University admissions?",
        "answer": "You can apply online via the official university website: 1) Visit https://presidencyuniversity.in/ and click on 'Apply Now'; 2) Register with your active email address and mobile number; 3) Fill in personal and educational details; 4) Upload required scanned documents; 5) Pay the application registration fee online.",
        "category": "Application procedure",
        "keywords": ["how to apply", "online application", "apply now", "registration step", "admission portal"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Online Application Portal - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the application fee for Presidency University programs?",
        "answer": "The application fee is typically ₹1,000 to ₹1,250 (non-refundable), payable online using Credit Card, Debit Card, Net Banking, or UPI through the secure payment gateway on the portal.",
        "category": "Application procedure",
        "keywords": ["application fee", "form cost", "how much is application", "fee payment mode"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Fee & Payments - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Can I visit the campus in person to submit my application?",
        "answer": "Yes, applicants and parents can visit the Admissions Office directly at the Rajanakunte campus or the City Admissions Office at Richmond Town, Bengaluru, to purchase the prospectus, submit physical forms, and receive personalized counseling.",
        "category": "Application procedure",
        "keywords": ["walk in admission", "offline application", "visit campus for form", "counseling desk"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Admissions Desk - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Can I track my application status online?",
        "answer": "Yes, once registered, applicants receive a unique Application ID and password. By logging into the Presidency University applicant dashboard, you can track form submission, payment receipt, interview scheduling, and offer status.",
        "category": "Application procedure",
        "keywords": ["track application", "application status", "applicant portal login", "admission tracking"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Applicant Login - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 10. Admission Deadlines
    {
        "question": "When do admissions open and close for the academic year 2026–2027?",
        "answer": "Admissions generally open in November/December for early rounds and continue through July/August depending on state entrance results (KCET/PGCET). It is strongly advised to apply early as high-demand branches like B.Tech CSE fill up fast.",
        "category": "Admission deadlines",
        "keywords": ["admission dates", "application deadline", "last date to apply", "2026 admissions", "closing date"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Important Dates - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the reporting date for newly admitted first-year students?",
        "answer": "Orientation programs and commencement of classes for first-year undergraduate and postgraduate cohorts typically begin in August/September, as notified in the official academic calendar.",
        "category": "Admission deadlines",
        "keywords": ["orientation date", "class start date", "reporting date", "academic calendar"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Academic Calendar - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Are admissions open on rolling rounds?",
        "answer": "Yes, early admissions proceed in phased cycles (Phase 1, Phase 2, and Phase 3). Early phase applicants often have access to higher merit scholarship allocations and branch priority.",
        "category": "Admission deadlines",
        "keywords": ["admission phases", "rolling admissions", "early bird rounds", "seat availability"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Admissions Cycles - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 11. Fee Structure
    {
        "question": "What is the approximate fee structure for B.Tech programs?",
        "answer": "For direct admissions / Management Quota, B.Tech tuition fees generally range from ₹2,50,000 to ₹3,50,000 per year (total approx ₹10 to ₹14 Lakhs over 4 years, higher for CSE/AI specializations). For students admitted through KCET government quota, fees are subsidized at approximately ₹1,00,000 to ₹1,15,000 per year as per Karnataka government norms.",
        "category": "Fee structure",
        "keywords": ["btech fees", "engineering fees", "cost of btech", "kcet fee vs management fee", "annual tuition"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "B.Tech Fee Details - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the total fee for the 2-Year MBA program?",
        "answer": "The total fee for the 2-year full-time MBA program generally ranges between ₹6,00,000 and ₹9,00,000 for the full course under the management quota, payable in semester or annual installments. For PGCET government-allotted seats, fees are subsidized.",
        "category": "Fee structure",
        "keywords": ["mba fees", "mba cost", "pgcet mba fee", "management mba package"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "MBA Fee Structure - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the fee structure for BBA, BCA, and B.Com programs?",
        "answer": "For BBA and BCA, tuition fees range from ₹1,30,000 to ₹2,00,000 per year depending on specialization. B.Com (Hons.) ranges around ₹1,10,000 to ₹1,50,000 per year.",
        "category": "Fee structure",
        "keywords": ["bba fees", "bca fees", "bcom fees", "ug commerce fees", "annual tuition fee"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "UG Programs Fee - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the fee structure for the School of Law (BA LLB / BBA LLB)?",
        "answer": "The annual tuition fee for 5-year integrated law programs (B.A. LL.B., B.B.A. LL.B., B.Com. LL.B. Hons.) is approximately ₹1,50,000 to ₹2,25,000 per year.",
        "category": "Fee structure",
        "keywords": ["law fees", "ba llb fees", "bba llb fee", "5 year law cost"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Law Fee Structure - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What payment modes are accepted for university fees?",
        "answer": "Tuition fees can be paid via the Presidency University ERP online student portal using Net Banking, NEFT/RTGS, Credit/Debit cards, UPI, or through Demand Draft (DD) drawn in favor of 'Presidency University' payable at Bengaluru.",
        "category": "Fee structure",
        "keywords": ["fee payment mode", "neft", "rtgs", "demand draft", "online fee pay"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Payment Guidelines - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University offer education loan assistance?",
        "answer": "Yes, Presidency University has tie-ups with leading nationalized and private banks (including SBI, Canara Bank, HDFC Bank, ICICI Bank, Axis Bank, and Credila). The admissions desk provides bonafide fee estimates and documentation required to expedite loan processing.",
        "category": "Fee structure",
        "keywords": ["education loan", "bank tie up", "sbi loan", "loan assistance", "bonafide certificate"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Education Loan Support - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 12. Scholarships
    {
        "question": "What scholarships are available at Presidency University?",
        "answer": "Presidency University offers: 1) Merit-based Scholarships (up to 100% Presidential Scholarship); 2) High-scorer waivers based on 10+2 / board exam percentages (90%+ and 80-89.9%); 3) Entrance exam rank-based waivers (JEE Main, KCET, CLAT, CAT, MAT); 4) Sports and Cultural Excellence Scholarships; 5) Sibling / Alumni fee concessions; 6) Financial aid for defense wards and single parents.",
        "category": "Scholarships",
        "keywords": ["scholarships", "fee concession", "waiver", "presidential scholarship", "types of scholarship"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Scholarships - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the Presidential Scholarship?",
        "answer": "The Presidential Scholarship is the highest merit award offered by the university, providing up to a 100% tuition fee waiver to exceptional toppers in national entrance exams or state board toppers.",
        "category": "Scholarships",
        "keywords": ["presidential scholarship", "100 percent waiver", "free seat", "top merit award"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Presidential Scholarship Scheme",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the fee waiver for students with 90% or above in 12th/PUC?",
        "answer": "Under the merit concession policy, candidates securing 90% and above aggregate marks in 10+2 / PUC receive a special tuition concession (typically ₹50,000 or equivalent percentage waiver on tuition fees in the first year).",
        "category": "Scholarships",
        "keywords": ["90 percent scholarship", "board topper waiver", "merit cut off", "50000 waiver"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Merit Scholarship Slabs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the fee concession for students scoring between 80% and 89.99% in 12th?",
        "answer": "Candidates securing between 80% and 89.99% in qualifying board examinations are eligible for standard merit fee concessions (typically ₹30,000 or corresponding percentage deduction on first-year tuition fee).",
        "category": "Scholarships",
        "keywords": ["80 percent scholarship", "merit deduction", "30000 waiver"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Merit Waiver Policy - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University offer sports scholarships?",
        "answer": "Yes, state, national, and international level sports medalists and participants in disciplines like Cricket, Football, Basketball, Athletics, and Badminton are granted sports scholarships ranging from 25% to 75% tuition fee waiver upon trials and certificate scrutiny.",
        "category": "Scholarships",
        "keywords": ["sports scholarship", "national player", "athlete waiver", "sports quota"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Sports Scholarships - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is there a concession for alumni or siblings of current students?",
        "answer": "Yes, Presidency University provides a 10% to 20% sibling discount and alumni continuation concession for students whose siblings are enrolled or who completed their schooling/PUC at Presidency Group of Institutions.",
        "category": "Scholarships",
        "keywords": ["sibling discount", "alumni concession", "presidency school alumni", "pgi concession"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Institutional Concessions - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How can I apply for a scholarship at Presidency University?",
        "answer": "You can apply for scholarships directly within the online admission application form by uploading certified copies of your qualifying marksheets, entrance rank cards, or sports/cultural certificates. The Scholarship Committee reviews and notifies eligible candidates during admission.",
        "category": "Scholarships",
        "keywords": ["how to apply for scholarship", "scholarship form", "upload documents for waiver"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Scholarship Guidelines - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 13. Required Documents
    {
        "question": "What documents are required for undergraduate (B.Tech / BBA / Law) admission?",
        "answer": "Required documents include: 1) Class 10th / SSLC Marks Card; 2) Class 12th / PUC / Equivalent Marks Card; 3) Transfer Certificate (TC); 4) Migration Certificate (for non-Karnataka / non-state board students); 5) Conduct / Character Certificate; 6) Entrance Exam Rank Card (KCET/COMEDK/JEE/CLAT); 7) Caste/Income Certificate (if claiming reservation); 8) Aadhar Card copy; 9) Passport-size recent photographs (6-8 copies).",
        "category": "Required documents",
        "keywords": ["documents required", "checklist", "certificates for admission", "tc", "migration", "marks card"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Documents Checklist - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What additional documents are required for MBA / M.Tech admissions?",
        "answer": "For postgraduate admissions, along with 10th and 12th certificates, you need: 1) Degree Marks Cards of all semesters; 2) Degree Certificate or Provisional Degree Certificate (PDC); 3) Entrance exam scorecard (PGCET/CAT/MAT/KMAT); 4) Work Experience certificates (if applicable).",
        "category": "Required documents",
        "keywords": ["pg documents", "mba documents checklist", "degree certificate", "pdc", "semester marks cards"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "PG Admission Checklist - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Do I need to submit original certificates during admission?",
        "answer": "Yes, during final seat confirmation and verification, original certificates must be produced for verification by the Registrar's office. The university issues an acknowledgment receipt and returns originals after verification according to regulatory timelines.",
        "category": "Required documents",
        "keywords": ["original certificates", "verification process", "acknowledgment receipt", "certificate submission"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Document Verification Policy - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 14. Hostel Facilities
    {
        "question": "Are hostel accommodations available at Presidency University?",
        "answer": "Yes, Presidency University provides separate, well-appointed hostels for boys and girls. Accommodations are available in twin-sharing and triple-sharing room layouts, with choices of air-conditioned (AC) and non-AC rooms.",
        "category": "Hostel facilities",
        "keywords": ["hostel", "accommodation", "dorm", "boys hostel", "girls hostel", "twin sharing", "triple sharing"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Student Housing & Hostels - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the fee for Presidency University hostels?",
        "answer": "Hostel fees typically range from ₹1,40,000 to ₹1,75,000 per academic year depending on the room category (triple sharing vs twin sharing, standard vs AC), plus a one-time refundable security caution deposit of approximately ₹10,000.",
        "category": "Hostel facilities",
        "keywords": ["hostel fee", "mess fee", "hostel rent", "annual hostel charges", "security deposit"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Hostel Fee Structure - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What amenities are provided in the hostels?",
        "answer": "Hostel amenities include: comfortable beds with mattresses, study tables, chairs, modular wardrobes, high-speed Wi-Fi, 24/7 power backup with generators, solar water heaters, laundry facilities, TV common rooms, recreation indoor games, and daily housekeeping.",
        "category": "Hostel facilities",
        "keywords": ["hostel amenities", "wifi", "laundry", "hot water", "common room", "housekeeping"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Hostel Amenities - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the dining / mess facility like in the hostels?",
        "answer": "The dining halls serve hygienic, nutritious multi-cuisine meals including North Indian and South Indian vegetarian and non-vegetarian selections. The menu is planned in consultation with the student mess committee.",
        "category": "Hostel facilities",
        "keywords": ["hostel mess", "food quality", "vegetarian food", "non veg", "dining hall", "menu"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Hostel Dining - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What safety and security measures exist in the hostels?",
        "answer": "Safety measures include 24/7 security personnel, biometric entry/exit access, full CCTV surveillance covering all perimeters, resident wardens on every floor, anti-ragging squads, and strict visitor verification logs.",
        "category": "Hostel facilities",
        "keywords": ["hostel safety", "biometric", "cctv", "security", "wardens", "curfew"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Hostel Safety - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What are the hostel curfew hours and outing rules?",
        "answer": "For student safety, evening entry cutoff is strictly observed (usually 7:30 PM for hostel gates). Weekend outings and night-outs require parent consent submitted via the official hostel ERP / warden approval app.",
        "category": "Hostel facilities",
        "keywords": ["curfew timing", "outing rules", "night out permission", "hostel rules"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Hostel Rules & Regulations - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is weekend transport provided for hostellers to visit the city?",
        "answer": "Yes, the university provides scheduled weekend shuttle buses connecting hostel students to nearby shopping centers, supermarkets, and metro connections in Yelahanka New Town.",
        "category": "Hostel facilities",
        "keywords": ["weekend shuttle", "shopping bus", "yelahanka transport", "weekend outing"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Hostel Services - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 15. Transportation
    {
        "question": "Does Presidency University provide bus transportation?",
        "answer": "Yes, Presidency University manages a fleet of over 50 luxury buses operating on dedicated routes connecting almost all parts of Bengaluru city and surrounding suburban belts to the Rajanakunte campus.",
        "category": "Transportation",
        "keywords": ["transportation", "bus facility", "college bus", "fleet", "50 buses"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "University Transport - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Which areas of Bengaluru are covered by university buses?",
        "answer": "Major routes cover: Majestic, Hebbal, Yelahanka, Yeshwanthpur, Rajajinagar, Vijayanagar, Banashankari, Jayanagar, BTM Layout, Koramangala, Indiranagar, Whitefield, KR Puram, Electronic City, Nagarbhavi, and Kengeri.",
        "category": "Transportation",
        "keywords": ["bus routes", "hebbal route", "majestic route", "whitefield bus", "areas covered"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Bus Routes - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What safety features are equipped on university buses?",
        "answer": "All university buses are equipped with GPS live tracking, speed governors, CCTV cameras, first-aid kits, fire extinguishers, and emergency contact numbers, operated by vetted, experienced drivers.",
        "category": "Transportation",
        "keywords": ["bus safety", "gps tracking", "speed governor", "safe transport"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Transport Safety Guidelines - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the annual transportation fee?",
        "answer": "Transport fees vary depending on pick-up distance and zone, typically ranging from ₹30,000 to ₹45,000 per academic year, inclusive of return trips on all working days.",
        "category": "Transportation",
        "keywords": ["transport fee", "bus pass cost", "annual bus charges", "bus fare"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Transport Fee Matrix - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is there a shuttle service between Rajanakunte station and the campus?",
        "answer": "Yes, a complimentary feeder shuttle operates frequently during peak morning and evening hours between Rajanakunte bus stop / railway station and the university main gate for students using public transit.",
        "category": "Transportation",
        "keywords": ["shuttle service", "feeder bus", "rajanakunte shuttle", "station pickup"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Campus Shuttle - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 16. Library
    {
        "question": "What library facilities are available at Presidency University?",
        "answer": "The university features a multi-branch library system: the Central Main Library (housing Engineering, Computer Science, and Sciences), the Management Library Annexe, and a dedicated Law Library in the E-Block. Total holdings exceed 40,500+ volumes.",
        "category": "Library",
        "keywords": ["library", "books", "central library", "law library", "volumes", "reading room"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Library Services - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What digital databases and e-resources are subscribed by the library?",
        "answer": "The library subscribes to premier e-resource packages including IEEE Xplore, ScienceDirect, SpringerLink, ProQuest, EBSCO, Manupatra, SCC Online, HeinOnline, LexisNexis, and Knimbus remote access platform.",
        "category": "Library",
        "keywords": ["digital library", "ieee xplore", "scopus", "manupatra", "scc online", "knimbus", "e journals"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Digital E-Resources - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is the library automated?",
        "answer": "Yes, the library is fully automated using KOHA Integrated Library Management Software with Web OPAC for remote catalog searches, RFID book detection gates, and self-check-in/check-out kiosks.",
        "category": "Library",
        "keywords": ["koha", "web opac", "rfid", "library automation", "self checkout"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Library Automation - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What are the library timings?",
        "answer": "The Central Library is open from 8:30 AM to 8:00 PM on all working days, with extended reading hours until 10:00 PM during mid-term and end-semester examinations.",
        "category": "Library",
        "keywords": ["library timings", "opening hours", "exam reading hours", "closing time"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Library Timings - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 17. Laboratories
    {
        "question": "What computing and AI laboratories are on campus?",
        "answer": "Presidency University houses state-of-the-art computer labs with over 2,000+ high-end workstations, dedicated NVIDIA GPU AI clusters for deep learning, an Apple Mac Lab for iOS development, and specialized Cloud & IoT setups.",
        "category": "Laboratories",
        "keywords": ["computer labs", "ai lab", "gpu cluster", "apple mac lab", "nvidia", "workstations"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Computing Facilities - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What specialized engineering workshops exist at the university?",
        "answer": "Specialized labs include: Robotics & Automation Lab, Mechatronics Lab, Advanced Materials & Metallography Lab, Fluid Mechanics & IC Engines Lab, VLSI & Embedded Systems Design Lab, and Concrete Technology Lab.",
        "category": "Laboratories",
        "keywords": ["engineering labs", "robotics lab", "vlsi lab", "mechatronics lab", "workshops"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Engineering Laboratories - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does the School of Law have a Moot Court Hall?",
        "answer": "Yes, the School of Law features a full-fledged, air-conditioned replica Moot Court Hall with judge's podium, witness stand, counsel bar, and acoustic recording equipment for regular trial simulations and mooting competitions.",
        "category": "Laboratories",
        "keywords": ["moot court", "law court hall", "trial advocacy", "mock court"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Moot Court Facilities - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What laboratories are available for Allied Health and Sciences?",
        "answer": "Facilities include modern Clinical Biochemistry Labs, Microbiology & Pathology Labs, Hematology Lab, Simulation ICU/Operation Theatre setup, Optics & Refraction Lab, and Forensic Crime Scene Simulation rooms.",
        "category": "Laboratories",
        "keywords": ["health labs", "biochemistry lab", "pathology lab", "simulation ot", "forensic lab"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Allied Health Labs - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 18. Sports Facilities
    {
        "question": "What sports facilities are available on campus?",
        "answer": "The campus offers extensive sports infrastructure: a full-sized cricket ground with practice turf nets, standard football turf, floodlit basketball courts, volleyball and throwball courts, badminton courts, tennis courts, and athletics tracks.",
        "category": "Sports facilities",
        "keywords": ["sports facilities", "cricket ground", "football turf", "basketball court", "athletics", "badminton"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Sports & Fitness - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is there a gymnasium on campus?",
        "answer": "Yes, Presidency University features separate, fully equipped modern gymnasiums for boys and girls with cardiovascular machines, strength trainers, free weights, and certified fitness trainers.",
        "category": "Sports facilities",
        "keywords": ["gym", "gymnasium", "fitness center", "workout", "weights"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Gymnasium & Fitness - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What indoor games are available?",
        "answer": "The Student Activity Centre houses table tennis courts, chess and carrom lounges, and a dedicated Yoga and Meditation studio conducting regular wellness sessions.",
        "category": "Sports facilities",
        "keywords": ["indoor games", "table tennis", "chess", "carrom", "yoga studio"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Indoor Sports - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the annual university sports meet called?",
        "answer": "The annual sports meet is known as 'Kreedotsava' (Presidency Olympic Week), featuring inter-departmental and inter-university tournaments in cricket, football, basketball, and track & field athletics.",
        "category": "Sports facilities",
        "keywords": ["kreedotsava", "sports meet", "annual sports fest", "tournaments"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Sports Tournaments - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 19. Student Clubs
    {
        "question": "What student clubs exist at Presidency University?",
        "answer": "Student clubs operate under the Department of Student Affairs (DSA) spanning: 1) Technical Clubs (Coding Club, ACM Chapter, IEEE, Robotics, AI Club); 2) Cultural Clubs (Music, Dance, Theatre, Photography); 3) Literary & Debating (MUN, Quiz, Debate); 4) Social Action (Rotaract Club, NSS, NCC, Red Cross); 5) Sports & Fitness Associations.",
        "category": "Student clubs",
        "keywords": ["clubs", "student clubs", "dsa", "acm", "ieee", "rotaract", "dance club", "coding club"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Student Clubs & Chapters - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University have an active NCC unit?",
        "answer": "Yes, Presidency University has an active National Cadet Corps (NCC) Army Wing detachment providing military training, weapon training, drills, and participation in Republic Day (RDC) parades.",
        "category": "Student clubs",
        "keywords": ["ncc", "national cadet corps", "army wing", "rdc camp", "military drill"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "NCC Detachment - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What community service initiatives does NSS undertake?",
        "answer": "The National Service Scheme (NSS) unit organizes regular blood donation camps, rural health camps in adopted villages around Rajanakunte, tree plantation drives, and digital literacy workshops for local schools.",
        "category": "Student clubs",
        "keywords": ["nss", "community service", "blood donation", "adopted villages", "social work"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "NSS Activities - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the Rotaract Club of Presidency University?",
        "answer": "Chartered under Rotary International District 3192, the Rotaract Club of Presidency University organizes youth leadership conclaves, environmental awareness runs, orphan support initiatives, and inter-collegiate humanitarian drives.",
        "category": "Student clubs",
        "keywords": ["rotaract", "rotaract club", "rotary", "youth leadership", "charity"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Rotaract Presidency - Student Affairs",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How can a student join or start a club?",
        "answer": "During the annual 'Club Carnival' held in the first month of the academic year, students can register for any club. Students wishing to form a new club can submit a charter and faculty mentor endorsement to the Directorate of Student Affairs (DSA).",
        "category": "Student clubs",
        "keywords": ["how to join club", "club carnival", "start a club", "dsa registration"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Club Membership - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 20. Campus Events
    {
        "question": "What is Invincia at Presidency University?",
        "answer": "'Invincia' is Presidency University's flagship annual inter-collegiate national cultural festival. It is one of Bengaluru's biggest youth festivals, drawing over 15,000+ students for multi-stage music concerts, fashion pro-nites, dance competitions, and celebrity headliner performances.",
        "category": "Campus events",
        "keywords": ["invincia", "annual fest", "cultural festival", "pro nite", "celebrity concert", "college fest"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Invincia Cultural Festival - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What technical fests and hackathons are hosted?",
        "answer": "The university hosts the annual National TechFest and 'Presidency Hackathon' (a 24-36 hour national coding and hardware hackathon), featuring challenges in AI, Smart Mobility, FinTech, and Green Tech with corporate sponsorships and cash prizes.",
        "category": "Campus events",
        "keywords": ["hackathon", "tech fest", "presidency hackathon", "coding competition", "prize money"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Technical Fests - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the National Moot Court Competition hosted by School of Law?",
        "answer": "The School of Law hosts an annual National Moot Court Competition that invites law teams from across India to argue complex constitutional, international, and commercial law problems judged by High Court judges and Senior Advocates.",
        "category": "Campus events",
        "keywords": ["national moot court", "law competition", "mooting", "legal event"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "National Moot Court - School of Law",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University organize Model United Nations (MUN)?",
        "answer": "Yes, Presidency University Model United Nations (PUMUN) is an annual diplomatic simulation where student delegates represent diverse nations to debate global policy, conflict resolution, and UN sustainable development goals.",
        "category": "Campus events",
        "keywords": ["pumun", "model united nations", "debating conclave", "diplomacy"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "PUMUN - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 21. Placement Information
    {
        "question": "How are the placements at Presidency University Bengaluru?",
        "answer": "Presidency University reports a consistent placement track record facilitated by its dedicated Career Resource Centre (CRC). Over 500+ top tier recruiters visit annually, offering career opportunities across software, core engineering, consulting, banking, and management domains.",
        "category": "Placement information",
        "keywords": ["placements", "placement record", "crc", "campus recruitment", "job opportunities"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Placements - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the highest package offered at Presidency University?",
        "answer": "Recent placement cycles have witnessed highest salary packages scaling between ₹13.58 LPA and ₹16+ LPA, with leading offers coming from international tech, product engineering, and global consulting corporations.",
        "category": "Placement information",
        "keywords": ["highest package", "highest salary", "top ctc", "13.58 lpa", "16 lpa"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Placement Statistics - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the average package for B.Tech and MBA graduates?",
        "answer": "The overall average CTC for B.Tech engineering graduates ranges between ₹5.50 LPA and ₹6.00 LPA. For MBA graduates, the average package ranges around ₹5.00 LPA to ₹6.50 LPA.",
        "category": "Placement information",
        "keywords": ["average package", "average salary", "average ctc", "btech average", "mba average"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Salary Trends - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Who are the top recruiters visiting Presidency University?",
        "answer": "Prominent recruiting partners include: Microsoft, Amazon, Infosys, Wipro, TCS, Capgemini, Cognizant, Tech Mahindra, Dell Technologies, EY, KPMG, Berger Paints, ICICI Bank, Deloitte, Mindtree, Oracle, HP, and Bosch.",
        "category": "Placement information",
        "keywords": ["top recruiters", "companies visiting", "infosys", "tcs", "microsoft", "amazon", "capgemini"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Recruiting Partners - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the placement percentage of eligible students?",
        "answer": "The university consistently registers a placement rate exceeding 90% for all eligible registered students who meet company cut-off criteria without backlogs.",
        "category": "Placement information",
        "keywords": ["placement percentage", "placement rate", "success rate", "90 percent placement"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Placement Report - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 22. Career Services
    {
        "question": "What is the Career Resource Centre (CRC)?",
        "answer": "The Career Resource Centre (CRC) is the specialized university wing responsible for training, corporate relations, industry partnerships, internships, and on-campus placement drives.",
        "category": "Career services",
        "keywords": ["crc", "career resource centre", "placement cell", "corporate connect", "training wing"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Career Resource Centre - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What pre-placement training is provided to students?",
        "answer": "From the 2nd year onwards, CRC conducts comprehensive training modules in: 1) Quantitative aptitude and logical reasoning; 2) Data Structures, Algorithms, and Full-Stack Coding; 3) Soft skills, communication, and executive presence; 4) Resume building, group discussions, and mock technical/HR interviews.",
        "category": "Career services",
        "keywords": ["pre placement training", "soft skills", "aptitude classes", "coding training", "mock interview"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Training Modules - Career Services",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does the university organize corporate talks and CXO guest lectures?",
        "answer": "Yes, through the 'Industry Connect' initiative, senior corporate leaders, CTOs, and HR directors from Fortune 500 companies frequently conduct on-campus seminars and masterclasses.",
        "category": "Career services",
        "keywords": ["cxo lectures", "guest lectures", "corporate talks", "industry connect"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Industry Connect - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 23. Internship Information
    {
        "question": "Is an internship mandatory for undergraduate and postgraduate students?",
        "answer": "Yes, mandatory credit-bearing summer and final-semester internships are integrated into the curriculum for B.Tech, MBA, Law, and Design programs to ensure real-world industry readiness.",
        "category": "Internship information",
        "keywords": ["internship", "mandatory internship", "industry training", "summer internship", "credits"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Internship Policies - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University help students find internships?",
        "answer": "Yes, the Career Resource Centre facilitates on-campus internship drives where companies recruit students for 2 to 6-month stipendiary internships, frequently leading to Pre-Placement Offers (PPOs).",
        "category": "Internship information",
        "keywords": ["internship assistance", "ppo", "stipend internship", "internship drive"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Internship Cell - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What kinds of legal internships do School of Law students undergo?",
        "answer": "Law students undergo mandatory annual internships with trial court advocates, High Court advocates, senior corporate law firms, NGOs, legal aid cells, and judicial clerkships.",
        "category": "Internship information",
        "keywords": ["law internship", "court internship", "ngo internship", "advocate chambers"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Legal Internships - School of Law",
        "lastVerifiedDate": "2026-10-24"
    },

    # 24. Contact Details
    {
        "question": "What is the official contact number for admission inquiries?",
        "answer": "You can reach the Presidency University admissions helpline at +91 90220 92222 or the central board line at 080 4925 5555.",
        "category": "Contact details",
        "keywords": ["contact number", "phone number", "helpline", "admission call", "9022092222"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Contact Us - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the official admission email address?",
        "answer": "For general admission inquiries, email: admission@presidencyuniversity.in. For general institutional queries, email: info@presidencyuniversity.in.",
        "category": "Contact details",
        "keywords": ["email address", "admission email", "info email", "official mail"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Contact Emails - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the postal address of Presidency University main campus?",
        "answer": "Presidency University, Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064, Karnataka, India.",
        "category": "Contact details",
        "keywords": ["postal address", "mailing address", "pin code 560064", "university address"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Campus Address - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What are the operating hours of the Admissions Office?",
        "answer": "The Admissions Office is open Monday to Saturday from 9:00 AM to 5:00 PM (IST). It is closed on Sundays and designated public holidays.",
        "category": "Contact details",
        "keywords": ["working hours", "timing", "office hours", "open days"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Office Hours - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How can companies contact the Career Resource Centre for placements?",
        "answer": "Recruiters and corporate partners can contact the CRC at placements@presidencyuniversity.in or call the placement directorate at +91 80 4925 5555.",
        "category": "Contact details",
        "keywords": ["placement contact", "recruiter email", "crc phone", "hire graduates"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Placement Contact - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 25. Frequently Asked Questions
    {
        "question": "Is Presidency University ragging-free?",
        "answer": "Yes, Presidency University maintains a strict zero-tolerance policy towards ragging in compliance with Supreme Court and UGC directives. An active Anti-Ragging Committee and Squad conduct round-the-clock surprise checks.",
        "category": "Frequently asked questions",
        "keywords": ["anti ragging", "ragging policy", "student safety", "zero tolerance"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Anti-Ragging Policy - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is attendance compulsory at Presidency University?",
        "answer": "Yes, students must maintain a minimum of 75% attendance in each course theory and practical component to be eligible to appear for the End-Term Semester Examinations.",
        "category": "Frequently asked questions",
        "keywords": ["attendance rule", "75 percent attendance", "minimum attendance", "attendance requirement"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Academic Regulations - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Is there a dress code at Presidency University?",
        "answer": "Students are required to wear smart, formal/semi-formal attire reflecting an academic environment. Certain schools (such as the School of Law and School of Allied Health Sciences) mandate specific uniforms/blazers during formal courtroom days, labs, and presentations.",
        "category": "Frequently asked questions",
        "keywords": ["dress code", "uniform", "attire", "law uniform"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Student Code of Conduct - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Does Presidency University have on-campus medical facilities?",
        "answer": "Yes, the university has an on-campus Health Care Centre staffed 24/7 with resident doctors and qualified nurses. An emergency ambulance is stationed on campus, and the university has tie-ups with multi-specialty hospitals in Yelahanka.",
        "category": "Frequently asked questions",
        "keywords": ["medical facilities", "health clinic", "doctor on campus", "ambulance", "hospital tie up"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Healthcare & Wellness - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Are ATM and banking facilities available on campus?",
        "answer": "Yes, multi-bank ATM facilities are located inside the campus near the cafeteria and administrative blocks for convenient cash withdrawals by students and staff.",
        "category": "Frequently asked questions",
        "keywords": ["atm", "bank", "cash machine", "banking on campus"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Campus Amenities - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What food and canteen options exist on campus?",
        "answer": "The campus features a spacious multi-cuisine food court serving South Indian, North Indian, Chinese, and continental snacks, along with Café Coffee Day (CCD), Nescafe kiosks, juice corners, and an ice-cream parlour.",
        "category": "Frequently asked questions",
        "keywords": ["canteen", "food court", "cafe coffee day", "ccd", "cafeteria", "snacks"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Food & Dining - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },

    # 26. Official Application Links
    {
        "question": "What is the official link to apply for Presidency University?",
        "answer": "The official online application portal is accessible directly at: https://presidencyuniversity.in/ (click 'Apply Now'). Alternatively, link via the official admissions portal.",
        "category": "Official application links",
        "keywords": ["official application link", "apply online link", "registration link", "url"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Official Application Portal",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "Where can I download the official university prospectus and brochure?",
        "answer": "The official prospectus and school-specific brochures can be downloaded from the university portal at https://presidencyuniversity.in/ or obtained directly from the Admissions Desk.",
        "category": "Official application links",
        "keywords": ["download prospectus", "brochure link", "syllabus download", "handbook"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Prospectus Downloads - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the link to the official Presidency University website?",
        "answer": "The main official website is: https://presidencyuniversity.in/ (Main university portal with verified links and information).",
        "category": "Official application links",
        "keywords": ["main website", "official site link", "home page url", "presidency university in"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Presidency University Home",
        "lastVerifiedDate": "2026-10-24"
    },

    # 27. Important Notices
    {
        "question": "How does the university publish important examination and academic notices?",
        "answer": "All official circulars, examination schedules, time-tables, and academic calendar revisions are published on the official Presidency University Student Portal / ERP system and displayed on departmental notice boards.",
        "category": "Important notices",
        "keywords": ["notices", "circulars", "exam timetable", "student portal notice", "announcements"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "University Notices - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "What is the advisory regarding fake admission agents or brokers?",
        "answer": "Presidency University strictly cautions parents and candidates that it has NOT authorized any external brokers, agents, or consultancies to charge commission or guarantee admissions. All admissions are processed exclusively through the official university portal or official campus admissions office.",
        "category": "Important notices",
        "keywords": ["fake agents warning", "broker caution", "fraud alert", "official admission only"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Public Caution Notice - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    },
    {
        "question": "How are fee refunds handled if an admission is cancelled?",
        "answer": "Fee refunds follow UGC guidelines: 100% refund (less nominal processing fee) if withdrawal request is received 15 days or more before the formally notified last date of admission, with graded refund percentages thereafter as per UGC refund directives.",
        "category": "Important notices",
        "keywords": ["refund policy", "fee refund", "cancellation of admission", "ugc refund rules"],
        "sourceUrl": "https://presidencyuniversity.in/",
        "sourceTitle": "Refund Policy - Presidency University",
        "lastVerifiedDate": "2026-10-24"
    }
]

print(f"Initial seed records: {len(database)}")
