import { retrieveAnswer, tokenize } from './src/services/aiRetrievalEngine.js';

const testQueries = [
  'fees',
  'fess',
  'what is the fees',
  'fee',
  'what are the fees',
  'fees structure',
  'fess details',
  'btech fees',
  'hostel fees',
  'mba fees',
  'how much fees'
];

for (const q of testQueries) {
  const res = retrieveAnswer(q);
  console.log(`Query: "${q}" => Status: ${res.status}, Conf: ${res.confidence}, Match: "${res.matchedEntry ? res.matchedEntry.question : 'NONE'}"`);
}
