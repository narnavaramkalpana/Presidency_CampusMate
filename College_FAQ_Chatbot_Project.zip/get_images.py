import re

f = open(r'C:\Users\ASUS\.gemini\antigravity\brain\8066d25f-8824-4ec2-a544-b32cbbecdc86\.system_generated\steps\166\content.md', encoding='utf-8').read()
imgs = set(re.findall(r'https://presidencyuniversity\.in[^\s\"\'\)\>]+\.(?:jpg|jpeg|png|webp|svg)', f))
for img in sorted(imgs):
    print(img)
