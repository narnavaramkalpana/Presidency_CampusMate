import React from 'react';
import { 
  Sparkles, 
  Users, 
  Music, 
  Activity, 
  HeartHandshake, 
  ShieldCheck, 
  Camera, 
  Award, 
  CheckCircle2, 
  ArrowRight,
  Smile,
  Compass
} from 'lucide-react';

export default function CampusLife({ onAskAI, setActivePage }) {
  const clubs = [
    {
      category: 'Technical & Coding',
      list: [
        { name: 'Presidency Coding Club', desc: 'Competitive programming, LeetCode sprints, and beginner-to-advanced algorithms.' },
        { name: 'ACM Student Chapter', desc: 'Association for Computing Machinery student chapter hosting national hackathons.' },
        { name: 'IEEE Student Branch', desc: 'Technical symposiums, IEEE paper writing, and robotics engineering projects.' },
        { name: 'Google Developer Student Club', desc: 'Android, Cloud, and Machine Learning workshops using Google technologies.' }
      ]
    },
    {
      category: 'Cultural & Performing Arts',
      list: [
        { name: 'Symphony Music Club', desc: 'Vocalists, instrumental bands, fusion acoustic gigs, and battle of the bands.' },
        { name: 'Presidency Dance Crew', desc: 'Award-winning choreography team covering hip-hop, contemporary, and classical styles.' },
        { name: 'Dramatics & Theatre Society', desc: 'Proscenium plays, street plays (Nukkad Natak), mime, and state drama competitions.' },
        { name: 'Shutterbugs (Photography & Film)', desc: 'Visual media, filmmaking, photo walks, and live event coverage.' }
      ]
    },
    {
      category: 'Community & Social Action',
      list: [
        { name: 'Rotaract Club of Presidency University', desc: 'Chartered under Rotary District 3192 for youth leadership and community charity.' },
        { name: 'National Service Scheme (NSS)', desc: 'Rural village health camps, blood donation drives, and literacy campaigns.' },
        { name: 'National Cadet Corps (NCC)', desc: 'Army Wing detachment instilling military discipline, drills, and national pride.' },
        { name: 'Eco & Sustainability Club', desc: 'Tree planting, campus waste segregation, and green environmental awareness.' }
      ]
    },
    {
      category: 'Literary & Debating',
      list: [
        { name: 'Presidency MUN Society', desc: 'Model United Nations simulations, international diplomacy, and Parliamentary debate.' },
        { name: 'Literary & Quizzing Club', desc: 'Trivia tournaments, creative writing, poetry slams, and book discussions.' },
        { name: 'Legal Aid & Human Rights Cell', desc: 'Community legal awareness and legal rights advocacy in adopted villages.' }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner with Real Campus Life Background */}
      <div className="rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden bg-slate-950 border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/80 via-[#0a1e3b]/65 to-[#091b33]/60 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-500/20 text-blue-200 text-xs font-semibold border border-blue-400/30">
            <Sparkles className="w-3.5 h-3.5 text-blue-300" />
            <span>Directorate of Student Affairs (DSA)</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif text-white tracking-tight">
            Campus Life & Invincia
          </h1>
          <p className="text-sm text-slate-200 leading-relaxed font-normal">
            Life at Presidency University Bengaluru extends far beyond textbooks. With vibrant student clubs, cultural festivals, inter-collegiate tournaments, and leadership forums, every day brings opportunities to collaborate and shine.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onAskAI("What is Invincia at Presidency University?")}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-2 cursor-pointer hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI About Invincia</span>
            </button>
            <button
              onClick={() => onAskAI("What student clubs are available at Presidency University?")}
              className="px-4 py-2.5 bg-slate-950/80 hover:bg-slate-900 text-white font-bold text-xs rounded-xl border border-slate-700 shadow-sm transition flex items-center gap-2 cursor-pointer hover:scale-105 active:scale-95"
            >
              <Users className="w-3.5 h-3.5 text-blue-400" />
              <span>Ask AI About Clubs</span>
            </button>
          </div>
        </div>
      </div>

      {/* Invincia Feature Card */}
      <div className="bg-gradient-to-br from-[#091b33] to-[#163e72] rounded-3xl p-8 sm:p-10 text-white shadow-lg space-y-6 border border-blue-900/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/15 pb-6">
          <div>
            <span className="text-xs font-bold text-blue-300 uppercase tracking-widest block mb-1">
              Annual Mega Cultural Extravaganza
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif">
              Invincia – South India’s Premier Youth Fest
            </h2>
          </div>
          <div className="text-xs font-semibold text-blue-100 bg-blue-950/70 border border-blue-400/40 px-3.5 py-1.5 rounded-full shadow-inner">
            15,000+ Footfall • 60+ National Colleges Participating
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
          Organized by the Department of Student Affairs, Invincia transforms the 65-acre campus into a vibrant festival ground with multiple live performance stages, celebrity headliners, high-octane battle of the bands, designer fashion pro-nites, and street choreography face-offs.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="bg-white/10 p-4 rounded-xl border border-white/15 backdrop-blur-xs">
            <Music className="w-5 h-5 text-blue-300 mb-2" />
            <h4 className="text-xs font-bold text-white mb-1">Celebrity Pro-Nites</h4>
            <p className="text-[11px] text-slate-200 leading-relaxed">Live concert performances by renowned Bollywood, indie, and international music sensations.</p>
          </div>
          <div className="bg-white/10 p-4 rounded-xl border border-white/15 backdrop-blur-xs">
            <Activity className="w-5 h-5 text-blue-300 mb-2" />
            <h4 className="text-xs font-bold text-white mb-1">Dance & Fashion</h4>
            <p className="text-[11px] text-slate-200 leading-relaxed">Inter-college street dance face-offs, fusion beats, and themed couture runway competitions.</p>
          </div>
          <div className="bg-white/10 p-4 rounded-xl border border-white/15 backdrop-blur-xs">
            <Award className="w-5 h-5 text-blue-300 mb-2" />
            <h4 className="text-xs font-bold text-white mb-1">Cash Prizes & Trophies</h4>
            <p className="text-[11px] text-slate-200 leading-relaxed">Over ₹10 Lakhs in cash prizes, trophies, and corporate talent-scouting opportunities.</p>
          </div>
        </div>
      </div>

      {/* Student Clubs Directory */}
      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold text-[#091b33] font-serif">
            Student Clubs & Activity Chapters
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Join during the annual 'Club Carnival' or start your own chapter with faculty mentorship.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {clubs.map((group, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4"
            >
              <h3 className="text-base font-bold text-[#091b33] border-b border-slate-100 pb-3 flex items-center justify-between">
                <span>{group.category}</span>
                <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded font-mono">
                  {group.list.length} Clubs
                </span>
              </h3>

              <div className="space-y-3">
                {group.list.map((c, cIdx) => (
                  <div key={cIdx} className="p-3 bg-slate-50 hover:bg-blue-50/50 rounded-xl border border-slate-100 transition">
                    <h4 className="text-xs font-bold text-slate-900">{c.name}</h4>
                    <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">{c.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Student Wellness & Counseling */}
      <div className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center flex-shrink-0">
            <Smile className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-base font-bold text-slate-900">
              Student Counseling & Mental Wellness Centre
            </h4>
            <p className="text-xs text-slate-600 mt-0.5 max-w-xl">
              Professional counselors and clinical psychologists provide empathetic, confidential guidance to help students maintain mental balance and overcome academic or personal challenges.
            </p>
          </div>
        </div>

        <button
          onClick={() => onAskAI("How does the university assist students with mental wellness and counseling?")}
          className="px-4 py-2 bg-[#091b33] hover:bg-[#163e72] text-blue-400 font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 whitespace-nowrap"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Ask AI Wellness Support</span>
        </button>
      </div>
    </div>
  );
}
