import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  ArrowRight, 
  GraduationCap, 
  BookOpen, 
  Building2, 
  Award, 
  ShieldCheck, 
  Briefcase, 
  Bus, 
  Home as HomeIcon, 
  MapPin, 
  Mic, 
  DollarSign, 
  Compass, 
  MessageSquare,
  Users
} from 'lucide-react';
import { universityMetadata } from '../data/universityDatabase';

export default function Home({ setActivePage, onAskAI, onOpenMap, onOpenExplainer }) {
  const [heroInput, setHeroInput] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleHeroSubmit = (e) => {
    e.preventDefault();
    if (heroInput.trim()) {
      onAskAI(heroInput.trim());
      setHeroInput('');
    }
  };

  // Voice Search via Web Speech API in Hero
  const handleHeroVoice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      onAskAI("What is the admission process for Presidency University?");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        setHeroInput(transcript);
        onAskAI(transcript);
      }
    };
    recognition.start();
  };

  // Streamlined Quick Access Hub (8 core university areas)
  const quickAccessCards = [
    {
      id: 'admissions',
      title: 'Admissions 2026-27',
      desc: 'Application process, KCET/COMEDK cutoffs & eligibility.',
      icon: ShieldCheck,
      page: 'admissions',
      aiQuery: 'How can I apply for admission 2026-27?',
      color: 'text-blue-600 bg-blue-50 border-blue-200 dark:bg-blue-900/40 dark:border-blue-800 dark:text-blue-300'
    },
    {
      id: 'courses',
      title: 'Courses & Programs',
      desc: '80+ UG & PG degrees across Engineering, Law, Management & Design.',
      icon: GraduationCap,
      page: 'courses',
      aiQuery: 'What courses are offered at Presidency University?',
      color: 'text-indigo-600 bg-indigo-50 border-indigo-200 dark:bg-indigo-900/40 dark:border-indigo-800 dark:text-indigo-300'
    },
    {
      id: 'fees',
      title: 'Fees & Scholarships',
      desc: 'Fee structures, quota breakdowns & up to 50% merit concessions.',
      icon: DollarSign,
      page: 'fees',
      aiQuery: 'What is the fee structure across courses?',
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-900/40 dark:border-emerald-800 dark:text-emerald-300'
    },
    {
      id: 'placements',
      title: 'Placements & Careers',
      desc: '₹13.58 LPA top package, 97% placement record & 550+ recruiters.',
      icon: Briefcase,
      page: 'placements',
      aiQuery: 'What was the highest placement package?',
      color: 'text-purple-600 bg-purple-50 border-purple-200 dark:bg-purple-900/40 dark:border-purple-800 dark:text-purple-300'
    },
    {
      id: 'navigation',
      title: 'Campus Navigation',
      desc: 'Real floor & block locations for cafeteria, library, labs & offices.',
      icon: MapPin,
      page: 'facilities',
      aiQuery: 'Where is the cafeteria located on campus?',
      color: 'text-rose-600 bg-rose-50 border-rose-200 dark:bg-rose-900/40 dark:border-rose-800 dark:text-rose-300',
      action: () => (onOpenMap ? onOpenMap('cafeteria') : setActivePage('facilities'))
    },
    {
      id: 'hostel',
      title: 'Hostels & Dining',
      desc: 'Biometric hostels, AC/non-AC rooms & 4-meal daily dining.',
      icon: HomeIcon,
      page: 'hostel',
      aiQuery: 'What hostel facilities and fees are offered?',
      color: 'text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-900/40 dark:border-amber-800 dark:text-amber-300'
    },
    {
      id: 'transport',
      title: 'Campus Transportation',
      desc: '50+ GPS-tracked bus routes across Bengaluru metropolitan zones.',
      icon: Bus,
      page: 'hostel',
      aiQuery: 'Which areas are covered by university buses?',
      color: 'text-teal-600 bg-teal-50 border-teal-200 dark:bg-teal-900/40 dark:border-teal-800 dark:text-teal-300'
    },
    {
      id: 'campus-life',
      title: 'Campus Life & Clubs',
      desc: 'Invincia fest, 30+ student clubs, sports arena & student affairs.',
      icon: Users,
      page: 'campus-life',
      aiQuery: 'What student clubs and cultural activities are available?',
      color: 'text-cyan-600 bg-cyan-50 border-cyan-200 dark:bg-cyan-900/40 dark:border-cyan-800 dark:text-cyan-300'
    }
  ];

  return (
    <div className="space-y-12 sm:space-y-16 pb-12">
      {/* Hero Section with Clean College Campus Background */}
      <section className="relative overflow-hidden min-h-[480px] sm:min-h-[520px] flex items-center justify-center text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        {/* Real Campus Background Image - Official Presidency University Campus Entrance */}
        <div 
          className="absolute inset-0 bg-cover bg-center sm:bg-[center_35%] bg-no-repeat transform scale-102"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />

        {/* Cinematic navy gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#091b33]/75 via-[#0a1e3b]/60 to-[#091b33]/85" />

        <div className="relative z-10 w-full max-w-3xl mx-auto text-center space-y-6">
          {/* Clean Minimal Title */}
          <div>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white drop-shadow-md">
              College FAQ <span className="text-blue-400">Chatbot</span>
            </h1>
          </div>

          {/* AI Interactive Search Input Box */}
          <div className="w-full max-w-2xl mx-auto">
            <form onSubmit={handleHeroSubmit} className="relative flex items-center w-full shadow-2xl rounded-2xl overflow-hidden border border-white/25 bg-slate-950/90 backdrop-blur-md p-1.5 focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-500/25 transition-all duration-200">
              <div className="pl-3 text-blue-400 flex items-center flex-shrink-0">
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <input
                type="text"
                value={heroInput}
                onChange={(e) => setHeroInput(e.target.value)}
                placeholder="Ask College FAQ Chatbot: 'DevOps fees?', 'Cafeteria location?'..."
                className="w-full min-w-0 flex-1 bg-transparent px-3 py-2.5 sm:py-3 text-sm sm:text-base text-white placeholder-slate-400 focus:outline-none"
              />
              
              {/* Voice Search Button */}
              <button
                type="button"
                onClick={handleHeroVoice}
                className={`p-2 sm:p-2.5 rounded-xl transition cursor-pointer mr-1.5 flex-shrink-0 ${
                  isListening ? 'bg-rose-500 text-white animate-pulse shadow-md' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
                title={isListening ? "Listening... Click to stop" : "Voice Input"}
              >
                <Mic className="w-4 h-4" />
              </button>

              {/* Submit Button */}
              <button
                type="submit"
                className="px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 sm:gap-2 shadow-lg transition whitespace-nowrap cursor-pointer hover:scale-102 active:scale-98 flex-shrink-0"
              >
                <span>Ask</span>
                <Send className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* University Key Highlights Metrics - Clean 4-card ribbon */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          {[
            { label: 'Campus Area', value: '65+ Acres', sub: 'Lush green Rajanakunte' },
            { label: 'Top Placement CTC', value: '₹13.58 LPA', sub: '550+ Recruiters' },
            { label: 'Academic Legacy', value: '48+ Years', sub: 'Presidency Group Estd. 1976' },
            { label: 'Verified QA Records', value: `${universityMetadata.totalFAQEntries}+ Records`, sub: '100% Official Database' }
          ].map((metric, idx) => (
            <div 
              key={idx}
              className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-md border border-slate-200/90 dark:border-slate-800 text-center hover:shadow-lg transition hover:-translate-y-0.5"
            >
              <div className="text-xl sm:text-2xl font-black text-[#091b33] dark:text-blue-300 font-serif">
                {metric.value}
              </div>
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-0.5">{metric.label}</div>
              <div className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">{metric.sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Access Campus Hub - Clean, interactive cards with direct actions */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-900 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-bold uppercase tracking-wider">
            <Compass className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Campus Exploration</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#091b33] dark:text-white font-serif">
            Quick University Services
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Browse verified information by department or query the AI assistant directly.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {quickAccessCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200/90 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 shadow-xs hover:shadow-md transition flex flex-col justify-between group"
              >
                <div>
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-3.5 border ${card.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition">
                    {card.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {card.desc}
                  </p>
                </div>

                <div className="pt-3.5 mt-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <button
                    onClick={() => (card.action ? card.action() : setActivePage(card.page))}
                    className="text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-1 cursor-pointer transition"
                  >
                    <span>{card.id === 'navigation' ? 'Open Map' : 'View'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => onAskAI(card.aiQuery)}
                    className="text-[11px] font-semibold text-blue-700 dark:text-blue-300 hover:text-blue-900 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/80 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 transition flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                    <span>Ask AI</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* AI Assistant Callout Banner - Clean and Focused */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl p-6 sm:p-10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-blue-400/30 overflow-hidden">
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/92 via-[#163e72]/88 to-[#091b33]/90 backdrop-blur-[1px]" />
          
          <div className="relative z-10 space-y-2 max-w-xl text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>College FAQ Chatbot Intelligence</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-extrabold font-serif">
              Have Questions About Presidency University?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
              Ask about B.Tech CSE specialization fees, KCET cutoffs, hostel accommodation, or campus directions. Answers are verified and available 24/7.
            </p>
          </div>

          <div className="relative z-10 flex flex-wrap gap-3 justify-center">
            <button
              onClick={() => onAskAI('')}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center gap-2 cursor-pointer hover:scale-102"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask FAQ Chatbot</span>
            </button>
            <button
              onClick={() => (onOpenMap ? onOpenMap() : setActivePage('facilities'))}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm border border-white/20 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Campus Map</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
