import re

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    text = f.read()

# find all questions matching cse, btech, devops, fees
entries = re.findall(r'\{\s*"id":\s*(\d+),[\s\S]*?"question":\s*"([^"]+)",[\s\S]*?"category":\s*"([^"]+)"', text)
print(f"Total entries: {len(entries)}")
for id_num, q, cat in entries:
    q_low = q.lower()
    if any(k in q_low for k in ['cse', 'devops', 'specialization', 'b.tech fee', 'engineering fee', 'computer science']):
        print(f"ID {id_num} [{cat}]: {q}")
