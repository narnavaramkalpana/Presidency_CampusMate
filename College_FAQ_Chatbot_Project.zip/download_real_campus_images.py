import urllib.request
import os

os.makedirs(r"C:\Users\ASUS\.gemini\antigravity\scratch\campusmate-presidency\public\assets", exist_ok=True)

images_to_download = {
    "isr-campus-banner.webp": "https://presidencyuniversity.in/uploads/images/6902e9e44fb4d1761798628.webp",
    "campus-building-main.jpeg": "https://presidencyuniversity.in/uploads/home/banner_images/6ab380919c2021790148753.jpeg",
    "campus-aerial-green.jpeg": "https://presidencyuniversity.in/uploads/home/banner_images/6960bbfd894091767947261.jpeg",
    "campus-academic-block.jpeg": "https://presidencyuniversity.in/uploads/home/banner_images/6ab37fde6b9e91790148574.jpeg",
    "campus-life-lg.jpg": "https://presidencyuniversity.in/assets/images/life-pre-lg.jpg"
}

headers = {'User-Agent': 'Mozilla/5.0'}

for name, url in images_to_download.items():
    dest = os.path.join(r"C:\Users\ASUS\.gemini\antigravity\scratch\campusmate-presidency\public\assets", name)
    try:
        req = urllib.request.Request(url, headers=headers)
        data = urllib.request.urlopen(req, timeout=15).read()
        with open(dest, "wb") as f:
            f.write(data)
        print(f"Downloaded {name} ({len(data)} bytes) from {url}")
    except Exception as e:
        print(f"Failed to download {name}: {e}")
