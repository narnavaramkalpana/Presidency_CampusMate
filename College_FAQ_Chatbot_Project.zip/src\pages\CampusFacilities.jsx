import React from 'react';
import { 
  Building2, 
  BookOpen, 
  Cpu, 
  Activity, 
  Coffee, 
  Heart, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  ExternalLink,
  Volume2,
  Compass,
  Navigation,
  MapPin,
  ArrowRight
} from 'lucide-react';
import { CAMPUS_WAYPOINTS } from '../components/CampusMapModal';

export default function CampusFacilities({ onAskAI, setActivePage, onOpenMap }) {
  const facilities = [
    {
      id: 'library',
      title: 'Automated Libraries & Knowledge Centre',
      category: 'Academic Resource',
      icon: BookOpen,
      desc: 'Central Library, Law Library (E-Block), and Management Annexe housing over 40,500+ volumes, 150+ journals, and digital subscriptions to IEEE Xplore, ScienceDirect, EBSCO, and Knimbus remote access.',
      bullets: [
        'Automated with KOHA Integrated Library Management Software',
        'RFID security gates & self-service checkout kiosks',
        '24/7 off-campus Knimbus remote e-resource portal',
        'Turnitin & DrillBit plagiarism detection software for research'
      ],
      waypointId: 'central-library'
    },
    {
      id: 'computing',
      title: 'High-Performance Computing & AI Labs',
      category: 'Research & Labs',
      icon: Cpu,
      desc: 'Over 2,000+ networked high-end desktop workstations powered by NVIDIA GPU clusters for deep learning, artificial intelligence research, and big data computations.',
      bullets: [
        'Dedicated Apple Mac Lab with iMacs for iOS/macOS engineering',
        'Cisco Networking & Cyber Security simulation environments',
        'IoT, Cloud Computing, and Blockchain testing testbeds',
        'Campus-wide high-speed secure Wi-Fi infrastructure'
      ],
      waypointId: 'engineering-block'
    },
    {
      id: 'engineering-labs',
      title: 'Advanced Engineering Workshops',
      category: 'Engineering Infrastructure',
      icon: Building2,
      desc: 'State-of-the-art practical laboratories for all engineering disciplines equipped with industry-grade experimental setups and simulation packages.',
      bullets: [
        'Robotics & Industrial Automation Lab',
        'Mechatronics & Pneumatics Control Systems Lab',
        'Cadence & Synopsis VLSI Design Suites',
        'Materials Science & Metallography Testing Workshop',
        'Drilling & Fluid Mechanics rigs for Petroleum Engineering'
      ],
      waypointId: 'labs-workshop'
    },
    {
      id: 'moot-court',
      title: 'Moot Court Hall (School of Law)',
      category: 'Legal Infrastructure',
      icon: ShieldCheck,
      desc: 'Full-scale air-conditioned replica court hall designed to simulate real courtroom appellate and trial advocacy proceedings as approved by the Bar Council of India.',
      bullets: [
        'Acoustically treated judge’s bench and bar council tables',
        'Integrated audio/video recording for trial reviews',
        'Legal Aid Clinic offering community pro bono advice',
        'Hosts the prestigious Annual National Moot Court Competition'
      ],
      waypointId: 'admin-block'
    },
    {
      id: 'sports',
      title: 'Sports Arena & Modern Gymnasiums',
      category: 'Athletics & Wellness',
      icon: Activity,
      desc: 'Expansive outdoor and indoor sports complexes encouraging physical well-being, teamwork, and competitive varsity athletics.',
      bullets: [
        'Full-sized cricket ground with dedicated turf practice nets',
        'Standard football turf & athletic running tracks',
        'Floodlit outdoor basketball and volleyball courts',
        'Separate fully equipped gyms for boys & girls with cardio & strength machines',
        'Table tennis, chess lounges, and Yoga & Meditation studio'
      ],
      waypointId: 'sports-arena'
    },
    {
      id: 'health',
      title: '24/7 Health Care Centre & Emergency Care',
      category: 'Medical Services',
      icon: Heart,
      desc: 'Round-the-clock on-campus health clinic providing medical consultations, first-aid, observation beds, and emergency response.',
      bullets: [
        'Resident physician and qualified nursing staff on campus',
        'Dedicated emergency ambulance stationed 24/7 at main gate',
        'Tie-ups with premier multi-specialty hospitals in Yelahanka',
        'Group accidental health insurance coverage for all students'
      ],
      waypointId: 'health-atm'
    },
    {
      id: 'dining',
      title: 'Multi-Cuisine Food Courts & Cafes',
      category: 'Student Life',
      icon: Coffee,
      desc: 'Spacious food courts offering delicious, hygienic North Indian, South Indian, and continental meals along with branded coffee outlets.',
      bullets: [
        'Café Coffee Day (CCD) and Nescafe express kiosks',
        'Fresh fruit juice bars and ice-cream parlours',
        'Continuous quality and hygiene audits by university food committee',
        'Spacious indoor and covered outdoor seating pavilions'
      ],
      waypointId: 'cafeteria'
    },
    {
      id: 'auditorium',
      title: 'Convention Centre Auditorium & Amphitheaters',
      category: 'Events & Conclaves',
      icon: Volume2,
      desc: 'A magnificent 1,200+ capacity air-conditioned auditorium convention centre for academic convocations, national conferences, and international symposia.',
      bullets: [
        'State-of-the-art line-array acoustic audio and digital projection',
        'Two open-air landscaped amphitheaters for cultural performances',
        'Conference seminar halls equipped with smart interactive boards'
      ],
      waypointId: 'admin-block'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header Banner with Real Campus Background */}
      <div className="rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden bg-slate-950 border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/85 via-[#0a1e3b]/70 to-[#091b33]/65 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <Building2 className="w-3.5 h-3.5" />
            <span>65+ Acre Eco-Friendly Campus</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Campus Facilities & Infrastructure
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Presidency University Bengaluru provides cutting-edge academic laboratories, automated libraries, athletic arenas, and student amenities designed for complete holistic development.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onOpenMap && onOpenMap()}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-2 cursor-pointer"
            >
              <Compass className="w-4 h-4" />
              <span>Launch Interactive Campus Map</span>
            </button>
            <a
              href="https://maps.app.goo.gl/YKo4kaj7VsPtktNh7"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5"
            >
              <Navigation className="w-3.5 h-3.5 text-blue-300" />
              <span>Google Maps Navigation</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>
          </div>
        </div>
      </div>

      {/* Interactive Campus Map & Waypoint Guide Banner */}
      <div className="bg-gradient-to-r from-blue-900/10 via-indigo-900/10 to-slate-900/5 dark:from-blue-950/40 dark:via-indigo-950/30 dark:to-slate-900/50 rounded-3xl p-6 sm:p-8 border border-blue-200/80 dark:border-blue-900/60 shadow-sm space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              <Compass className="w-3.5 h-3.5" />
              <span>Campus Navigation Hub</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white font-serif">
              Key Campus Landmarks & Navigation Waypoints
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Locate academic blocks, cafeteria, laboratories, and student residences with instant walking directions.
            </p>
          </div>

          <button
            onClick={() => onOpenMap && onOpenMap()}
            className="self-start md:self-auto px-4 py-2.5 bg-gradient-to-r from-[#091b33] to-[#163e72] hover:from-[#0d2346] hover:to-[#1a4985] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-2 cursor-pointer border border-blue-400/40 flex-shrink-0"
          >
            <Compass className="w-4 h-4 text-blue-300" />
            <span>Open Interactive Map</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Quick Waypoints Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 pt-1">
          {CAMPUS_WAYPOINTS.slice(0, 5).map((wp) => {
            const Icon = wp.icon;
            return (
              <button
                key={wp.id}
                onClick={() => onOpenMap && onOpenMap(wp.id)}
                className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-400 dark:hover:border-blue-500 shadow-2xs hover:shadow-xs transition text-left cursor-pointer group flex items-start gap-2.5"
              >
                <div 
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs flex-shrink-0 mt-0.5"
                  style={{ backgroundColor: wp.color }}
                >
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 truncate">
                    {wp.shortName}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">{wp.floor}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Facilities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
        {facilities.map((fac) => {
          const Icon = fac.icon;
          return (
            <div
              key={fac.id}
              className="bg-white dark:bg-slate-800/90 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700/80 hover:border-blue-300 dark:hover:border-blue-500 shadow-sm hover:shadow-md transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-bold text-[#163e72] dark:text-blue-300 bg-blue-50 dark:bg-blue-900/50 px-2.5 py-1 rounded-md uppercase tracking-wider">
                    {fac.category}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition mb-2">
                  {fac.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                  {fac.desc}
                </p>

                <ul className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-700/80">
                  {fac.bullets.map((b, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 mt-6 border-t border-slate-100 dark:border-slate-700/80 flex items-center justify-between">
                <button
                  onClick={() => onAskAI(`Tell me about the ${fac.title} at Presidency University.`)}
                  className="text-xs font-bold text-blue-700 dark:text-blue-400 hover:text-[#091b33] dark:hover:text-white flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Ask AI Details</span>
                </button>
                {fac.waypointId && onOpenMap && (
                  <button
                    onClick={() => onOpenMap(fac.waypointId)}
                    className="text-xs text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Compass className="w-3 h-3" />
                    <span>View on Map →</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
