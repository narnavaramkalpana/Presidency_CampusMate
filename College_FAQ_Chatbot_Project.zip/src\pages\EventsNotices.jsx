import React, { useState } from 'react';
import { 
  Calendar, 
  Bell, 
  AlertTriangle, 
  FileText, 
  ExternalLink, 
  Sparkles, 
  Search, 
  Tag, 
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

export default function EventsNotices({ onAskAI }) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const notices = [
    {
      id: 1,
      title: 'Admissions 2026–2027: Early Action Application Window Open',
      category: 'Admissions',
      date: 'October 2026',
      summary: 'Online applications are open for B.Tech, MBA, Law (BA/BBA LLB), Design, and Allied Health Sciences for the upcoming academic cohort. Early applicants qualify for priority merit scholarships.',
      sourceUrl: 'https://presidencyuniversity.in/',
      isImportant: true
    },
    {
      id: 2,
      title: 'PUBLIC CAUTION: Unauthorized Admission Brokers & Consultancies Alert',
      category: 'Statutory Notice',
      date: 'Permanent Notice',
      summary: 'Presidency University strictly cautions that it has NOT authorized any third-party brokers or agents. All admissions are conducted strictly through the official portal or campus admissions office.',
      sourceUrl: 'https://presidencyuniversity.in/',
      isCaution: true
    },
    {
      id: 3,
      title: 'Invincia 2026: Annual Inter-Collegiate Cultural Festival Dates Announced',
      category: 'Events & Cultural',
      date: 'Event Update',
      summary: 'The Directorate of Student Affairs has officially announced the dates for Invincia 2026. Student clubs and collegiate contingents across India can register online for dance, music, and fashion events.',
      sourceUrl: 'https://presidencyuniversity.in/'
    },
    {
      id: 4,
      title: 'End-Term Semester Examinations: Hall Ticket & Attendance Eligibility Notice',
      category: 'Examinations',
      date: 'Academic Circular',
      summary: 'Students with 75% and above attendance in all courses can download digital exam hall tickets from their student ERP portal. Re-sit/makeup examination dates will be published by the Controller of Examinations.',
      sourceUrl: 'https://presidencyuniversity.in/'
    },
    {
      id: 5,
      title: 'Mandatory Anti-Ragging Affidavit Submission under UGC Guidelines',
      category: 'Compliance',
      date: 'Statutory Compliance',
      summary: 'All first-year and senior students must submit their online Anti-Ragging Undertaking reference number via antiragging.in to the Proctorial Board before semester registration.',
      sourceUrl: 'https://presidencyuniversity.in/'
    },
    {
      id: 6,
      title: 'Fee Refund Policy upon Admission Cancellation as per UGC Mandate',
      category: 'Statutory Notice',
      date: 'Policy Guidelines',
      summary: 'UGC-compliant refund guidelines: 100% refund (less nominal administrative fee) if cancellation is submitted 15 days or more before the formally announced commencement date.',
      sourceUrl: 'https://presidencyuniversity.in/'
    },
    {
      id: 7,
      title: 'National Hackathon & Tech Conclave: Registrations Open for Coding Chapters',
      category: 'Events & Cultural',
      date: 'TechFest Update',
      summary: 'The School of Computer Science & Engineering invites 2-4 member student teams for a 36-hour hackathon focused on Generative AI, Green Mobility, and Smart Cities with cash rewards.',
      sourceUrl: 'https://presidencyuniversity.in/'
    },
    {
      id: 8,
      title: 'Campus Placement Season: Major MNCs Scheduling On-Campus Technical Drives',
      category: 'Placements',
      date: 'Career Circular',
      summary: 'The Career Resource Centre (CRC) has scheduled technical recruitment drives with Microsoft, Capgemini, Infosys, and Deloitte for eligible final-year candidates without backlogs.',
      sourceUrl: 'https://presidencyuniversity.in/'
    }
  ];

  const categoriesList = ['All', 'Admissions', 'Examinations', 'Events & Cultural', 'Placements', 'Statutory Notice'];

  const filteredNotices = notices.filter(n => {
    const matchCat = activeCategory === 'All' || n.category === activeCategory;
    const matchSearch = searchQuery === '' ||
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-8 sm:p-12 text-white shadow-xl overflow-hidden border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/88 via-[#0d2346]/80 to-[#163e72]/75 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <Bell className="w-3.5 h-3.5" />
            <span>Official University Notice Board</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Events, Circulars & Notices
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Stay updated with verified academic announcements, exam schedules, cultural fests, recruitment drives, and statutory advisories directly from Presidency University.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 text-xs no-scrollbar">
          {categoriesList.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-semibold transition ${
                activeCategory === cat
                  ? 'bg-[#091b33] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search circulars..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Notices List */}
      <div className="space-y-4">
        {filteredNotices.map((notice) => (
          <div
            key={notice.id}
            className={`bg-white rounded-2xl p-6 border transition shadow-xs hover:shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 ${
              notice.isCaution 
                ? 'border-rose-200 bg-rose-50/20' 
                : notice.isImportant 
                  ? 'border-blue-300 bg-blue-50/15' 
                  : 'border-slate-200'
            }`}
          >
            <div className="space-y-2 max-w-3xl">
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                  notice.isCaution 
                    ? 'bg-rose-100 text-rose-800 border border-rose-300' 
                    : 'bg-blue-100 text-blue-900 border border-blue-300'
                }`}>
                  {notice.category}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  {notice.date}
                </span>
                {notice.isCaution && (
                  <span className="flex items-center gap-1 text-[10px] text-rose-700 font-bold">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    Public Advisory
                  </span>
                )}
              </div>

              <h3 className="text-base font-bold text-slate-900">
                {notice.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {notice.summary}
              </p>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0 self-start md:self-center">
              <button
                onClick={() => onAskAI(`Tell me more about the notice: ${notice.title}`)}
                className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-xs rounded-lg border border-blue-400/30 transition flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Ask AI</span>
              </button>
              <a
                href={notice.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
                title="View on official portal"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
