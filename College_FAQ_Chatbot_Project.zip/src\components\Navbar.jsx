import React, { useState, useEffect, useRef } from 'react';
import PresidencyLogo from './PresidencyLogo';
import { 
  Search, 
  Sparkles, 
  Menu, 
  X, 
  ExternalLink, 
  ChevronDown,
  Sun,
  Moon,
  Compass,
  MapPin,
  BookOpen
} from 'lucide-react';

export default function Navbar({ 
  activePage, 
  setActivePage, 
  onOpenSearch, 
  onOpenAIChat,
  theme = 'light',
  toggleTheme,
  onOpenMap,
  onOpenExplainer
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);
  const moreRef = useRef(null);

  // Close "More" dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (moreRef.current && !moreRef.current.contains(event.target)) {
        setMoreDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Primary desktop navigation links (always visible on desktop)
  const primaryLinks = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'courses', label: 'Courses' },
    { id: 'admissions', label: 'Admissions' },
    { id: 'fees', label: 'Fees', fullLabel: 'Fees & Scholarships' },
    { id: 'placements', label: 'Placements' },
    { id: 'facilities', label: 'Facilities' },
    { id: 'hostel', label: 'Hostels', fullLabel: 'Hostel & Transport' },
    { id: 'campus-life', label: 'Campus Life' },
    { id: 'events', label: 'Events', fullLabel: 'Events & Notices' },
    { id: 'contact', label: 'Contact' },
  ];

  // Mobile drawer links
  const allNavLinks = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Presidency' },
    { id: 'courses', label: 'Courses & Programs' },
    { id: 'admissions', label: 'Admissions 2026-27' },
    { id: 'fees', label: 'Fees & Scholarships' },
    { id: 'facilities', label: 'Campus Facilities' },
    { id: 'hostel', label: 'Hostel & Transportation' },
    { id: 'placements', label: 'Placements & Careers' },
    { id: 'campus-life', label: 'Campus Life & Clubs' },
    { id: 'events', label: 'Events & Notices' },
    { id: 'contact', label: 'Contact & Location' },
  ];

  const handleNavClick = (pageId) => {
    setActivePage(pageId);
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/98 dark:bg-slate-900/98 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-xs transition-colors duration-200">
      {/* Official Top Accent Border */}
      <div className="h-1.5 w-full bg-gradient-to-r from-[#091b33] via-[#2563eb] to-[#091b33]" />

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2 sm:gap-4">
          
          {/* Logo & Brand: Uses the exact official Presidency University emblem and typography */}
          <button 
            onClick={() => handleNavClick('home')}
            className="flex items-center text-left focus:outline-none group flex-shrink-0 cursor-pointer"
            title="Presidency University Bengaluru - Home"
          >
            <PresidencyLogo className="h-10 sm:h-12" light={theme === 'dark'} />
          </button>

          {/* Desktop Navigation Links: Cleanly aligned with equal line-height, flex-centering, and no wrapping */}
          <nav className="hidden xl:flex items-center gap-0.5 2xl:gap-1">
            {primaryLinks.map((link) => {
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  title={link.fullLabel || link.label}
                  className={`h-9 px-3 2xl:px-3.5 rounded-lg text-[12px] 2xl:text-[13px] font-semibold transition-all inline-flex items-center justify-center whitespace-nowrap cursor-pointer ${
                    isActive 
                      ? 'text-[#091b33] dark:text-blue-300 font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs' 
                      : 'text-slate-600 dark:text-slate-300 hover:text-[#091b33] dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/80'
                  }`}
                >
                  <span>{link.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Medium Screen (lg: 1024px-1279px) Streamlined Navigation with More dropdown */}
          <nav className="hidden lg:flex xl:hidden items-center gap-0.5">
            {primaryLinks.slice(0, 6).map((link) => {
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`h-8 px-2.5 rounded-md text-[11px] font-semibold transition inline-flex items-center justify-center whitespace-nowrap cursor-pointer ${
                    isActive 
                      ? 'text-[#091b33] dark:text-blue-300 font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700' 
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}

            {/* "More" Dropdown Menu for intermediate screens */}
            <div className="relative" ref={moreRef}>
              <button
                onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
                className="h-8 px-2 rounded-md text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition inline-flex items-center gap-1 cursor-pointer"
              >
                <span>More</span>
                <ChevronDown className={`w-3 h-3 transition-transform ${moreDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {moreDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                  {primaryLinks.slice(6).map((link) => (
                    <button
                      key={link.id}
                      onClick={() => handleNavClick(link.id)}
                      className={`w-full text-left px-3.5 py-2 text-xs font-semibold transition flex items-center justify-between cursor-pointer ${
                        activePage === link.id 
                          ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-900 dark:text-blue-200 font-bold' 
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/60'
                      }`}
                    >
                      <span>{link.fullLabel || link.label}</span>
                      {activePage === link.id && <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </nav>

          {/* Quick Actions & AI Chat Button */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            {/* Campus Map Button */}
            <button
              onClick={() => onOpenMap && onOpenMap()}
              className="h-9 flex items-center gap-1.5 px-2.5 sm:px-3 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
              title="Interactive Campus Map & Waypoints"
            >
              <Compass className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span className="hidden sm:inline">Campus Map</span>
            </button>

            {/* Quick Search Button */}
            <button
              onClick={onOpenSearch}
              className="h-9 flex items-center gap-1.5 px-2.5 sm:px-3 text-xs text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-700 transition focus:outline-none cursor-pointer"
              title="Search university information (Ctrl+K)"
            >
              <Search className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
              <span className="hidden md:inline font-medium">Search</span>
              <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[9px] font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded text-slate-400">
                ⌘K
              </kbd>
            </button>

            {/* Theme Toggle Button (Light/Dark Mode) */}
            {toggleTheme && (
              <button
                onClick={toggleTheme}
                className="h-9 w-9 flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                title={theme === 'dark' ? "Switch to Light Mode" : "Switch to Dark Mode"}
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4 text-amber-400 transition-transform duration-300 rotate-0 hover:rotate-45" />
                ) : (
                  <Moon className="w-4 h-4 text-slate-700 transition-transform duration-300 rotate-0 hover:-rotate-12" />
                )}
              </button>
            )}

            {/* College FAQ Chatbot Highlight Button */}
            <button
              onClick={onOpenAIChat}
              className="h-9 flex items-center gap-1.5 px-3 sm:px-3.5 rounded-lg text-xs font-bold bg-gradient-to-r from-[#091b33] to-[#163e72] hover:from-[#0d2346] hover:to-[#1a4985] text-white shadow-md hover:shadow-lg transition-all cursor-pointer border border-blue-400/40"
              title="Ask College FAQ Chatbot"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-300 animate-pulse" />
              <span className="hidden sm:inline">FAQ Bot</span>
              <span className="sm:hidden">FAQ</span>
            </button>

            {/* Mobile Drawer Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 pt-3 pb-6 max-h-[80vh] overflow-y-auto animate-in slide-in-from-top duration-200 shadow-xl">
          <div className="flex flex-col gap-1">
            <button
              onClick={() => {
                onOpenAIChat();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-4 py-3 rounded-xl text-sm font-bold bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-blue-700/15 dark:from-blue-900/30 dark:to-indigo-900/30 text-[#091b33] dark:text-blue-300 border border-blue-200 dark:border-blue-800 flex items-center justify-between mb-2 shadow-xs cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Ask College FAQ Chatbot</span>
              </span>
              <span className="text-[10px] bg-blue-600 text-white px-2 py-0.5 rounded-full font-bold uppercase">
                Interactive
              </span>
            </button>

            {/* Mobile Campus Map Link */}
            <button
              onClick={() => {
                if (onOpenMap) onOpenMap();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-semibold transition flex items-center justify-between text-blue-700 dark:text-blue-300 bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200/60 dark:border-blue-900/40 mb-1 cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Interactive Campus Map & Directions</span>
              </span>
              <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded font-mono">MAP</span>
            </button>

            {allNavLinks.map((link) => {
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-semibold transition flex items-center justify-between cursor-pointer ${
                    isActive 
                      ? 'bg-[#091b33] dark:bg-blue-900 text-white font-bold' 
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span>{link.label}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-blue-400"></span>}
                </button>
              );
            })}

            <div className="pt-4 mt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
              {/* Mobile Theme Toggle Button */}
              {toggleTheme && (
                <button
                  onClick={toggleTheme}
                  className="w-full py-2.5 px-3 text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg flex items-center justify-center gap-2 cursor-pointer transition"
                >
                  {theme === 'dark' ? (
                    <>
                      <Sun className="w-4 h-4 text-amber-400" />
                      <span>Switch to Light Theme</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-4 h-4 text-slate-700" />
                      <span>Switch to Dark Theme</span>
                    </>
                  )}
                </button>
              )}

              <a
                href="https://presidencyuniversity.in/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-center py-2 px-3 text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg flex items-center justify-center gap-1.5"
              >
                <span>Visit Main University Website</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <div className="text-center text-[11px] text-slate-400 dark:text-slate-500 pt-1">
                Presidency University Bengaluru • Itgalpur, Rajanakunte, Yelahanka
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
