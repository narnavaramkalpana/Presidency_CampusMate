---
marp: true
theme: default
paginate: true
header: "Presidency University • College FAQ Chatbot Presentation"
footer: "N Kalpana (20241cdv0043) & Poornima L (20241cdv0045) | CA-3 Cloud Computing"
style: |
  section {
    background-color: #091b33;
    color: #f8fafc;
    font-family: 'Segoe UI', system-ui, sans-serif;
    padding: 40px;
  }
  h1 { color: #60a5fa; }
  h2 { color: #93c5fd; border-bottom: 2px solid #3b82f6; padding-bottom: 8px; }
  h3 { color: #38bdf8; }
  strong { color: #fbbf24; }
  a { color: #60a5fa; text-decoration: none; }
  table { font-size: 14px; width: 100%; border-collapse: collapse; }
  th { background-color: #1e3a8a; color: #fff; padding: 8px; }
  td { background-color: #0f172a; border: 1px solid #334155; padding: 8px; }
  .badge { background: #2563eb; color: #fff; padding: 4px 10px; border-radius: 9999px; font-size: 12px; }
  .card { background: #0f172a; border: 1px solid #334155; border-radius: 12px; padding: 16px; margin: 10px 0; }
---

# 🎓 Building a FAQ Chatbot for a College Website
### Approved Sample Knowledge Base, Intent-Based Retrieval & Safe Fallbacks

**Course**: CDV3400 Cloud Computing • CA-3 Project  
**Institution**: Presidency University, Bengaluru  
**Live URL**: [https://campusmate-presidency.pages.dev/](https://campusmate-presidency.pages.dev/)  
**Interactive Slides**: [https://campusmate-presidency.pages.dev/presentation.html](https://campusmate-presidency.pages.dev/presentation.html)

**Project Team Members & Presenters:**
* 👤 **N Kalpana** — Roll Number: `20241cdv0043`
* 👤 **Poornima L** — Roll Number: `20241cdv0045`

> 💡 **Tip in VS Code**: Press **`Ctrl + Shift + V`** (or right-click tab ➔ **Open Preview**) to view this as styled slides!

---

## Slide 1: Executive Summary & Project Objectives

### Problem Context:
* **Large Campus Scale**: Presidency University spans **65+ acres** in Rajanakunte with **8 academic schools** and **80+ courses**.
* **Information Overload**: Essential details (B.Tech CSE DevOps fees, KCET/COMEDK criteria, bus routes, hostels) are buried inside 60-page PDF prospectuses.
* **The Danger of Public LLMs**: Generic models hallucinate fictional fees, wrong cutoff ranks, and nonexistent eligibility criteria.

### Our Solution:
* A **zero-hallucination College FAQ Chatbot** bound strictly to an approved **265-record sample knowledge base**.
* Instant natural language retrieval with **typo correction**, **conversational greetings/identity**, and **safe fallbacks**.
* Fully responsive on **mobile screens** with interactive **campus map navigation** and **voice interaction**.

---

## Slide 2: Project Architecture & Cloud Stack

```
┌──────────────────┐       ┌────────────────────────┐       ┌────────────────────────┐
│  Student User    │ ────> │ Cloudflare Pages CDN   │ ────> │ React 19 Client Engine │
│ (Mobile/Desktop) │       │ Global Edge Network    │       │ Vite 8 + Tailwind CSS  │
└──────────────────┘       └────────────────────────┘       └────────────────────────┘
                                                                        │
                                   ┌────────────────────────────────────┴────────────────┐
                                   ▼                                                     ▼
                     ┌───────────────────────────┐                         ┌───────────────────────────┐
                     │ Intent & NLP Preprocessor │                         │ TF-IDF & Fuzzy Cosine     │
                     │ Greetings, Synonyms, Typo │                         │ Similarity Vector Matcher │
                     └───────────────────────────┘                         └───────────────────────────┘
                                   │                                                     │
                                   └─────────────────┬───────────────────────────────────┘
                                                     ▼
                                     ┌───────────────────────────────┐
                                     │ Approved Knowledge Repository │
                                     │   265 Verified College FAQs   │
                                     └───────────────────────────────┘
```

* **Cloud Hosting**: Cloudflare Pages edge delivery (sub-50ms TTFB worldwide).
* **Performance**: Sub-5ms client-side retrieval with **zero backend server overhead** and **zero API costs**.
* **Reliability**: 100% deterministic and safe.

---

## Slide 3: Approved Sample Knowledge Base (265 Records)

The chatbot is backed by an approved, structured knowledge base covering all facets of university operations:

| Category | Record Count | Sample Inquiries Covered |
| :--- | :---: | :--- |
| **Courses & Degrees** | 42 | B.Tech CSE (Core, DevOps, AI&ML, Cyber), MBA, Law (BCI), BCA |
| **Fee Structure** | 38 | Program tuition, CSE DevOps special fees, installment options |
| **Admissions & Cutoffs** | 35 | KCET, COMEDK, PUALT, JEE eligibility, 2026-27 criteria |
| **Scholarships** | 22 | Merit-based concessions (up to 50% for 90%+ marks), sports |
| **Hostel & Amenities** | 28 | AC & Non-AC room types, mess dining menus, curfew timings |
| **Campus Life & Locations** | 36 | Dr. Kalam Central Library, Cafeterias, Sports Arena, Labs |
| **Transport & Commute** | 24 | 85+ bus routes across Bengaluru, passes, pickup spots |
| **Placements & Packages** | 25 | Highest package (₹13.58 LPA), 550+ recruiters, average CTC |
| **Administration** | 15 | Chancellor, UGC approval, AICTE, AIU membership, helplines |

---

## Slide 4: Retrieval Engine & Intent Matching

### Multi-Tiered Matching Pipeline:
1. **Conversational Intent Interceptor**:
   * Instant responses for greetings (`hi`, `hello`, `good morning`), identity/authors (`who are you`, `who made you`), overview (`about university`), gratitude (`thanks`), and help.
2. **Domain Normalization & Typo Tolerance**:
   * Corrects misspellings before scoring:
     * `fess` / `feee` ➔ `fees`
     * `dev ops` / `dev-ops` ➔ `devops`
     * `palcements` / `placmnt` ➔ `placement`
     * `hostle` ➔ `hostel`
     * `cafetria` ➔ `cafeteria`
3. **Synonym Expansion Matrix**:
   * Automatically expands terms (e.g. `cost`, `tuition`, `charge` ➔ `fees`; `canteen`, `food court` ➔ `cafeteria`).
4. **Weighted Question & Keyword Scoring**:
   * Evaluates exact titles, fuzzy token matches, and keyword tag intersections.

---

## Slide 5: Safe Fallback & Zero-Hallucination Guardrails

### Core Philosophy: "Accuracy Over Speculation"

* When a user query falls below the confidence cutoff (e.g., asking unverified personal gossip or unlisted outside data):
  1. The bot **never invents** fake numbers, fake dates, or nonexistent policies.
  2. Clearly states that the record is not found in the verified college database.
  3. Provides structured suggestions to guide the student to popular valid queries.
  4. Provides direct handoff to the official university helpline:
     * 📞 **Admissions Helpline**: `+91 90220 92222` / `080 4925 5555`
     * ✉️ **Admissions Email**: `admission@presidencyuniversity.in`
     * 🌐 **Official Portal**: `https://presidencyuniversity.in/`

---

## Slide 6: Mobile-First UX & Interactive Campus Navigation

### 1. Mobile Modal Optimization:
* **Full-Screen Responsive View**: Uses `100dvh` (dynamic viewport height) on smartphones, eliminating clipping when virtual keyboards open.
* **Safe-Area Inset Support**: `pb-[max(env(safe-area-inset-bottom),12px)]` ensures iPhone/Android bottom navigation bars do not obscure controls.
* **iOS Zoom Fix**: `text-base` (16px) font prevents unwanted auto-zooming in Safari.
* **Touch-Friendly Controls**: 44px+ touch targets and dedicated mobile `<ArrowLeft />` back button.

### 2. Interactive Campus Map Hub:
* Interactive SVG map of the 65-acre campus with 10 key waypoints:
  * Central Library • Multi-Cuisine Cafeteria • Admin Block A • Student Hostels • Engineering Labs
* Direct **"View on Interactive Campus Map"** trigger buttons embedded directly in location answers.

---

## Slide 7: Voice Interaction (Speech-to-Text & Text-to-Speech)

### Accessibility Through Web Speech APIs:

1. **Speech-to-Text (Voice Input)**:
   * Uses `window.SpeechRecognition` / `webkitSpeechRecognition`.
   * Real-time transcription with Indian English (`en-IN`) acoustic models.
   * Visual pulsing microphone indicator with instant query execution.

2. **Text-to-Speech (Audio Playback)**:
   * Uses `window.speechSynthesis`.
   * Automatically strips markdown syntax symbols (`*`, `#`, `•`) for natural voice pronunciation.
   * Play / Stop toggle on every assistant response card for auditory learners and visually impaired visitors.

---

## Slide 8: Live System Demonstration & Test Queries

Run these queries live at **[https://campusmate-presidency.pages.dev/](https://campusmate-presidency.pages.dev/)**:

| Query Tested | Expected Engine Behavior | Verified Result |
| :--- | :--- | :---: |
| `hi` / `hello` | Friendly greeting with suggested prompt chips | ✅ PASS |
| `who are you` | Authors (N Kalpana & Poornima L) + CA-3 project details | ✅ PASS |
| `about university` | 65-acre campus overview, UGC, AICTE, schools & rankings | ✅ PASS |
| `what is the fess structure cor cse core devops` | Handles 3 typos (`fess`, `cor`, `devops`) and returns B.Tech CSE DevOps fees | ✅ PASS |
| `where is the cafeteria` | Directions + interactive campus map waypoint link | ✅ PASS |
| `highest placement package` | Returns ₹13.58 LPA package and top recruiters | ✅ PASS |
| `what is the fee for medical college` | Safe fallback response (Presidency has no medical school) | ✅ PASS |

---

## Slide 9: Team Contributions & Work Division

| Task / Module | Primary Contributor | Description |
| :--- | :---: | :--- |
| **Knowledge Base Engineering** | **N Kalpana** | Curated & validated 265 college FAQs across courses, fees, and admissions. |
| **Intent Retrieval & NLP Engine** | **Poornima L** | Implemented tokenization, synonym dictionary, and fuzzy Levenshtein matching. |
| **Mobile Modal & UI Redesign** | **N Kalpana** | Built mobile-first full-screen modal, safe-area padding, and touch UX. |
| **Voice APIs & Campus Navigation** | **Poornima L** | Integrated Web Speech API (STT/TTS) and interactive SVG campus map waypoints. |
| **Cloud Deployment & Testing** | **Both** | Deployed on Cloudflare Pages, automated 27/27 regression test cases. |

---

## Slide 10: Conclusion & Project Links

### Summary of Achievements:
* Delivered an intelligent, student-friendly AI assistant strictly adhering to university records.
* Achieved **100% verified accuracy** with **zero hallucinated fees or criteria**.
* Sub-5ms client-side response speed with zero third-party cloud costs.
* Fully accessible across mobile, tablet, desktop, and voice.

### Project Resources:
* 🌐 **Live Application**: [https://campusmate-presidency.pages.dev/](https://campusmate-presidency.pages.dev/)
* 🖥️ **Web Presentation Slides**: [https://campusmate-presidency.pages.dev/presentation.html](https://campusmate-presidency.pages.dev/presentation.html)
* 📑 **Markdown Deck**: `PRESENTATION_SLIDES.md` (Open with `Ctrl + Shift + V` in VS Code)
* 📊 **PowerPoint File**: `College_FAQ_Chatbot_Presentation.pptx`

---
*Presidency University • School of Computer Science and Engineering • CA-3 Evaluation*
