import json

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    text = f.read()

# find ID 240 and ID 13
import re
p240 = re.search(r'\{\s*"id":\s*240,\s*"question":\s*"([^"]+)",\s*"answer":\s*"([^"]+)"', text)
if p240:
    print("Q240:", p240.group(1))
    print("A240:", p240.group(2))

p13 = re.search(r'\{\s*"id":\s*13,\s*"question":\s*"([^"]+)",\s*"answer":\s*"([^"]+)"', text)
if p13:
    print("Q13:", p13.group(1))
    print("A13:", p13.group(2))
