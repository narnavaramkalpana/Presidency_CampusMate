// Complete Verified University Knowledge Database for CampusMate AI
// Presidency University, Bengaluru (Established 2013, Karnataka Act No. 41 of 2013)
// Total verified records: 238

export const universityDatabase = [
  {
    "id": 1,
    "question": "What is Presidency University, Bengaluru?",
    "answer": "Presidency University, Bengaluru is a premier private university established in Karnataka by the Presidency Group of Institutions under the Presidency University Act, 2013 (Karnataka Act No. 41 of 2013). It is approved by AICTE, recognized by UGC under Section 2(f), and is a member of the Association of Indian Universities (AIU).",
    "category": "University overview",
    "keywords": [
      "presidency university",
      "overview",
      "what is",
      "about",
      "bengaluru",
      "karnataka",
      "ugc",
      "aicte"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 2,
    "question": "Is Presidency University recognized by UGC and approved by AICTE?",
    "answer": "Yes, Presidency University Bengaluru is fully recognized by the University Grants Commission (UGC) under section 2(f) of the UGC Act, 1956, and its engineering and technical programs are approved by the All India Council for Technical Education (AICTE), New Delhi.",
    "category": "University overview",
    "keywords": [
      "ugc recognition",
      "aicte approval",
      "accreditation",
      "validity",
      "govt recognized",
      "statutory approvals"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 3,
    "question": "Who is the Chancellor of Presidency University?",
    "answer": "Dr. Nissar Ahmed is the Founder-Chairman of Presidency Group of Institutions and the Chancellor of Presidency University Bengaluru. He is a prominent educationist and visionary leader who has steered the institution for nearly five decades.",
    "category": "University overview",
    "keywords": [
      "chancellor",
      "dr nissar ahmed",
      "founder",
      "chairman",
      "leadership"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 4,
    "question": "What is the motto and vision of Presidency University?",
    "answer": "The motto of Presidency University is 'Gain More Knowledge, Reach Greater Heights'. Its vision is to be an innovative, research-driven, and value-oriented university dedicated to imparting quality global education and creating socially responsible leaders.",
    "category": "University overview",
    "keywords": [
      "motto",
      "vision",
      "mission",
      "values",
      "goals",
      "aim"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 5,
    "question": "What is the legacy of the Presidency Group of Institutions (PGI)?",
    "answer": "Presidency Group of Institutions was founded in 1976 and spans over 48 years of academic excellence. It encompasses multiple pre-university colleges, K-12 schools across Bangalore and Mangalore, and Presidency College (Hebbal), educating over 50,000 students.",
    "category": "University overview",
    "keywords": [
      "presidency group of institutions",
      "pgi",
      "legacy",
      "1976",
      "history",
      "sister schools"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 6,
    "question": "What awards and rankings has Presidency University received?",
    "answer": "Presidency University has been ranked among the top emerging universities and private engineering colleges in South India by prestigious surveys including Times Engineering, Education World, India Today, and Competition Success Review (CSR).",
    "category": "University overview",
    "keywords": [
      "rankings",
      "awards",
      "times ranking",
      "nirf",
      "accolades",
      "rating"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 7,
    "question": "When was Presidency University established?",
    "answer": "Presidency University Bengaluru was established in 2013 under the Presidency University Act, 2013 passed by the Karnataka State Legislature (Karnataka Act No. 41 of 2013).",
    "category": "History and establishment",
    "keywords": [
      "establishment",
      "founded",
      "year 2013",
      "karnataka act 41",
      "legislation"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 8,
    "question": "Under which Act was Presidency University constituted?",
    "answer": "Presidency University was constituted by the Karnataka Act No. 41 of 2013, notified by the Government of Karnataka in the Karnataka Gazette.",
    "category": "History and establishment",
    "keywords": [
      "act 41",
      "karnataka act",
      "constitution",
      "gazette notification",
      "legal status"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 9,
    "question": "How did Presidency Group evolve into Presidency University?",
    "answer": "Starting with a single school in 1976, Presidency Group built premier institutions like Presidency College, Hebbal (re-accredited NAAC 'A+'). Recognizing its outstanding track record, the Government of Karnataka sanctioned the establishment of Presidency University in 2013.",
    "category": "History and establishment",
    "keywords": [
      "evolution",
      "growth",
      "heritage",
      "from school to university",
      "milestones"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 10,
    "question": "Is Presidency University a private or deemed university?",
    "answer": "Presidency University is a State Private University enacted by the Karnataka Legislative Assembly under Act No. 41 of 2013, empowering it to award its own degrees recognized across India and internationally.",
    "category": "History and establishment",
    "keywords": [
      "private university",
      "state university",
      "deemed",
      "degree awarding power"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 11,
    "question": "Where did the Presidency Group start its educational journey?",
    "answer": "The journey began in Bengaluru in 1976 with primary education, expanding into Pre-University education, undergraduate collegiate degrees in Hebbal, and culminating in the 65+ acre university campus at Rajanakunte.",
    "category": "History and establishment",
    "keywords": [
      "origin",
      "1976 origin",
      "hebbal campus",
      "foundational journey"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 12,
    "question": "What is the institutional motto and founding philosophy?",
    "answer": "The founding philosophy focuses on holistic student transformation through learner-centric pedagogy, international collaborations, ethical values, and industry readiness.",
    "category": "History and establishment",
    "keywords": [
      "philosophy",
      "founding principles",
      "holistic education"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 13,
    "question": "Where is Presidency University campus located?",
    "answer": "Presidency University Bengaluru is located at **Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064, Karnataka, India**.\n\nKey location details & distances:\n• **Highway / Road**: Situated on Doddaballapur Main Road (State Highway 9), approximately 12 km from Yelahanka New Town.\n• **From Kempegowda International Airport (BLR)**: ~28 km (approx. 35–45 minutes drive via SH-9 / airport bypass).\n• **From Majestic (KSR Bengaluru Railway Station)**: ~30 km (connected via BMTC buses and university bus routes).\n• **City Admissions Office**: University House, 8/1, King Street, Richmond Town, Bengaluru – 560025.\n\n[📍 Open Campus Location on Google Maps](https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru) • [🧭 Live Turn-by-Turn Navigation](https://www.google.com/maps/dir/?api=1&destination=Presidency+University+Bengaluru)",
    "category": "Location and campus",
    "keywords": [
      "location",
      "address",
      "where is",
      "itgalpur",
      "rajanakunte",
      "yelahanka",
      "bengaluru",
      "pincode",
      "google maps",
      "map",
      "directions to campus",
      "how to reach university",
      "campus directions",
      "navigation"
    ],
    "sourceUrl": "https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru",
    "sourceTitle": "Google Maps – Presidency University Bengaluru",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 14,
    "question": "How large is the Presidency University campus?",
    "answer": "Presidency University Bengaluru is set amidst a sprawling, lush green 65+ acre campus equipped with modern architectural academic blocks, advanced research laboratories, open-air amphitheaters, sports complexes, and student residential zones.",
    "category": "Location and campus",
    "keywords": [
      "campus size",
      "65 acres",
      "campus area",
      "green campus",
      "infrastructure"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 15,
    "question": "Where is the Presidency University City Admissions Office located?",
    "answer": "The City Admissions Office is located at University House, 8/1, King Street, Richmond Town, Bengaluru \u2013 560025, Karnataka, India.",
    "category": "Location and campus",
    "keywords": [
      "city office",
      "richmond town",
      "king street",
      "urban center",
      "city admissions"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 16,
    "question": "How far is Presidency University from Kempegowda International Airport (BLR)?",
    "answer": "The university campus in Rajanakunte is approximately 28 km from Kempegowda International Airport (BLR), Devanahalli, Bengaluru, and can be reached in about 35\u201345 minutes via the NH 44 / State Highway 9 route.",
    "category": "Location and campus",
    "keywords": [
      "airport distance",
      "kempegowda airport",
      "blr distance",
      "travel time",
      "flight connectivity"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 17,
    "question": "How far is Presidency University from Majestic (KSR Bengaluru) Railway Station?",
    "answer": "The campus is approximately 30 km from KSR Bengaluru (Majestic) City Railway Station and Kempegowda Bus Station. Dedicated university buses and BMTC public buses ply regularly between Majestic/Hebbal and Rajanakunte.",
    "category": "Location and campus",
    "keywords": [
      "majestic distance",
      "railway station",
      "ksr distance",
      "bus connectivity"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 18,
    "question": "Is public transportation available to Presidency University campus?",
    "answer": "Yes, BMTC buses regularly run from Yelahanka, Majestic, and Hebbal toward Doddaballapur with stops at Rajanakunte. The university also operates a dedicated feeder shuttle between Rajanakunte bus stop / railway station and the campus entrance.",
    "category": "Location and campus",
    "keywords": [
      "public transport",
      "bmtc",
      "shuttle",
      "rajanakunte stop",
      "train to rajanakunte"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 19,
    "question": "What are the key landmarks near Presidency University?",
    "answer": "Key landmarks include Rajanakunte Railway Station, Marasandra Circle, Yelahanka Air Force Station, and Ramanashree California Resort on Doddaballapur Road.",
    "category": "Location and campus",
    "keywords": [
      "landmarks",
      "nearby places",
      "marasandra",
      "yelahanka landmarks"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 20,
    "question": "What schools and faculties exist at Presidency University Bengaluru?",
    "answer": "Presidency University operates through 9 specialized schools: School of Engineering (SOE), School of Management (SOM), School of Law (SOL), School of Design (SOD), School of Computer Science & Information Science, School of Commerce (SOC), School of Media Studies, School of Allied Health Sciences, and School of Basic Sciences & Humanities.",
    "category": "Courses and departments",
    "keywords": [
      "schools",
      "faculties",
      "departments",
      "soe",
      "som",
      "sol",
      "sod",
      "all schools"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 21,
    "question": "What courses are offered by the School of Engineering (SOE)?",
    "answer": "The School of Engineering offers 4-year B.Tech programs in Computer Science & Engineering (CSE), Artificial Intelligence & Machine Learning (AI & ML), Data Science, Cyber Security, Blockchain & IoT, Information Science, Electronics & Communication (ECE), Electrical & Electronics (EEE), Mechanical Engineering, Mechatronics, Petroleum Engineering, and Civil Engineering, plus M.Tech and Ph.D. programs.",
    "category": "Courses and departments",
    "keywords": [
      "engineering courses",
      "btech branches",
      "soe",
      "cse",
      "ece",
      "mechatronics",
      "petroleum"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 22,
    "question": "What courses are offered by the School of Management (SOM)?",
    "answer": "The School of Management offers MBA (Master of Business Administration) with diverse dual specializations, and Undergraduate BBA programs in General Management, Aviation Management, Business Analytics, Digital Marketing, and Supply Chain Management.",
    "category": "Courses and departments",
    "keywords": [
      "management courses",
      "mba",
      "bba",
      "som",
      "aviation",
      "business analytics"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 23,
    "question": "What courses are offered by the School of Law (SOL)?",
    "answer": "The School of Law is approved by the Bar Council of India (BCI) and offers 5-year integrated law degrees: B.A. LL.B. (Hons.), B.B.A. LL.B. (Hons.), B.Com. LL.B. (Hons.), 1-year LL.M. (Master of Laws) in Intellectual Property Rights & Corporate Law, and Ph.D. in Law.",
    "category": "Courses and departments",
    "keywords": [
      "law courses",
      "sol",
      "bci approved",
      "ba llb",
      "bba llb",
      "llm",
      "law honors"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 24,
    "question": "What programs are offered by the School of Design (SOD)?",
    "answer": "The School of Design offers 4-year Bachelor of Design (B.Des) programs in Product Design, Fashion Design, Communication Design, Game Design & Augmented Reality, and Space / Interior Design.",
    "category": "Courses and departments",
    "keywords": [
      "design courses",
      "bdes",
      "sod",
      "fashion design",
      "product design",
      "game design"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 25,
    "question": "What programs are offered by the School of Allied Health Sciences?",
    "answer": "The School of Allied Health Sciences offers 3 to 4-year B.Sc. programs in Medical Laboratory Technology (MLT), Anesthesia and Operation Theatre Technology, Medical Imaging Technology (Radiology), Optometry, Renal Dialysis Technology, and Cardiac Care Technology.",
    "category": "Courses and departments",
    "keywords": [
      "allied health",
      "medical technology",
      "paramedical",
      "mlt",
      "dialysis",
      "radiology",
      "optometry"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 26,
    "question": "Does Presidency University offer BCA and MCA programs?",
    "answer": "Yes, through the School of Computer Science & Information Science, Presidency University offers a 3-year BCA (Bachelor of Computer Applications) with tracks in AI/ML, Cloud Computing, and Cyber Security, as well as a 2-year MCA (Master of Computer Applications) program.",
    "category": "Courses and departments",
    "keywords": [
      "bca",
      "mca",
      "computer applications",
      "it courses",
      "bca cloud",
      "mca admission"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 27,
    "question": "What B.Tech specializations are available in Computer Science?",
    "answer": "Under Computer Science, Presidency University offers B.Tech in: (1) Computer Science and Engineering (CSE), (2) CSE with AI & Machine Learning, (3) CSE with Data Science, (4) CSE with Cyber Security, (5) CSE with Internet of Things (IoT), and (6) Information Science and Engineering (ISE).",
    "category": "Undergraduate programs",
    "keywords": [
      "btech cse specializations",
      "cse ai ml",
      "cse data science",
      "cse cyber security",
      "btech cse options"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 28,
    "question": "What is the duration of undergraduate B.Tech programs?",
    "answer": "The B.Tech program is a 4-year, 8-semester full-time degree program. For diploma holders admitted via lateral entry directly into the second year, the duration is 3 years (6 semesters).",
    "category": "Undergraduate programs",
    "keywords": [
      "btech duration",
      "4 years",
      "semesters",
      "lateral entry duration"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 29,
    "question": "What undergraduate business and commerce degrees are offered?",
    "answer": "Presidency University offers BBA (General, Aviation, Business Analytics, Digital Marketing), B.Com (Honours), B.Com (Banking & Finance), and B.Com (Corporate Accounting & Taxation). All these are 3-year full-time undergraduate degree courses.",
    "category": "Undergraduate programs",
    "keywords": [
      "ug commerce",
      "ug business",
      "bba programs",
      "bcom honors",
      "bcom banking"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 30,
    "question": "What is the duration and structure of 5-year Integrated Law degrees?",
    "answer": "The B.A. LL.B. (Hons.), B.B.A. LL.B. (Hons.), and B.Com. LL.B. (Hons.) are 5-year integrated law programs divided into 10 semesters. They incorporate continuous moot court training, legal aid clinics, judicial internships, and law seminars approved by BCI.",
    "category": "Undergraduate programs",
    "keywords": [
      "5 year law",
      "integrated law",
      "ba llb duration",
      "bba llb",
      "moot court"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 31,
    "question": "Does Presidency University offer B.Sc. in Forensic Science or Biotechnology?",
    "answer": "Yes, the School of Basic Sciences & Humanities offers a 3-year B.Sc. in Forensic Science and a B.Sc. in Biotechnology, featuring modern forensic laboratories, crime scene simulation setups, and biotechnology bio-safety hoods.",
    "category": "Undergraduate programs",
    "keywords": [
      "bsc forensic science",
      "bsc biotechnology",
      "sciences ug",
      "crime lab"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 32,
    "question": "What is the curriculum structure for B.Des (Bachelor of Design)?",
    "answer": "The B.Des program spans 4 years (8 semesters). The first year covers foundation in visual arts, design thinking, and material exploration, followed by 3 years of disciplinary specializations in Product, Fashion, Communication, or Game Design with industry internships.",
    "category": "Undergraduate programs",
    "keywords": [
      "bdes curriculum",
      "design degree structure",
      "design foundation"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 33,
    "question": "What programs does the School of Media Studies offer for undergraduates?",
    "answer": "The School of Media Studies offers a 3-year B.A. in Journalism and Mass Communication, covering print journalism, television broadcasting, digital media, podcasting, public relations, and advertising with a dedicated media studio.",
    "category": "Undergraduate programs",
    "keywords": [
      "media studies",
      "journalism degree",
      "ba mass comm",
      "media production"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 34,
    "question": "What specializations are available in MBA at Presidency University?",
    "answer": "The 2-year MBA program at Presidency University offers dual specializations in Marketing, Finance, Human Resource Management (HRM), Business Analytics, Operations & Supply Chain Management, Digital Marketing, and Banking & Financial Services.",
    "category": "Postgraduate programs",
    "keywords": [
      "mba specializations",
      "dual specialization",
      "mba marketing",
      "mba finance",
      "mba hr",
      "mba analytics"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 35,
    "question": "What M.Tech programs are offered at Presidency University?",
    "answer": "Presidency University offers 2-year M.Tech programs in Computer Science & Engineering, Artificial Intelligence, Data Science, Embedded Systems & VLSI, and Product Design & Manufacturing.",
    "category": "Postgraduate programs",
    "keywords": [
      "mtech courses",
      "mtech cse",
      "mtech vlsi",
      "mtech ai",
      "postgraduate engineering"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 36,
    "question": "What is the duration and focus of the LL.M. program?",
    "answer": "The LL.M. is a 1-year postgraduate master's degree in Law offered in specializations like Intellectual Property Rights (IPR) and Corporate & Commercial Laws, aimed at legal research, academic careers, and corporate legal consulting.",
    "category": "Postgraduate programs",
    "keywords": [
      "llm",
      "master of laws",
      "1 year llm",
      "ipr law",
      "corporate law masters"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 37,
    "question": "Does Presidency University offer Ph.D. programs?",
    "answer": "Yes, Presidency University offers Full-Time and Part-Time Ph.D. doctoral programs across Engineering, Management, Commerce, Law, Physics, Chemistry, Mathematics, and Humanities under UGC norms.",
    "category": "Postgraduate programs",
    "keywords": [
      "phd",
      "doctoral",
      "research programs",
      "phd engineering",
      "phd management",
      "phd law"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 38,
    "question": "What M.Sc. programs are offered at Presidency University?",
    "answer": "The university offers 2-year M.Sc. programs in Physics, Chemistry (Organic & Analytical), Applied Mathematics, and Biotechnology.",
    "category": "Postgraduate programs",
    "keywords": [
      "msc courses",
      "msc chemistry",
      "msc physics",
      "msc biotechnology",
      "msc mathematics"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 39,
    "question": "What is the structure of the MCA (Master of Computer Applications) program?",
    "answer": "The MCA program is a 2-year (4-semester) post-graduate program emphasizing advanced software architecture, cloud platforms, full-stack application development, AI integrations, and an industry project in the final semester.",
    "category": "Postgraduate programs",
    "keywords": [
      "mca program",
      "master of computer applications",
      "mca syllabus",
      "pg computer science"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 40,
    "question": "What is the overall admission process at Presidency University?",
    "answer": "The admission process involves: 1) Online registration and form submission; 2) Submitting academic scores and qualifying entrance test results; 3) Evaluation by the Admissions Committee (with Personal Interview / Design Aptitude where required); 4) Provisional Admission Offer letter generation; 5) Verification of documents and initial fee payment to secure seat.",
    "category": "Admission process",
    "keywords": [
      "admission process",
      "how to get admission",
      "steps for admission",
      "admission procedure"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 41,
    "question": "Which entrance examinations are accepted for B.Tech admission?",
    "answer": "For B.Tech, Presidency University accepts scores from: Karnataka CET (KCET), COMEDK UGET, JEE Main, or the Presidency University Evaluation Test / Merit Assessment.",
    "category": "Admission process",
    "keywords": [
      "btech entrance exam",
      "kcet",
      "comedk",
      "jee main",
      "accepted tests"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 42,
    "question": "Which entrance examinations are accepted for MBA admission?",
    "answer": "For MBA, Presidency University accepts Karnataka PGCET, CAT, MAT, XAT, CMAT, ATMA, or KMAT scores, followed by a personal interview / micro-presentation round.",
    "category": "Admission process",
    "keywords": [
      "mba entrance exam",
      "pgcet",
      "cat",
      "mat",
      "xat",
      "cmat",
      "kmat"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 43,
    "question": "Which entrance exams are accepted for School of Law admissions?",
    "answer": "School of Law accepts Common Law Admission Test (CLAT), LSAT-India, or the Presidency University Law Admission Test (PULAT), along with candidate performance in 10+2.",
    "category": "Admission process",
    "keywords": [
      "law entrance exam",
      "clat",
      "lsat india",
      "pulat",
      "law admission"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 44,
    "question": "What is the admission procedure for the School of Design (B.Des)?",
    "answer": "Applicants must qualify 10+2 and clear the Presidency University Design Aptitude Test (DAT) / UCEED score, followed by a Portfolio Presentation and personal interview.",
    "category": "Admission process",
    "keywords": [
      "bdes admission",
      "design entrance",
      "dat",
      "uceed",
      "portfolio review"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 45,
    "question": "Can I apply for direct admission through Management Quota?",
    "answer": "Yes, Presidency University offers direct admissions through the Institutional / Management Quota for eligible students meeting university academic cut-offs. Candidates can apply online or visit the campus admission desk.",
    "category": "Admission process",
    "keywords": [
      "management quota",
      "direct admission",
      "institutional quota",
      "seat booking"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 46,
    "question": "Is lateral entry available for B.Tech programs?",
    "answer": "Yes, diploma holders in engineering or B.Sc. graduates with Mathematics with at least 45% aggregate (40% for SC/ST/OBC Karnataka) can apply for Lateral Entry directly into the 2nd year (3rd semester) of B.Tech.",
    "category": "Admission process",
    "keywords": [
      "lateral entry",
      "btech lateral entry",
      "diploma to btech",
      "3rd semester admission"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 47,
    "question": "What is the eligibility criteria for B.Tech Computer Science and Engineering (CSE)?",
    "answer": "Candidates must have passed 10+2 (PUC / CBSE / ISC or equivalent) with at least 45% aggregate marks (40% for Karnataka SC/ST/OBC) in Physics and Mathematics as compulsory subjects, along with Chemistry, Biotechnology, Biology, Computer Science, or Electronics.",
    "category": "Eligibility requirements",
    "keywords": [
      "eligibility btech cse",
      "percentage required for cse",
      "12th marks for engineering",
      "puc cut off"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 48,
    "question": "What is the eligibility criteria for MBA at Presidency University?",
    "answer": "Candidates must hold a Bachelor's Degree of minimum 3-year duration from a recognized university with an aggregate of at least 50% marks (45% for Karnataka SC/ST/OBC candidates) and a valid entrance score (PGCET/CAT/MAT/KMAT/CMAT).",
    "category": "Eligibility requirements",
    "keywords": [
      "mba eligibility",
      "graduation marks for mba",
      "mba cutoff",
      "bachelor degree percentage"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 49,
    "question": "What is the eligibility for 5-Year Integrated Law (BA LLB / BBA LLB / B.Com LLB)?",
    "answer": "Candidates must have passed 10+2 / PUC or equivalent examination from a recognized board with a minimum of 45% aggregate marks (40% for SC/ST candidates). The maximum age limit conforms to Bar Council of India regulations.",
    "category": "Eligibility requirements",
    "keywords": [
      "law eligibility",
      "ba llb marks",
      "bci age limit",
      "12th marks for law"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 50,
    "question": "What is the eligibility criteria for BBA and B.Com programs?",
    "answer": "Candidates must have passed 10+2 / Karnataka PUC / CBSE / ISC or equivalent examination in any stream (Commerce, Science, or Arts) from a recognized board with a minimum aggregate of 45% to 50%.",
    "category": "Eligibility requirements",
    "keywords": [
      "bba eligibility",
      "bcom eligibility",
      "12th commerce percentage",
      "puc commerce criteria"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 51,
    "question": "What is the eligibility criteria for BCA (Bachelor of Computer Applications)?",
    "answer": "Candidates must have passed 10+2 / PUC or equivalent examination with a minimum of 45% aggregate marks with Mathematics, Computer Science, Statistics, or Business Mathematics as one of the preferred subjects.",
    "category": "Eligibility requirements",
    "keywords": [
      "bca eligibility",
      "bca math required",
      "bca 12th percentage",
      "computer applications eligibility"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 52,
    "question": "What is the eligibility criteria for Allied Health Sciences (B.Sc. MLT, Imaging, etc.)?",
    "answer": "Candidates must have completed 10+2 / PUC with Physics, Chemistry, and Biology (PCB) as mandatory subjects with a minimum of 45% to 50% aggregate marks from a recognized board.",
    "category": "Eligibility requirements",
    "keywords": [
      "allied health eligibility",
      "bsc mlt criteria",
      "pcb required",
      "paramedical eligibility"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 53,
    "question": "What is the eligibility criteria for M.Tech admissions?",
    "answer": "Candidates must hold a B.E. / B.Tech degree in a relevant discipline from an AICTE/UGC recognized university with not less than 50% aggregate marks (45% for Karnataka SC/ST/OBC candidates). A valid GATE or Karnataka PGCET score is preferred.",
    "category": "Eligibility requirements",
    "keywords": [
      "mtech eligibility",
      "gate score",
      "pgcet engineering",
      "btech percentage for mtech"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 54,
    "question": "How can I apply online for Presidency University admissions?",
    "answer": "You can apply online via the official university website: 1) Visit https://presidencyuniversity.in/ and click on 'Apply Now'; 2) Register with your active email address and mobile number; 3) Fill in personal and educational details; 4) Upload required scanned documents; 5) Pay the application registration fee online.",
    "category": "Application procedure",
    "keywords": [
      "how to apply",
      "online application",
      "apply now",
      "registration step",
      "admission portal"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 55,
    "question": "What is the application fee for Presidency University programs?",
    "answer": "The application fee is typically \u20b91,000 to \u20b91,250 (non-refundable), payable online using Credit Card, Debit Card, Net Banking, or UPI through the secure payment gateway on the portal.",
    "category": "Application procedure",
    "keywords": [
      "application fee",
      "form cost",
      "how much is application",
      "fee payment mode"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 56,
    "question": "Can I visit the campus in person to submit my application?",
    "answer": "Yes, applicants and parents can visit the Admissions Office directly at the Rajanakunte campus or the City Admissions Office at Richmond Town, Bengaluru, to purchase the prospectus, submit physical forms, and receive personalized counseling.",
    "category": "Application procedure",
    "keywords": [
      "walk in admission",
      "offline application",
      "visit campus for form",
      "counseling desk"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 57,
    "question": "Can I track my application status online?",
    "answer": "Yes, once registered, applicants receive a unique Application ID and password. By logging into the Presidency University applicant dashboard, you can track form submission, payment receipt, interview scheduling, and offer status.",
    "category": "Application procedure",
    "keywords": [
      "track application",
      "application status",
      "applicant portal login",
      "admission tracking"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 58,
    "question": "Can international students or NRI candidates apply?",
    "answer": "Yes, Presidency University has an International & NRI Admissions Desk. Candidates with foreign qualifications must provide an Equivalence Certificate from the Association of Indian Universities (AIU) and a valid passport/visa.",
    "category": "Application procedure",
    "keywords": [
      "international admissions",
      "nri quota",
      "aiu equivalence",
      "foreign students"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 59,
    "question": "What happens after I receive a Provisional Admission Offer?",
    "answer": "Upon receiving the provisional offer letter, the candidate must pay the prescribed initial seat confirmation fee by the deadline stated in the letter to reserve the seat in their desired program.",
    "category": "Application procedure",
    "keywords": [
      "provisional offer",
      "seat confirmation",
      "offer letter acceptance",
      "reserve seat"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 60,
    "question": "When do admissions open and close for the academic year 2026\u20132027?",
    "answer": "Admissions generally open in November/December for early rounds and continue through July/August depending on state entrance results (KCET/PGCET). It is strongly advised to apply early as high-demand branches like B.Tech CSE fill up fast.",
    "category": "Admission deadlines",
    "keywords": [
      "admission dates",
      "application deadline",
      "last date to apply",
      "2026 admissions",
      "closing date"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 61,
    "question": "What is the reporting date for newly admitted first-year students?",
    "answer": "Orientation programs and commencement of classes for first-year undergraduate and postgraduate cohorts typically begin in August/September, as notified in the official academic calendar.",
    "category": "Admission deadlines",
    "keywords": [
      "orientation date",
      "class start date",
      "reporting date",
      "academic calendar"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 62,
    "question": "Are admissions open on rolling rounds?",
    "answer": "Yes, early admissions proceed in phased cycles (Phase 1, Phase 2, and Phase 3). Early phase applicants often have access to higher merit scholarship allocations and branch priority.",
    "category": "Admission deadlines",
    "keywords": [
      "admission phases",
      "rolling admissions",
      "early bird rounds",
      "seat availability"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 63,
    "question": "What is the deadline for fee balance payment after seat booking?",
    "answer": "The balance tuition fee must be paid before the commencement of the academic session or orientation day, as specified in the provisional admission letter.",
    "category": "Admission deadlines",
    "keywords": [
      "fee payment deadline",
      "balance fee date",
      "orientation deadline"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 64,
    "question": "When do KCET and COMEDK counseling allotments report to campus?",
    "answer": "Students allotted seats through KEA (KCET) or COMEDK counseling must report to the campus within the dates specified on their respective admission allotment order with original documents.",
    "category": "Admission deadlines",
    "keywords": [
      "kea reporting date",
      "kcet allotment deadline",
      "comedk reporting window"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 239,
    "question": "What is the fee structure across courses at Presidency University?",
    "answer": "Here is the verified fee structure across key programs at Presidency University Bengaluru:\n\n• B.Tech Engineering: ₹2,50,000 to ₹3,50,000 per year (Management Quota, higher for CSE/AI specializations); approx ₹1,00,000 to ₹1,15,000/year for KCET government quota seats.\n• MBA (School of Management): ₹6,00,000 to ₹9,00,000 total for the 2-year program (subsidized for PGCET quota).\n• BBA & BCA: ₹1,30,000 to ₹2,00,000 per year depending on specialization (Aviation, AI, Analytics).\n• School of Law (BA LLB / BBA LLB): Approx ₹1,50,000 to ₹2,25,000 per year (5-year integrated honors).\n• School of Design (B.Des): ₹2,00,000 to ₹2,80,000 per year.\n• Campus Hostels: ₹1,10,000 to ₹1,80,000 per annum (includes 4-meal daily dining, Wi-Fi, laundry, 2/3 sharing, AC/non-AC).\n• University Transportation (Bus): ₹28,000 to ₹36,000 per annum covering 50+ routes across Bengaluru.\n• Merit Scholarships: Up to 50% tuition waiver for 90%+ marks in 12th/PUC.\n\nFor official personal quotes and admission counseling, visit the Admissions Office or call the helpline at +91 90220 92222 / 080 4925 5555.",
    "category": "Fee structure",
    "keywords": [
      "fees",
      "fess",
      "fee",
      "fee structure",
      "fees structure",
      "college fees",
      "course fees",
      "tuition fees",
      "what is the fees",
      "fees details",
      "how much fees",
      "presidency fees",
      "annual fees",
      "total fees",
      "fee info"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Fee Details",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 65,
    "question": "What is the approximate fee structure for B.Tech programs?",
    "answer": "For direct admissions / Management Quota, B.Tech tuition fees generally range from \u20b92,50,000 to \u20b93,50,000 per year (total approx \u20b910 to \u20b914 Lakhs over 4 years, higher for CSE/AI specializations). For students admitted through KCET government quota, fees are subsidized at approximately \u20b91,00,000 to \u20b91,15,000 per year as per Karnataka government norms.",
    "category": "Fee structure",
    "keywords": [
      "btech fees",
      "engineering fees",
      "cost of btech",
      "kcet fee vs management fee",
      "annual tuition"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 66,
    "question": "What is the total fee for the 2-Year MBA program?",
    "answer": "The total fee for the 2-year full-time MBA program generally ranges between \u20b96,00,000 and \u20b99,00,000 for the full course under the management quota, payable in semester or annual installments. For PGCET government-allotted seats, fees are subsidized.",
    "category": "Fee structure",
    "keywords": [
      "mba fees",
      "mba cost",
      "pgcet mba fee",
      "management mba package"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 67,
    "question": "What is the fee structure for BBA, BCA, and B.Com programs?",
    "answer": "For BBA and BCA, tuition fees range from \u20b91,30,000 to \u20b92,00,000 per year depending on specialization. B.Com (Hons.) ranges around \u20b91,10,000 to \u20b91,50,000 per year.",
    "category": "Fee structure",
    "keywords": [
      "bba fees",
      "bca fees",
      "bcom fees",
      "ug commerce fees",
      "annual tuition fee"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 68,
    "question": "What is the fee structure for the School of Law (BA LLB / BBA LLB)?",
    "answer": "The annual tuition fee for 5-year integrated law programs (B.A. LL.B., B.B.A. LL.B., B.Com. LL.B. Hons.) is approximately \u20b91,50,000 to \u20b92,25,000 per year.",
    "category": "Fee structure",
    "keywords": [
      "law fees",
      "ba llb fees",
      "bba llb fee",
      "5 year law cost"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 69,
    "question": "What payment modes are accepted for university fees?",
    "answer": "Tuition fees can be paid via the Presidency University ERP online student portal using Net Banking, NEFT/RTGS, Credit/Debit cards, UPI, or through Demand Draft (DD) drawn in favor of 'Presidency University' payable at Bengaluru.",
    "category": "Fee structure",
    "keywords": [
      "fee payment mode",
      "neft",
      "rtgs",
      "demand draft",
      "online fee pay"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 70,
    "question": "Does Presidency University offer education loan assistance?",
    "answer": "Yes, Presidency University has tie-ups with leading nationalized and private banks (including SBI, Canara Bank, HDFC Bank, ICICI Bank, Axis Bank, and Credila). The admissions desk provides bonafide fee estimates and documentation required to expedite loan processing.",
    "category": "Fee structure",
    "keywords": [
      "education loan",
      "bank tie up",
      "sbi loan",
      "loan assistance",
      "bonafide certificate"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 71,
    "question": "Are there any extra examination or laboratory fees?",
    "answer": "Semester examination fees, university registration, and lab consumables are either bundled into the institutional fee schedule or charged at nominal university-regulated rates per semester.",
    "category": "Fee structure",
    "keywords": [
      "exam fee",
      "lab fee",
      "hidden charges",
      "registration charges"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 72,
    "question": "What scholarships are available at Presidency University?",
    "answer": "Presidency University offers: 1) Merit-based Scholarships (up to 100% Presidential Scholarship); 2) High-scorer waivers based on 10+2 / board exam percentages (90%+ and 80-89.9%); 3) Entrance exam rank-based waivers (JEE Main, KCET, CLAT, CAT, MAT); 4) Sports and Cultural Excellence Scholarships; 5) Sibling / Alumni fee concessions; 6) Financial aid for defense wards and single parents.",
    "category": "Scholarships",
    "keywords": [
      "scholarships",
      "fee concession",
      "waiver",
      "presidential scholarship",
      "types of scholarship"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 73,
    "question": "What is the Presidential Scholarship?",
    "answer": "The Presidential Scholarship is the highest merit award offered by the university, providing up to a 100% tuition fee waiver to exceptional toppers in national entrance exams or state board toppers.",
    "category": "Scholarships",
    "keywords": [
      "presidential scholarship",
      "100 percent waiver",
      "free seat",
      "top merit award"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 74,
    "question": "What is the fee waiver for students with 90% or above in 12th/PUC?",
    "answer": "Under the merit concession policy, candidates securing 90% and above aggregate marks in 10+2 / PUC receive a special tuition concession (typically \u20b950,000 or equivalent percentage waiver on tuition fees in the first year).",
    "category": "Scholarships",
    "keywords": [
      "90 percent scholarship",
      "board topper waiver",
      "merit cut off",
      "50000 waiver"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 75,
    "question": "What is the fee concession for students scoring between 80% and 89.99% in 12th?",
    "answer": "Candidates securing between 80% and 89.99% in qualifying board examinations are eligible for standard merit fee concessions (typically \u20b930,000 or corresponding percentage deduction on first-year tuition fee).",
    "category": "Scholarships",
    "keywords": [
      "80 percent scholarship",
      "merit deduction",
      "30000 waiver"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 76,
    "question": "Does Presidency University offer sports scholarships?",
    "answer": "Yes, state, national, and international level sports medalists and participants in disciplines like Cricket, Football, Basketball, Athletics, and Badminton are granted sports scholarships ranging from 25% to 75% tuition fee waiver upon trials and certificate scrutiny.",
    "category": "Scholarships",
    "keywords": [
      "sports scholarship",
      "national player",
      "athlete waiver",
      "sports quota"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 77,
    "question": "Is there a concession for alumni or siblings of current students?",
    "answer": "Yes, Presidency University provides a 10% to 20% sibling discount and alumni continuation concession for students whose siblings are enrolled or who completed their schooling/PUC at Presidency Group of Institutions.",
    "category": "Scholarships",
    "keywords": [
      "sibling discount",
      "alumni concession",
      "presidency school alumni",
      "pgi concession"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 78,
    "question": "How can I apply for a scholarship at Presidency University?",
    "answer": "You can apply for scholarships directly within the online admission application form by uploading certified copies of your qualifying marksheets, entrance rank cards, or sports/cultural certificates. The Scholarship Committee reviews and notifies eligible candidates during admission.",
    "category": "Scholarships",
    "keywords": [
      "how to apply for scholarship",
      "scholarship form",
      "upload documents for waiver"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 79,
    "question": "What documents are required for undergraduate (B.Tech / BBA / Law) admission?",
    "answer": "Required documents include: 1) Class 10th / SSLC Marks Card; 2) Class 12th / PUC / Equivalent Marks Card; 3) Transfer Certificate (TC); 4) Migration Certificate (for non-Karnataka / non-state board students); 5) Conduct / Character Certificate; 6) Entrance Exam Rank Card (KCET/COMEDK/JEE/CLAT); 7) Caste/Income Certificate (if claiming reservation); 8) Aadhar Card copy; 9) Passport-size recent photographs (6-8 copies).",
    "category": "Required documents",
    "keywords": [
      "documents required",
      "checklist",
      "certificates for admission",
      "tc",
      "migration",
      "marks card"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 80,
    "question": "What additional documents are required for MBA / M.Tech admissions?",
    "answer": "For postgraduate admissions, along with 10th and 12th certificates, you need: 1) Degree Marks Cards of all semesters; 2) Degree Certificate or Provisional Degree Certificate (PDC); 3) Entrance exam scorecard (PGCET/CAT/MAT/KMAT); 4) Work Experience certificates (if applicable).",
    "category": "Required documents",
    "keywords": [
      "pg documents",
      "mba documents checklist",
      "degree certificate",
      "pdc",
      "semester marks cards"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 81,
    "question": "Do I need to submit original certificates during admission?",
    "answer": "Yes, during final seat confirmation and verification, original certificates must be produced for verification by the Registrar's office. The university issues an acknowledgment receipt and returns originals after verification according to regulatory timelines.",
    "category": "Required documents",
    "keywords": [
      "original certificates",
      "verification process",
      "acknowledgment receipt",
      "certificate submission"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 82,
    "question": "Is a Migration Certificate mandatory for all applicants?",
    "answer": "A Migration Certificate is mandatory for students who completed their 10+2 / Pre-University outside Karnataka or from non-state boards (such as CBSE, ICSE, NIOS, or foreign boards).",
    "category": "Required documents",
    "keywords": [
      "migration certificate",
      "cbse migration",
      "other state students documents"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 83,
    "question": "What should I do if my final 12th marksheet is delayed?",
    "answer": "Candidates whose results are awaited can submit an attested copy of their online provisional marksheet or internet copy accompanied by an undertaking. Permanent admission is confirmed once official original marksheets are submitted.",
    "category": "Required documents",
    "keywords": [
      "result awaited",
      "provisional marksheet",
      "delayed 12th results",
      "undertaking"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 84,
    "question": "Are hostel accommodations available at Presidency University?",
    "answer": "Yes, Presidency University provides separate, well-appointed hostels for boys and girls. Accommodations are available in twin-sharing and triple-sharing room layouts, with choices of air-conditioned (AC) and non-AC rooms.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel",
      "accommodation",
      "dorm",
      "boys hostel",
      "girls hostel",
      "twin sharing",
      "triple sharing"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 85,
    "question": "What is the fee for Presidency University hostels?",
    "answer": "Hostel fees typically range from \u20b91,40,000 to \u20b91,75,000 per academic year depending on the room category (triple sharing vs twin sharing, standard vs AC), plus a one-time refundable security caution deposit of approximately \u20b910,000.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel fee",
      "mess fee",
      "hostel rent",
      "annual hostel charges",
      "security deposit"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 86,
    "question": "What amenities are provided in the hostels?",
    "answer": "Hostel amenities include: comfortable beds with mattresses, study tables, chairs, modular wardrobes, high-speed Wi-Fi, 24/7 power backup with generators, solar water heaters, laundry facilities, TV common rooms, recreation indoor games, and daily housekeeping.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel amenities",
      "wifi",
      "laundry",
      "hot water",
      "common room",
      "housekeeping"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 87,
    "question": "What is the dining / mess facility like in the hostels?",
    "answer": "The dining halls serve hygienic, nutritious multi-cuisine meals including North Indian and South Indian vegetarian and non-vegetarian selections. The menu is planned in consultation with the student mess committee.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel mess",
      "food quality",
      "vegetarian food",
      "non veg",
      "dining hall",
      "menu"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 88,
    "question": "What safety and security measures exist in the hostels?",
    "answer": "Safety measures include 24/7 security personnel, biometric entry/exit access, full CCTV surveillance covering all perimeters, resident wardens on every floor, anti-ragging squads, and strict visitor verification logs.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel safety",
      "biometric",
      "cctv",
      "security",
      "wardens",
      "curfew"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 89,
    "question": "What are the hostel curfew hours and outing rules?",
    "answer": "For student safety, evening entry cutoff is strictly observed (usually 7:30 PM for hostel gates). Weekend outings and night-outs require parent consent submitted via the official hostel ERP / warden approval app.",
    "category": "Hostel facilities",
    "keywords": [
      "curfew timing",
      "outing rules",
      "night out permission",
      "hostel rules"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 90,
    "question": "Is weekend transport provided for hostellers to visit the city?",
    "answer": "Yes, the university provides scheduled weekend shuttle buses connecting hostel students to nearby shopping centers, supermarkets, and metro connections in Yelahanka New Town.",
    "category": "Hostel facilities",
    "keywords": [
      "weekend shuttle",
      "shopping bus",
      "yelahanka transport",
      "weekend outing"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 91,
    "question": "Does Presidency University provide bus transportation?",
    "answer": "Yes, Presidency University manages a fleet of over 50 luxury buses operating on dedicated routes connecting almost all parts of Bengaluru city and surrounding suburban belts to the Rajanakunte campus.",
    "category": "Transportation",
    "keywords": [
      "transportation",
      "bus facility",
      "college bus",
      "fleet",
      "50 buses"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 92,
    "question": "Which areas of Bengaluru are covered by university buses?",
    "answer": "Major routes cover: Majestic, Hebbal, Yelahanka, Yeshwanthpur, Rajajinagar, Vijayanagar, Banashankari, Jayanagar, BTM Layout, Koramangala, Indiranagar, Whitefield, KR Puram, Electronic City, Nagarbhavi, and Kengeri.",
    "category": "Transportation",
    "keywords": [
      "bus routes",
      "hebbal route",
      "majestic route",
      "whitefield bus",
      "areas covered"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 93,
    "question": "What safety features are equipped on university buses?",
    "answer": "All university buses are equipped with GPS live tracking, speed governors, CCTV cameras, first-aid kits, fire extinguishers, and emergency contact numbers, operated by vetted, experienced drivers.",
    "category": "Transportation",
    "keywords": [
      "bus safety",
      "gps tracking",
      "speed governor",
      "safe transport"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 94,
    "question": "What is the annual transportation fee?",
    "answer": "Transport fees vary depending on pick-up distance and zone, typically ranging from \u20b930,000 to \u20b945,000 per academic year, inclusive of return trips on all working days.",
    "category": "Transportation",
    "keywords": [
      "transport fee",
      "bus pass cost",
      "annual bus charges",
      "bus fare"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 95,
    "question": "Is there a shuttle service between Rajanakunte station and the campus?",
    "answer": "Yes, a complimentary feeder shuttle operates frequently during peak morning and evening hours between Rajanakunte bus stop / railway station and the university main gate for students using public transit.",
    "category": "Transportation",
    "keywords": [
      "shuttle service",
      "feeder bus",
      "rajanakunte shuttle",
      "station pickup"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 96,
    "question": "How do students obtain a university bus pass?",
    "answer": "Students can apply for the bus pass during registration on the ERP portal by selecting their boarding stop, paying the transport fee, and collecting their RFID-enabled transport card from the Transport Office.",
    "category": "Transportation",
    "keywords": [
      "bus pass apply",
      "rfid bus pass",
      "transport registration",
      "boarding point"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 97,
    "question": "What library facilities are available at Presidency University?",
    "answer": "The university features a multi-branch library system: the Central Main Library (housing Engineering, Computer Science, and Sciences), the Management Library Annexe, and a dedicated Law Library in the E-Block. Total holdings exceed 40,500+ volumes.",
    "category": "Library",
    "keywords": [
      "library",
      "books",
      "central library",
      "law library",
      "volumes",
      "reading room"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 98,
    "question": "What digital databases and e-resources are subscribed by the library?",
    "answer": "The library subscribes to premier e-resource packages including IEEE Xplore, ScienceDirect, SpringerLink, ProQuest, EBSCO, Manupatra, SCC Online, HeinOnline, LexisNexis, and Knimbus remote access platform.",
    "category": "Library",
    "keywords": [
      "digital library",
      "ieee xplore",
      "scopus",
      "manupatra",
      "scc online",
      "knimbus",
      "e journals"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 99,
    "question": "Is the library automated?",
    "answer": "Yes, the library is fully automated using KOHA Integrated Library Management Software with Web OPAC for remote catalog searches, RFID book detection gates, and self-check-in/check-out kiosks.",
    "category": "Library",
    "keywords": [
      "koha",
      "web opac",
      "rfid",
      "library automation",
      "self checkout"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 100,
    "question": "What are the library timings?",
    "answer": "The Central Library is open from 8:30 AM to 8:00 PM on all working days, with extended reading hours until 10:00 PM during mid-term and end-semester examinations.",
    "category": "Library",
    "keywords": [
      "library timings",
      "opening hours",
      "exam reading hours",
      "closing time"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 101,
    "question": "Can students access library e-resources from home?",
    "answer": "Yes, students and faculty are provided with Knimbus remote access credentials, allowing 24/7 off-campus access to all subscribed international journals, e-books, and databases from any mobile device or laptop.",
    "category": "Library",
    "keywords": [
      "knimbus remote access",
      "off campus library",
      "home access e books",
      "digital portal"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 102,
    "question": "Does the university library offer plagiarism detection services?",
    "answer": "Yes, the library provides access to Turnitin and DrillBit plagiarism detection software for research scholars, postgraduate students, and faculty submitting dissertations and journal articles.",
    "category": "Library",
    "keywords": [
      "plagiarism check",
      "turnitin",
      "thesis similarity",
      "research verification"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 103,
    "question": "What computing and AI laboratories are on campus?",
    "answer": "Presidency University houses state-of-the-art computer labs with over 2,000+ high-end workstations, dedicated NVIDIA GPU AI clusters for deep learning, an Apple Mac Lab for iOS development, and specialized Cloud & IoT setups.",
    "category": "Laboratories",
    "keywords": [
      "computer labs",
      "ai lab",
      "gpu cluster",
      "apple mac lab",
      "nvidia",
      "workstations"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 104,
    "question": "What specialized engineering workshops exist at the university?",
    "answer": "Specialized labs include: Robotics & Automation Lab, Mechatronics Lab, Advanced Materials & Metallography Lab, Fluid Mechanics & IC Engines Lab, VLSI & Embedded Systems Design Lab, and Concrete Technology Lab.",
    "category": "Laboratories",
    "keywords": [
      "engineering labs",
      "robotics lab",
      "vlsi lab",
      "mechatronics lab",
      "workshops"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 105,
    "question": "Does the School of Law have a Moot Court Hall?",
    "answer": "Yes, the School of Law features a full-fledged, air-conditioned replica Moot Court Hall with judge's podium, witness stand, counsel bar, and acoustic recording equipment for regular trial simulations and mooting competitions.",
    "category": "Laboratories",
    "keywords": [
      "moot court",
      "law court hall",
      "trial advocacy",
      "mock court"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 106,
    "question": "What laboratories are available for Allied Health and Sciences?",
    "answer": "Facilities include modern Clinical Biochemistry Labs, Microbiology & Pathology Labs, Hematology Lab, Simulation ICU/Operation Theatre setup, Optics & Refraction Lab, and Forensic Crime Scene Simulation rooms.",
    "category": "Laboratories",
    "keywords": [
      "health labs",
      "biochemistry lab",
      "pathology lab",
      "simulation ot",
      "forensic lab"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 107,
    "question": "Is there a FabLab or Prototyping Centre on campus?",
    "answer": "Yes, Presidency University features a Maker Space and Prototyping Centre equipped with 3D printers, CNC cutting machines, laser engravers, and electronics soldering stations for student innovation and capstone projects.",
    "category": "Laboratories",
    "keywords": [
      "3d printer",
      "prototyping lab",
      "maker space",
      "fab lab",
      "hardware projects"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 108,
    "question": "What sports facilities are available on campus?",
    "answer": "The campus offers extensive sports infrastructure: a full-sized cricket ground with practice turf nets, standard football turf, floodlit basketball courts, volleyball and throwball courts, badminton courts, tennis courts, and athletics tracks.",
    "category": "Sports facilities",
    "keywords": [
      "sports facilities",
      "cricket ground",
      "football turf",
      "basketball court",
      "athletics",
      "badminton"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 109,
    "question": "Is there a gymnasium on campus?",
    "answer": "Yes, Presidency University features separate, fully equipped modern gymnasiums for boys and girls with cardiovascular machines, strength trainers, free weights, and certified fitness trainers.",
    "category": "Sports facilities",
    "keywords": [
      "gym",
      "gymnasium",
      "fitness center",
      "workout",
      "weights"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 110,
    "question": "What indoor games are available?",
    "answer": "The Student Activity Centre houses table tennis courts, chess and carrom lounges, and a dedicated Yoga and Meditation studio conducting regular wellness sessions.",
    "category": "Sports facilities",
    "keywords": [
      "indoor games",
      "table tennis",
      "chess",
      "carrom",
      "yoga studio"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 111,
    "question": "What is the annual university sports meet called?",
    "answer": "The annual sports meet is known as 'Kreedotsava' (Presidency Olympic Week), featuring inter-departmental and inter-university tournaments in cricket, football, basketball, and track & field athletics.",
    "category": "Sports facilities",
    "keywords": [
      "kreedotsava",
      "sports meet",
      "annual sports fest",
      "tournaments"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 112,
    "question": "Are professional sports coaches available for student teams?",
    "answer": "Yes, the Department of Physical Education employs certified coaches for Cricket, Football, Basketball, Badminton, and Athletics who train university varsity teams representing Presidency in inter-university championships.",
    "category": "Sports facilities",
    "keywords": [
      "sports coaches",
      "varsity teams",
      "inter university tournament",
      "sports training"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 113,
    "question": "What student clubs exist at Presidency University?",
    "answer": "Student clubs operate under the Department of Student Affairs (DSA) spanning: 1) Technical Clubs (Coding Club, ACM Chapter, IEEE, Robotics, AI Club); 2) Cultural Clubs (Music, Dance, Theatre, Photography); 3) Literary & Debating (MUN, Quiz, Debate); 4) Social Action (Rotaract Club, NSS, NCC, Red Cross); 5) Sports & Fitness Associations.",
    "category": "Student clubs",
    "keywords": [
      "clubs",
      "student clubs",
      "dsa",
      "acm",
      "ieee",
      "rotaract",
      "dance club",
      "coding club"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 114,
    "question": "Does Presidency University have an active NCC unit?",
    "answer": "Yes, Presidency University has an active National Cadet Corps (NCC) Army Wing detachment providing military training, weapon training, drills, and participation in Republic Day (RDC) parades.",
    "category": "Student clubs",
    "keywords": [
      "ncc",
      "national cadet corps",
      "army wing",
      "rdc camp",
      "military drill"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 115,
    "question": "What community service initiatives does NSS undertake?",
    "answer": "The National Service Scheme (NSS) unit organizes regular blood donation camps, rural health camps in adopted villages around Rajanakunte, tree plantation drives, and digital literacy workshops for local schools.",
    "category": "Student clubs",
    "keywords": [
      "nss",
      "community service",
      "blood donation",
      "adopted villages",
      "social work"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 116,
    "question": "What is the Rotaract Club of Presidency University?",
    "answer": "Chartered under Rotary International District 3192, the Rotaract Club of Presidency University organizes youth leadership conclaves, environmental awareness runs, orphan support initiatives, and inter-collegiate humanitarian drives.",
    "category": "Student clubs",
    "keywords": [
      "rotaract",
      "rotaract club",
      "rotary",
      "youth leadership",
      "charity"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 117,
    "question": "How can a student join or start a club?",
    "answer": "During the annual 'Club Carnival' held in the first month of the academic year, students can register for any club. Students wishing to form a new club can submit a charter and faculty mentor endorsement to the Directorate of Student Affairs (DSA).",
    "category": "Student clubs",
    "keywords": [
      "how to join club",
      "club carnival",
      "start a club",
      "dsa registration"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 118,
    "question": "Does Presidency University have an IEEE or ACM student branch?",
    "answer": "Yes, both IEEE Presidency University Student Branch and ACM Student Chapter are active on campus, hosting technical hackathons, coding bootcamps, and international speaker sessions.",
    "category": "Student clubs",
    "keywords": [
      "ieee chapter",
      "acm chapter",
      "tech chapters",
      "coding community"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 119,
    "question": "What is Invincia at Presidency University?",
    "answer": "'Invincia' is Presidency University's flagship annual inter-collegiate national cultural festival. It is one of Bengaluru's biggest youth festivals, drawing over 15,000+ students for multi-stage music concerts, fashion pro-nites, dance competitions, and celebrity headliner performances.",
    "category": "Campus events",
    "keywords": [
      "invincia",
      "annual fest",
      "cultural festival",
      "pro nite",
      "celebrity concert",
      "college fest"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 120,
    "question": "What technical fests and hackathons are hosted?",
    "answer": "The university hosts the annual National TechFest and 'Presidency Hackathon' (a 24-36 hour national coding and hardware hackathon), featuring challenges in AI, Smart Mobility, FinTech, and Green Tech with corporate sponsorships and cash prizes.",
    "category": "Campus events",
    "keywords": [
      "hackathon",
      "tech fest",
      "presidency hackathon",
      "coding competition",
      "prize money"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 121,
    "question": "What is the National Moot Court Competition hosted by School of Law?",
    "answer": "The School of Law hosts an annual National Moot Court Competition that invites law teams from across India to argue complex constitutional, international, and commercial law problems judged by High Court judges and Senior Advocates.",
    "category": "Campus events",
    "keywords": [
      "national moot court",
      "law competition",
      "mooting",
      "legal event"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 122,
    "question": "Does Presidency University organize Model United Nations (MUN)?",
    "answer": "Yes, Presidency University Model United Nations (PUMUN) is an annual diplomatic simulation where student delegates represent diverse nations to debate global policy, conflict resolution, and UN sustainable development goals.",
    "category": "Campus events",
    "keywords": [
      "pumun",
      "model united nations",
      "debating conclave",
      "diplomacy"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 123,
    "question": "What cultural celebrations take place throughout the year?",
    "answer": "The campus celebrates Kannada Rajyotsava with traditional music and dance, Ethnic Day, Onam, Diwali, Christmas, Independence Day, and Republic Day with great enthusiasm and cultural showcases.",
    "category": "Campus events",
    "keywords": [
      "kannada rajyotsava",
      "ethnic day",
      "cultural celebrations",
      "festivals"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 124,
    "question": "How are the placements at Presidency University Bengaluru?",
    "answer": "Presidency University reports a consistent placement track record facilitated by its dedicated Career Resource Centre (CRC). Over 500+ top tier recruiters visit annually, offering career opportunities across software, core engineering, consulting, banking, and management domains.",
    "category": "Placement information",
    "keywords": [
      "placements",
      "placement record",
      "crc",
      "campus recruitment",
      "job opportunities"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 125,
    "question": "What is the highest package offered at Presidency University?",
    "answer": "Recent placement cycles have witnessed highest salary packages scaling between \u20b913.58 LPA and \u20b916+ LPA, with leading offers coming from international tech, product engineering, and global consulting corporations.",
    "category": "Placement information",
    "keywords": [
      "highest package",
      "highest salary",
      "top ctc",
      "13.58 lpa",
      "16 lpa"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 126,
    "question": "What is the average package for B.Tech and MBA graduates?",
    "answer": "The overall average CTC for B.Tech engineering graduates ranges between \u20b95.50 LPA and \u20b96.00 LPA. For MBA graduates, the average package ranges around \u20b95.00 LPA to \u20b96.50 LPA.",
    "category": "Placement information",
    "keywords": [
      "average package",
      "average salary",
      "average ctc",
      "btech average",
      "mba average"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 127,
    "question": "Who are the top recruiters visiting Presidency University?",
    "answer": "Prominent recruiting partners include: Microsoft, Amazon, Infosys, Wipro, TCS, Capgemini, Cognizant, Tech Mahindra, Dell Technologies, EY, KPMG, Berger Paints, ICICI Bank, Deloitte, Mindtree, Oracle, HP, and Bosch.",
    "category": "Placement information",
    "keywords": [
      "top recruiters",
      "companies visiting",
      "infosys",
      "tcs",
      "microsoft",
      "amazon",
      "capgemini"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 128,
    "question": "What is the placement percentage of eligible students?",
    "answer": "The university consistently registers a placement rate exceeding 90% for all eligible registered students who meet company cut-off criteria without backlogs.",
    "category": "Placement information",
    "keywords": [
      "placement percentage",
      "placement rate",
      "success rate",
      "90 percent placement"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 129,
    "question": "Are core engineering placements available for Mechanical and Civil students?",
    "answer": "Yes, companies such as Larsen & Toubro (L&T), Bosch, Tata Consulting Engineers, Godrej, Schindler, and Asian Paints recruit students from Mechanical, Mechatronics, and Civil disciplines.",
    "category": "Placement information",
    "keywords": [
      "core placements",
      "mechanical jobs",
      "civil placements",
      "l&t",
      "bosch"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 130,
    "question": "What is the Career Resource Centre (CRC)?",
    "answer": "The Career Resource Centre (CRC) is the specialized university wing responsible for training, corporate relations, industry partnerships, internships, and on-campus placement drives.",
    "category": "Career services",
    "keywords": [
      "crc",
      "career resource centre",
      "placement cell",
      "corporate connect",
      "training wing"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 131,
    "question": "What pre-placement training is provided to students?",
    "answer": "From the 2nd year onwards, CRC conducts comprehensive training modules in: 1) Quantitative aptitude and logical reasoning; 2) Data Structures, Algorithms, and Full-Stack Coding; 3) Soft skills, communication, and executive presence; 4) Resume building, group discussions, and mock technical/HR interviews.",
    "category": "Career services",
    "keywords": [
      "pre placement training",
      "soft skills",
      "aptitude classes",
      "coding training",
      "mock interview"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 132,
    "question": "Does the university organize corporate talks and CXO guest lectures?",
    "answer": "Yes, through the 'Industry Connect' initiative, senior corporate leaders, CTOs, and HR directors from Fortune 500 companies frequently conduct on-campus seminars and masterclasses.",
    "category": "Career services",
    "keywords": [
      "cxo lectures",
      "guest lectures",
      "corporate talks",
      "industry connect"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 133,
    "question": "Does Presidency University have an Entrepreneurship and Incubation Cell?",
    "answer": "Yes, the Presidency University Centre for Innovation, Incubation and Entrepreneurship (CIIE) provides seed funding, mentoring, co-working space, and intellectual property (IP) filing assistance to student startups.",
    "category": "Career services",
    "keywords": [
      "incubation cell",
      "startup cell",
      "ciie",
      "entrepreneurship",
      "seed funding"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 134,
    "question": "How are alumni involved in student career mentoring?",
    "answer": "The Presidency Alumni Association conducts monthly 'Alumni Mentorship Circles' where senior graduates working in top MNCs guide current students on industry trends, interview preparation, and referral opportunities.",
    "category": "Career services",
    "keywords": [
      "alumni mentoring",
      "alumni network",
      "career guidance",
      "mock interviews"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 135,
    "question": "Is an internship mandatory for undergraduate and postgraduate students?",
    "answer": "Yes, mandatory credit-bearing summer and final-semester internships are integrated into the curriculum for B.Tech, MBA, Law, and Design programs to ensure real-world industry readiness.",
    "category": "Internship information",
    "keywords": [
      "internship",
      "mandatory internship",
      "industry training",
      "summer internship",
      "credits"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 136,
    "question": "Does Presidency University help students find internships?",
    "answer": "Yes, the Career Resource Centre facilitates on-campus internship drives where companies recruit students for 2 to 6-month stipendiary internships, frequently leading to Pre-Placement Offers (PPOs).",
    "category": "Internship information",
    "keywords": [
      "internship assistance",
      "ppo",
      "stipend internship",
      "internship drive"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 137,
    "question": "What kinds of legal internships do School of Law students undergo?",
    "answer": "Law students undergo mandatory annual internships with trial court advocates, High Court advocates, senior corporate law firms, NGOs, legal aid cells, and judicial clerkships.",
    "category": "Internship information",
    "keywords": [
      "law internship",
      "court internship",
      "ngo internship",
      "advocate chambers"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 138,
    "question": "What is the typical stipend range for engineering and management internships?",
    "answer": "Internship stipends typically range from \u20b915,000 to \u20b940,000 per month depending on the recruiting company, performance in assessments, and technical role.",
    "category": "Internship information",
    "keywords": [
      "internship stipend",
      "monthly stipend",
      "paid internship"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 139,
    "question": "Can students complete internships abroad through international tie-ups?",
    "answer": "Yes, students with outstanding academic records can apply for semester abroad or international summer research internships through the university's partner universities in the UK, USA, and Europe.",
    "category": "Internship information",
    "keywords": [
      "international internship",
      "semester abroad",
      "foreign research"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 140,
    "question": "What is the official contact number for admission inquiries?",
    "answer": "You can reach the Presidency University admissions helpline at +91 90220 92222 or the central board line at 080 4925 5555.",
    "category": "Contact details",
    "keywords": [
      "contact number",
      "phone number",
      "helpline",
      "admission call",
      "9022092222"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 141,
    "question": "What is the official admission email address?",
    "answer": "For general admission inquiries, email: admission@presidencyuniversity.in. For general institutional queries, email: info@presidencyuniversity.in.",
    "category": "Contact details",
    "keywords": [
      "email address",
      "admission email",
      "info email",
      "official mail"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 142,
    "question": "What is the postal address of Presidency University main campus?",
    "answer": "Presidency University, Itgalpur, Rajanakunte, Yelahanka, Bengaluru \u2013 560064, Karnataka, India.",
    "category": "Contact details",
    "keywords": [
      "postal address",
      "mailing address",
      "pin code 560064",
      "university address"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 143,
    "question": "What are the operating hours of the Admissions Office?",
    "answer": "The Admissions Office is open Monday to Saturday from 9:00 AM to 5:00 PM (IST). It is closed on Sundays and designated public holidays.",
    "category": "Contact details",
    "keywords": [
      "working hours",
      "timing",
      "office hours",
      "open days"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 144,
    "question": "How can companies contact the Career Resource Centre for placements?",
    "answer": "Recruiters and corporate partners can contact the CRC at placements@presidencyuniversity.in or call the placement directorate at +91 80 4925 5555.",
    "category": "Contact details",
    "keywords": [
      "placement contact",
      "recruiter email",
      "crc phone",
      "hire graduates"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 145,
    "question": "What is the contact information for the Registrar and Examination Branch?",
    "answer": "The Registrar's Office can be contacted at registrar@presidencyuniversity.in, and the Controller of Examinations (COE) at coe@presidencyuniversity.in for verification of credentials and transcript requests.",
    "category": "Contact details",
    "keywords": [
      "registrar email",
      "coe email",
      "controller of examinations",
      "transcript contact"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 146,
    "question": "Is Presidency University ragging-free?",
    "answer": "Yes, Presidency University maintains a strict zero-tolerance policy towards ragging in compliance with Supreme Court and UGC directives. An active Anti-Ragging Committee and Squad conduct round-the-clock surprise checks.",
    "category": "Frequently asked questions",
    "keywords": [
      "anti ragging",
      "ragging policy",
      "student safety",
      "zero tolerance"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 147,
    "question": "Is attendance compulsory at Presidency University?",
    "answer": "Yes, students must maintain a minimum of 75% attendance in each course theory and practical component to be eligible to appear for the End-Term Semester Examinations.",
    "category": "Frequently asked questions",
    "keywords": [
      "attendance rule",
      "75 percent attendance",
      "minimum attendance",
      "attendance requirement"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 148,
    "question": "Is there a dress code at Presidency University?",
    "answer": "Students are required to wear smart, formal/semi-formal attire reflecting an academic environment. Certain schools (such as the School of Law and School of Allied Health Sciences) mandate specific uniforms/blazers during formal courtroom days, labs, and presentations.",
    "category": "Frequently asked questions",
    "keywords": [
      "dress code",
      "uniform",
      "attire",
      "law uniform"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 149,
    "question": "Does Presidency University have on-campus medical facilities?",
    "answer": "Yes, the university has an on-campus Health Care Centre staffed 24/7 with resident doctors and qualified nurses. An emergency ambulance is stationed on campus, and the university has tie-ups with multi-specialty hospitals in Yelahanka.",
    "category": "Frequently asked questions",
    "keywords": [
      "medical facilities",
      "health clinic",
      "doctor on campus",
      "ambulance",
      "hospital tie up"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 150,
    "question": "Are ATM and banking facilities available on campus?",
    "answer": "Yes, multi-bank ATM facilities are located inside the campus near the cafeteria and administrative blocks for convenient cash withdrawals by students and staff.",
    "category": "Frequently asked questions",
    "keywords": [
      "atm",
      "bank",
      "cash machine",
      "banking on campus"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 151,
    "question": "What food and canteen options exist on campus?",
    "answer": "The campus features a spacious multi-cuisine food court serving South Indian, North Indian, Chinese, and continental snacks, along with Caf\u00e9 Coffee Day (CCD), Nescafe kiosks, juice corners, and an ice-cream parlour.",
    "category": "Frequently asked questions",
    "keywords": [
      "canteen",
      "food court",
      "cafe coffee day",
      "ccd",
      "cafeteria",
      "snacks"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 152,
    "question": "Is campus-wide Wi-Fi provided to students?",
    "answer": "Yes, high-speed secure Wi-Fi coverage is enabled across all academic blocks, laboratories, libraries, auditoriums, and hostel buildings using student ERP credentials.",
    "category": "Frequently asked questions",
    "keywords": [
      "wifi",
      "campus internet",
      "wifi credentials",
      "broadband"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 153,
    "question": "What is the official link to apply for Presidency University?",
    "answer": "The official online application portal is accessible directly at: https://presidencyuniversity.in/ (click 'Apply Now'). Alternatively, link via the official admissions portal.",
    "category": "Official application links",
    "keywords": [
      "official application link",
      "apply online link",
      "registration link",
      "url"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 154,
    "question": "Where can I download the official university prospectus and brochure?",
    "answer": "The official prospectus and school-specific brochures can be downloaded from the university portal at https://presidencyuniversity.in/ or obtained directly from the Admissions Desk.",
    "category": "Official application links",
    "keywords": [
      "download prospectus",
      "brochure link",
      "syllabus download",
      "handbook"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 155,
    "question": "What is the link to the official Presidency University website?",
    "answer": "The main official website is: https://presidencyuniversity.in/ (Main university portal with verified links and information).",
    "category": "Official application links",
    "keywords": [
      "main website",
      "official site link",
      "home page url",
      "presidency university in"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 156,
    "question": "What is the official Google Reference link for Presidency University?",
    "answer": "The verified Google reference provided is: https://share.google/aed5CNFY68y6VE8UV (Official Google Share Reference for Presidency University Bengaluru).",
    "category": "Official application links",
    "keywords": [
      "google reference",
      "share google",
      "google link"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 157,
    "question": "Where can current students access the Presidency University ERP portal?",
    "answer": "Students can access course schedules, grades, attendance, and fee payments via the student ERP portal linked on https://presidencyuniversity.in/ under 'Student Portal'.",
    "category": "Official application links",
    "keywords": [
      "erp link",
      "student portal url",
      "attendance login",
      "grades portal"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 158,
    "question": "How does the university publish important examination and academic notices?",
    "answer": "All official circulars, examination schedules, time-tables, and academic calendar revisions are published on the official Presidency University Student Portal / ERP system and displayed on departmental notice boards.",
    "category": "Important notices",
    "keywords": [
      "notices",
      "circulars",
      "exam timetable",
      "student portal notice",
      "announcements"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 159,
    "question": "What is the advisory regarding fake admission agents or brokers?",
    "answer": "Presidency University strictly cautions parents and candidates that it has NOT authorized any external brokers, agents, or consultancies to charge commission or guarantee admissions. All admissions are processed exclusively through the official university portal or official campus admissions office.",
    "category": "Important notices",
    "keywords": [
      "fake agents warning",
      "broker caution",
      "fraud alert",
      "official admission only"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 160,
    "question": "How are fee refunds handled if an admission is cancelled?",
    "answer": "Fee refunds follow UGC guidelines: 100% refund (less nominal processing fee) if withdrawal request is received 15 days or more before the formally notified last date of admission, with graded refund percentages thereafter as per UGC refund directives.",
    "category": "Important notices",
    "keywords": [
      "refund policy",
      "fee refund",
      "cancellation of admission",
      "ugc refund rules"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 161,
    "question": "What is the procedure for semester exam hall ticket generation?",
    "answer": "Students who meet the minimum 75% attendance threshold and clear all dues can download their digitized hall ticket from the student ERP portal one week prior to the commencement of end-semester examinations.",
    "category": "Important notices",
    "keywords": [
      "hall ticket",
      "admit card",
      "exam hall ticket download",
      "semester exam entry"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 162,
    "question": "How can students submit an anti-ragging affidavit online?",
    "answer": "As mandated by the UGC and Supreme Court, every student and their parent must complete the annual online Anti-Ragging Undertaking at www.antiragging.in and submit the reference number to the university during registration.",
    "category": "Important notices",
    "keywords": [
      "anti ragging affidavit",
      "ugc undertaking",
      "antiragging in",
      "compliance"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 163,
    "question": "What is the course syllabus and focus of B.Tech CSE (AI & Machine Learning)?",
    "answer": "B.Tech CSE with specialization in AI & ML focuses on deep neural networks, natural language processing (NLP), computer vision, robotics, reinforcement learning, and big data architectures using Python, TensorFlow, and PyTorch.",
    "category": "Undergraduate programs",
    "keywords": [
      "cse ai ml syllabus",
      "machine learning subjects",
      "tensorflow",
      "pytorch"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 164,
    "question": "What is covered under B.Tech CSE (Data Science)?",
    "answer": "B.Tech CSE (Data Science) emphasizes statistical modeling, machine learning, predictive analytics, distributed computing with Apache Spark & Hadoop, data warehousing, and business intelligence visualization using PowerBI and Tableau.",
    "category": "Undergraduate programs",
    "keywords": [
      "cse data science",
      "data science syllabus",
      "big data",
      "hadoop",
      "spark"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 165,
    "question": "What subjects are taught in B.Tech CSE (Cyber Security)?",
    "answer": "The Cyber Security specialization covers ethical hacking, cryptography, network defense, penetration testing, digital forensics, blockchain fundamentals, and cloud security in compliance with industry ISO/NIST standards.",
    "category": "Undergraduate programs",
    "keywords": [
      "cyber security subjects",
      "ethical hacking",
      "cryptography",
      "network defense"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 166,
    "question": "What is the focus of the Electronics and Communication Engineering (ECE) department?",
    "answer": "ECE covers VLSI design, embedded systems, IoT architecture, 5G wireless communications, signal processing, and robotics, supported by cadence and MATLAB software labs.",
    "category": "Undergraduate programs",
    "keywords": [
      "ece department",
      "vlsi",
      "embedded systems",
      "5g communication",
      "electronics"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 167,
    "question": "What is the scope of Mechanical Engineering and Mechatronics at Presidency University?",
    "answer": "Mechanical and Mechatronics programs combine mechanical principles with electronics, microcontrollers, pneumatic systems, CAD/CAM/CAE modeling, and industrial automation for automotive, aerospace, and smart manufacturing sectors.",
    "category": "Undergraduate programs",
    "keywords": [
      "mechatronics scope",
      "mechanical engineering",
      "cad cam",
      "industrial automation"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 168,
    "question": "Does Presidency University offer Petroleum Engineering?",
    "answer": "Yes, Presidency University is one of the few premier institutions in Karnataka offering a 4-year B.Tech in Petroleum Engineering, focusing on drilling, reservoir engineering, oil exploration, and petrochemical processing.",
    "category": "Undergraduate programs",
    "keywords": [
      "petroleum engineering",
      "oil exploration",
      "petrochemicals",
      "drilling engineering"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 169,
    "question": "What specializations are available in Civil Engineering?",
    "answer": "Civil Engineering covers structural design, environmental engineering, geotechnical engineering, smart city transportation planning, and BIM (Building Information Modeling) technologies.",
    "category": "Undergraduate programs",
    "keywords": [
      "civil engineering",
      "structural engineering",
      "bim",
      "smart cities"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 170,
    "question": "What are the subjects covered in BBA Aviation Management?",
    "answer": "BBA Aviation Management covers airport operations, air traffic management, airline marketing, aviation security, cargo management, and aviation law, preparing students for managerial roles with domestic and international airlines.",
    "category": "Undergraduate programs",
    "keywords": [
      "bba aviation",
      "aviation management",
      "airport operations",
      "airline jobs"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 171,
    "question": "What is BBA Business Analytics?",
    "answer": "BBA Business Analytics integrates business administration principles with quantitative data analytics, Python for business, predictive modeling, financial analytics, and marketing analytics.",
    "category": "Undergraduate programs",
    "keywords": [
      "bba business analytics",
      "data analytics bba",
      "predictive modeling"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 172,
    "question": "What is BBA Digital Marketing?",
    "answer": "BBA Digital Marketing covers search engine optimization (SEO), performance marketing, social media marketing, content strategy, Google Analytics, digital advertising campaigns, and marketing automation.",
    "category": "Undergraduate programs",
    "keywords": [
      "bba digital marketing",
      "seo",
      "performance marketing",
      "digital campaigns"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 173,
    "question": "What is B.Com Corporate Accounting & Taxation?",
    "answer": "This specialized degree integrates corporate accounting standards (Ind-AS), direct & indirect taxation (GST & Income Tax), corporate law, auditing, and preparation for CA, CMA, or ACCA qualifications.",
    "category": "Undergraduate programs",
    "keywords": [
      "bcom taxation",
      "corporate accounting",
      "gst",
      "acca preparation",
      "cma"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 174,
    "question": "Does Presidency University provide ACCA or CMA integration with B.Com?",
    "answer": "Yes, the School of Commerce offers integrated training tracks aligned with Association of Chartered Certified Accountants (ACCA-UK) and US CMA certifications to give students global accounting credentials.",
    "category": "Undergraduate programs",
    "keywords": [
      "acca integration",
      "us cma",
      "chartered accountants",
      "global commerce"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 175,
    "question": "What is the difference between B.A. LL.B., B.B.A. LL.B., and B.Com. LL.B.?",
    "answer": "All three are 5-year integrated law degrees recognized by the Bar Council of India. B.A. LL.B. blends humanities and sociology with law; B.B.A. LL.B. focuses on corporate management and business law; B.Com. LL.B. specializes in corporate finance, taxation, and mercantile law.",
    "category": "Undergraduate programs",
    "keywords": [
      "difference in law degrees",
      "ba llb vs bba llb",
      "bcom llb",
      "which law degree"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 176,
    "question": "Does the School of Law have a Legal Aid Clinic?",
    "answer": "Yes, the School of Law runs a community Legal Aid Clinic supervised by faculty advocates that provides free legal awareness and basic counseling to underprivileged communities in surrounding rural Bangalore.",
    "category": "Student clubs",
    "keywords": [
      "legal aid clinic",
      "pro bono law",
      "community legal service",
      "law clinic"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 177,
    "question": "What facilities exist for students in the School of Design?",
    "answer": "The School of Design features specialized design drafting studios, fashion draping and garment construction labs, a ceramic and clay modeling studio, wood/metal model-making workshops, and high-end digital design suites equipped with Wacom tablets and Adobe Creative Cloud.",
    "category": "Laboratories",
    "keywords": [
      "design studios",
      "fashion lab",
      "clay studio",
      "wacom tablets",
      "garment construction"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 178,
    "question": "What career opportunities are open for Game Design graduates?",
    "answer": "Graduates of B.Des Game Design can work as game artists, level designers, 3D modelers, AR/VR experience designers, and animation specialists in gaming studios, metaverse startups, and simulation tech companies.",
    "category": "Placement information",
    "keywords": [
      "game design placements",
      "game developer jobs",
      "ar vr careers",
      "animation jobs"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 179,
    "question": "What are the career prospects for B.Sc. Medical Laboratory Technology (MLT)?",
    "answer": "B.Sc. MLT graduates work as clinical lab scientists, diagnostic laboratory managers, and research technicians in multi-specialty hospitals, pathology labs, and clinical trial organizations.",
    "category": "Placement information",
    "keywords": [
      "mlt careers",
      "medical lab jobs",
      "pathology technician",
      "hospital jobs"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 180,
    "question": "What does a B.Sc. Anesthesia & Operation Theatre Technologist do?",
    "answer": "They assist anesthesiologists and surgical teams in operating rooms, preparing anesthesia equipment, patient monitoring devices, sterilization protocols, and post-operative intensive care units.",
    "category": "Undergraduate programs",
    "keywords": [
      "anesthesia technology",
      "operation theatre jobs",
      "ot technician",
      "surgical assistance"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 181,
    "question": "What is B.Sc. Optometry and what are its clinical requirements?",
    "answer": "B.Sc. Optometry is a 4-year degree (including a 1-year clinical internship) that trains healthcare professionals to examine eyes, diagnose refractive errors, manage ocular diseases, and prescribe contact lenses and vision therapy.",
    "category": "Undergraduate programs",
    "keywords": [
      "optometry",
      "eye care",
      "clinical optometry",
      "refraction lab"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 182,
    "question": "Does Presidency University have an on-campus auditorium?",
    "answer": "Yes, the university has a world-class, fully air-conditioned convention center auditorium with over 1,200 seating capacity, modern acoustic engineering, high-definition projection systems, and stage lighting for seminars, conferences, and cultural programs.",
    "category": "Campus facilities",
    "keywords": [
      "auditorium",
      "convention center",
      "1200 capacity",
      "seminar hall"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 183,
    "question": "Are there open-air amphitheaters on campus?",
    "answer": "Yes, the campus features two large open-air amphitheaters surrounded by landscaped gardens, serving as venues for street plays, acoustic music jams, club open-mic sessions, and student gatherings.",
    "category": "Campus facilities",
    "keywords": [
      "amphitheater",
      "open air theater",
      "student gathering space"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 184,
    "question": "What are the cafeteria timings at Presidency University?",
    "answer": "The central food court operates from 7:30 AM to 8:30 PM, catering to day scholars, hostellers, and faculty. Kiosks such as Caf\u00e9 Coffee Day operate with flexible hours.",
    "category": "Campus facilities",
    "keywords": [
      "cafeteria timings",
      "food court hours",
      "canteen opening hours"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 185,
    "question": "Does Presidency University have power backup on campus?",
    "answer": "Yes, the entire campus is supported by 100% power backup through heavy-duty industrial diesel generators, ensuring uninterrupted operations in classrooms, labs, hostels, and server rooms.",
    "category": "Campus facilities",
    "keywords": [
      "power backup",
      "generator backup",
      "uninterrupted power"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 186,
    "question": "What green and eco-friendly initiatives exist on campus?",
    "answer": "The 65+ acre green campus incorporates rooftop solar energy generation, rainwater harvesting reservoirs, an on-site Sewage Treatment Plant (STP) for landscape irrigation, and an organic waste compost unit.",
    "category": "Campus facilities",
    "keywords": [
      "green campus",
      "solar power",
      "rainwater harvesting",
      "stp plant",
      "eco friendly"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 187,
    "question": "Is Wi-Fi provided inside hostel rooms?",
    "answer": "Yes, high-speed Wi-Fi with firewall protection and content filtering is accessible across all hostel rooms, common lounges, and study halls 24/7.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel wifi",
      "internet in rooms",
      "wifi speed in hostel"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 188,
    "question": "Are guests or day scholars allowed to enter student hostel rooms?",
    "answer": "No, for security and student privacy, day scholars and outside visitors are strictly prohibited from entering student hostel corridors and residential rooms. Visitors may meet residents only in designated reception lounges.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel visitors",
      "day scholars in hostel",
      "hostel guest policy"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 189,
    "question": "What laundry facilities are provided to hostel residents?",
    "answer": "Hostels provide dedicated commercial laundry services with scheduled weekly pickups and drop-offs for student clothes, alongside self-service automatic washing machines in designated utility areas.",
    "category": "Hostel facilities",
    "keywords": [
      "hostel laundry",
      "washing machine",
      "ironing service",
      "clothes wash"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 190,
    "question": "Can faculty and staff use the university buses?",
    "answer": "Yes, the university transportation network is available for students, faculty, and administrative staff who subscribe to the annual transport pass.",
    "category": "Transportation",
    "keywords": [
      "faculty bus",
      "staff transport",
      "bus for teachers"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 191,
    "question": "Is parking available on campus for personal two-wheelers and cars?",
    "answer": "Yes, Presidency University provides designated, secure parking lots inside the campus gates for student two-wheelers and staff automobiles with security guard monitoring.",
    "category": "Transportation",
    "keywords": [
      "parking facility",
      "bike parking",
      "car parking",
      "student parking"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 192,
    "question": "Does Microsoft or Amazon recruit from Presidency University?",
    "answer": "Yes, top global technology firms including Microsoft, Amazon, Infosys, Capgemini, and Dell have actively participated in campus recruitment drives and hackathon hiring for technical roles.",
    "category": "Placement information",
    "keywords": [
      "microsoft recruitment",
      "amazon placement",
      "big tech hiring",
      "tier 1 companies"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 193,
    "question": "What is the placement process for students?",
    "answer": "The placement process comprises: 1) CRC registration and resume vetting; 2) Company pre-placement talks (PPT); 3) Online aptitude and domain assessments; 4) Technical interviews / coding rounds; 5) HR interview; 6) Letter of Intent (LOI) / Offer Letter issuance.",
    "category": "Placement information",
    "keywords": [
      "placement rounds",
      "selection process",
      "campus drive steps",
      "loi"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 194,
    "question": "Are students with backlogs allowed to attend placement interviews?",
    "answer": "Most recruiting companies mandate zero standing backlogs and a minimum CGPA (typically 6.0 to 7.0). However, select companies do permit students with history of cleared backlogs.",
    "category": "Placement information",
    "keywords": [
      "backlog policy in placements",
      "cgpa cutoff for jobs",
      "placement eligibility"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 195,
    "question": "What is the Presidency Dance Crew?",
    "answer": "The Presidency Dance Crew is the official university dance ensemble that competes and wins accolades in national inter-college dance face-offs, representing Bollywood, Western, Hip-Hop, and Classical genres.",
    "category": "Student clubs",
    "keywords": [
      "dance crew",
      "dance club",
      "dance competition",
      "western dance"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 196,
    "question": "What is the Symphony Music Club?",
    "answer": "Symphony is the music club of Presidency University comprising vocalists, guitarists, drummers, and classical instrumentalists who perform at university fests, battle of bands, and acoustic unplugged sessions.",
    "category": "Student clubs",
    "keywords": [
      "music club",
      "symphony",
      "band",
      "singing club"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 197,
    "question": "What is the Dramatics and Theatre Society?",
    "answer": "The Dramatics Club produces full-length proscenium plays, street plays (Nukkad Natak), and mime acts addressing contemporary socio-political issues and participating in state drama fests.",
    "category": "Student clubs",
    "keywords": [
      "theatre club",
      "dramatics",
      "street play",
      "nukkad natak"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 198,
    "question": "Does Presidency University have a Photography and Media Club?",
    "answer": "Yes, 'Shutterbugs', the official photography and videography club, documents campus events, runs creative photo-walks, and manages visual coverage of festivals like Invincia.",
    "category": "Student clubs",
    "keywords": [
      "photography club",
      "shutterbugs",
      "videography",
      "photo walks"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 199,
    "question": "Can I change my branch in B.Tech after the first year?",
    "answer": "Yes, branch change at the end of the first year (2nd semester) is permitted subject to vacancy in the target branch and based on the candidate's CGPA in the first year as per university regulations.",
    "category": "Admission process",
    "keywords": [
      "branch change",
      "sliding branch",
      "change to cse",
      "cgpa for branch change"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 200,
    "question": "What is the grading system at Presidency University?",
    "answer": "Presidency University follows the 10-point Cumulative Grade Point Average (CGPA) system as prescribed by the UGC, with letter grades ranging from O (Outstanding) to F (Fail).",
    "category": "Frequently asked questions",
    "keywords": [
      "grading system",
      "cgpa",
      "10 point scale",
      "sgpa to cgpa",
      "ugc grading"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 201,
    "question": "What is the medium of instruction for all courses?",
    "answer": "The medium of instruction, examination, and academic interaction for all programs at Presidency University is English.",
    "category": "Frequently asked questions",
    "keywords": [
      "medium of instruction",
      "english medium",
      "language of classes"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 202,
    "question": "Are there student exchange programs with foreign universities?",
    "answer": "Yes, Presidency University has signed Memorandums of Understanding (MoUs) with renowned foreign universities across the UK, USA, France, and Asia for faculty exchange, student summer schools, and collaborative research.",
    "category": "University overview",
    "keywords": [
      "foreign exchange",
      "mou with foreign universities",
      "study abroad",
      "international collaborations"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 203,
    "question": "How does the university assist students with mental wellness and counseling?",
    "answer": "The university provides a dedicated Student Counseling and Wellness Centre with certified psychologists offering confidential, empathetic counseling for stress management, academic balance, and personal well-being.",
    "category": "Frequently asked questions",
    "keywords": [
      "counseling center",
      "mental wellness",
      "student psychologist",
      "stress management"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 204,
    "question": "Does Presidency University have an Equal Opportunity and Grievance Cell?",
    "answer": "Yes, the university maintains an Equal Opportunity Cell, Internal Complaints Committee (ICC), and an Online Student Grievance Redressal Portal to ensure an inclusive, fair, and safe campus environment for all.",
    "category": "Frequently asked questions",
    "keywords": [
      "grievance cell",
      "internal complaints committee",
      "icc",
      "equal opportunity"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 205,
    "question": "What are the subjects in B.Tech Civil Engineering with Smart Infrastructure?",
    "answer": "It incorporates Building Information Modeling (BIM), Smart Transportation Systems, Sustainable Green Construction, Geotechnical Sensors, and GIS & Remote Sensing technologies alongside core structural mechanics.",
    "category": "Undergraduate programs",
    "keywords": [
      "civil smart infrastructure",
      "bim",
      "green construction",
      "gis"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 206,
    "question": "What is the curriculum for B.Sc Medical Imaging Technology (Radiology)?",
    "answer": "The program trains students in X-Ray radiography, Computed Tomography (CT), Magnetic Resonance Imaging (MRI), Ultrasonography, and radiation safety protocols with clinical hospital postings.",
    "category": "Undergraduate programs",
    "keywords": [
      "medical imaging",
      "radiology",
      "mri",
      "ct scan",
      "radiography"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 207,
    "question": "What is B.Sc Renal Dialysis Technology?",
    "answer": "The program prepares allied healthcare professionals to operate hemodialysis equipment, monitor kidney patients during dialysis procedures, administer dialyzer fluids, and assist nephrologists.",
    "category": "Undergraduate programs",
    "keywords": [
      "dialysis technology",
      "hemodialysis",
      "kidney care",
      "renal tech"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 208,
    "question": "What is B.Sc Cardiac Care Technology?",
    "answer": "B.Sc Cardiac Care Technology trains students in electrocardiography (ECG), echocardiography, treadmill stress testing, and cardiac catheterization laboratory assisting for cardiovascular diagnostics.",
    "category": "Undergraduate programs",
    "keywords": [
      "cardiac care",
      "ecg",
      "echo test",
      "cath lab",
      "heart diagnosis"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 209,
    "question": "What specializations are available in M.Tech Computer Science?",
    "answer": "M.Tech CSE offers concentrations in Advanced Cloud Computing, Deep Learning & Autonomous Systems, Big Data Architectures, and Cyber Security & Cryptography.",
    "category": "Postgraduate programs",
    "keywords": [
      "mtech cse specializations",
      "cloud computing mtech",
      "autonomous systems"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 210,
    "question": "What is the eligibility for Ph.D. programs at Presidency University?",
    "answer": "Candidates must hold a Master's degree in a relevant field with at least 55% marks (50% for SC/ST/OBC non-creamy layer) and qualify the Presidency University Ph.D. Entrance Test (PUPET) followed by a research interview. UGC-NET/JRF/GATE qualified candidates are exempted from the written test.",
    "category": "Postgraduate programs",
    "keywords": [
      "phd eligibility",
      "pupet",
      "net jrf exemption",
      "doctorate criteria"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 211,
    "question": "What is the duration of Ph.D. programs?",
    "answer": "The minimum duration is 3 years for full-time scholars and 4 years for part-time scholars, up to a maximum duration of 6 years in accordance with UGC Ph.D. Regulations.",
    "category": "Postgraduate programs",
    "keywords": [
      "phd duration",
      "full time phd",
      "part time phd",
      "doctoral timeframe"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 212,
    "question": "Can I pay university fees in installments?",
    "answer": "Yes, under legitimate financial hardship or upon request during admission, the university permits fees to be paid in two equal semester-wise installments upon approval by the Finance Office.",
    "category": "Fee structure",
    "keywords": [
      "fee installments",
      "pay in parts",
      "semester installment",
      "split fee"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 213,
    "question": "What is the refund timeline for fee cancellation?",
    "answer": "Eligible refunds as per UGC rules are processed and credited to the applicant's verified bank account within 15 to 30 working days from the date of formal withdrawal application approval.",
    "category": "Important notices",
    "keywords": [
      "refund timeline",
      "cancellation refund days",
      "bank credit refund"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 214,
    "question": "Does Presidency University have an on-campus stationery and book shop?",
    "answer": "Yes, there is an on-campus stationery, textbook, and reprographic (photocopy/printing) store situated in the student amenities complex for all course materials.",
    "category": "Campus facilities",
    "keywords": [
      "stationery shop",
      "bookstore",
      "photocopy shop",
      "printing facility"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 215,
    "question": "What is the policy for students bringing four-wheelers to campus?",
    "answer": "Hostel students are discouraged from keeping cars on campus due to space regulation. Day scholars with valid driver's licenses may register their vehicle with the security office to obtain a vehicle entry pass.",
    "category": "Hostel facilities",
    "keywords": [
      "student cars",
      "vehicle registration",
      "parking permit",
      "four wheeler policy"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 216,
    "question": "Does Presidency University have an Apple Authorized Training facility?",
    "answer": "Yes, the School of Engineering hosts an Apple Mac lab equipped with iMac workstations for iOS app development, Swift programming, and macOS software engineering.",
    "category": "Laboratories",
    "keywords": [
      "apple lab",
      "imac",
      "swift programming",
      "ios development"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 217,
    "question": "What is the role of the Proctorial Board at Presidency University?",
    "answer": "The Proctorial Board is responsible for maintaining campus discipline, investigating code of conduct violations, supervising campus security, and ensuring a peaceful, safe learning environment.",
    "category": "Frequently asked questions",
    "keywords": [
      "proctorial board",
      "discipline",
      "chief proctor",
      "campus rules"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 218,
    "question": "Does Presidency University offer foreign language classes?",
    "answer": "Yes, through the Centre for Languages, students can opt for certification courses in German, French, Japanese, and Spanish to enhance their international employability.",
    "category": "Courses and departments",
    "keywords": [
      "foreign languages",
      "german class",
      "french course",
      "japanese language"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 219,
    "question": "What happens during the first-year Orientation Week?",
    "answer": "Orientation Week features addresses by the Chancellor and Vice-Chancellor, departmental curriculum walkthroughs, campus tours, Icebreaker games, club showcases, and anti-ragging/safety briefings.",
    "category": "Campus events",
    "keywords": [
      "orientation week",
      "freshers orientation",
      "icebreaker",
      "induction program"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 220,
    "question": "Are hackathons conducted exclusively for first-year students?",
    "answer": "Yes, the university organizes 'Freshers Hackathon' and beginner coding challenges to introduce first-year engineering students to collaborative programming, git, and problem-solving.",
    "category": "Campus events",
    "keywords": [
      "freshers hackathon",
      "beginner coding",
      "first year coding"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 221,
    "question": "What is the placement record of the School of Law?",
    "answer": "Graduates from the School of Law have secured placements with leading corporate law firms (such as Cyril Amarchand Mangaldas, Trilegal, and Khaitan & Co alumni networks), in-house corporate legal teams, litigation chambers, and judicial clerkships.",
    "category": "Placement information",
    "keywords": [
      "law placements",
      "law firms",
      "legal careers",
      "trilegal",
      "cyril amarchand"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 222,
    "question": "What is the placement record of MBA graduates?",
    "answer": "MBA students secure positions in top financial institutions, consulting firms, FMCG companies, and tech firms like EY, KPMG, ICICI Bank, Berger Paints, Deloitte, and Amazon with average CTCs of \u20b95-6.5 LPA.",
    "category": "Placement information",
    "keywords": [
      "mba placement record",
      "marketing jobs",
      "finance jobs",
      "kpmg",
      "deloitte"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 223,
    "question": "Does Presidency University offer remedial classes for weak students?",
    "answer": "Yes, departments schedule remedial and bridge tutorials on Saturdays and after regular class hours for students who need extra academic reinforcement in difficult engineering mathematics or core subjects.",
    "category": "Frequently asked questions",
    "keywords": [
      "remedial classes",
      "bridge course",
      "doubt clearing",
      "tutorial support"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 224,
    "question": "How are student council and class representatives selected?",
    "answer": "Class representatives and student council delegates are selected annually based on academic merit, leadership qualities, and faculty committee recommendations through the Directorate of Student Affairs.",
    "category": "Campus life",
    "keywords": [
      "student council",
      "class representative",
      "cr selection",
      "student leadership"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 225,
    "question": "What is the campus recycling and waste management system?",
    "answer": "The university segregates waste at source into dry, wet, and e-waste. Wet waste is converted into organic fertilizer for campus gardens, while plastic and paper are sent to authorized green recyclers.",
    "category": "Campus facilities",
    "keywords": [
      "waste management",
      "recycling",
      "green initiatives",
      "compost"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 226,
    "question": "What is the policy for students participating in external hackathons or sports meets?",
    "answer": "Students representing Presidency University in recognized national fests, hackathons, or university sports meets are granted Official Duty (OD) attendance credit for the duration of the competition.",
    "category": "Frequently asked questions",
    "keywords": [
      "od attendance",
      "official duty",
      "external hackathon permission",
      "attendance for sports"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 227,
    "question": "What healthcare insurance is provided to students?",
    "answer": "All enrolled students are covered under a group student accidental medical insurance policy for emergency hospitalization and care throughout their duration of study.",
    "category": "Frequently asked questions",
    "keywords": [
      "medical insurance",
      "health insurance",
      "student coverage",
      "emergency cover"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 228,
    "question": "Can students access the campus on Sundays or holidays?",
    "answer": "Hostel residents have access to student activity areas and dining halls on all days. Day scholars requiring access to laboratories or library for projects must carry valid ID cards and faculty permission passes.",
    "category": "Frequently asked questions",
    "keywords": [
      "sunday campus access",
      "holiday access",
      "weekend library"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 229,
    "question": "What is the official procedure to get a Bonafide Certificate?",
    "answer": "Students can apply for a Bonafide Certificate (for passport, bus pass, or bank loan) through their student ERP account, which is typically processed and digitally signed within 48 hours.",
    "category": "Frequently asked questions",
    "keywords": [
      "bonafide certificate",
      "passport letter",
      "student certificate"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 230,
    "question": "What is the incubation support provided to student entrepreneurs?",
    "answer": "The Centre for Innovation, Incubation and Entrepreneurship (CIIE) provides legal incorporation assistance, patent filing grants, prototype testing labs, and connects student founders with angel investors in Bangalore.",
    "category": "Career services",
    "keywords": [
      "startup support",
      "incubation",
      "patent grant",
      "angel investor"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 231,
    "question": "Are there guest houses available on campus for visiting parents?",
    "answer": "Yes, the university provides comfortable, air-conditioned guest room suites on campus for visiting parents at subsidized daily rates, subject to prior booking through the Registrar / Estate Office.",
    "category": "Hostel facilities",
    "keywords": [
      "guest house",
      "parents stay",
      "accommodation for parents",
      "guest rooms"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 232,
    "question": "What is the policy on mobile phones in classrooms?",
    "answer": "Mobile phones must be kept on silent mode inside classrooms and lecture halls and may only be used when permitted by faculty for educational activities (such as digital quizzes or research lookups).",
    "category": "Frequently asked questions",
    "keywords": [
      "mobile phone policy",
      "phones in class",
      "classroom rules"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 233,
    "question": "Does Presidency University have an active alumni association?",
    "answer": "Yes, the Presidency University Alumni Association (PUAA) connects thousands of graduates across the globe, organizing annual reunions, chapter meets in major tech hubs, and mentoring sessions for graduating batches.",
    "category": "University overview",
    "keywords": [
      "alumni association",
      "puaa",
      "alumni network",
      "reunions"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 234,
    "question": "How do I contact the IT Helpdesk for WiFi or ERP issues?",
    "answer": "Students can reach the campus IT Helpdesk at ithelpdesk@presidencyuniversity.in or visit the IT Support Centre on the ground floor of the Academic Block.",
    "category": "Contact details",
    "keywords": [
      "it helpdesk",
      "wifi issue",
      "erp password reset",
      "tech support"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 235,
    "question": "What is the contact email for hostel admission queries?",
    "answer": "For hostel bookings and queries, students can email: hostel@presidencyuniversity.in or call the Chief Warden's desk via the university board line 080 4925 5555.",
    "category": "Contact details",
    "keywords": [
      "hostel email",
      "hostel contact",
      "chief warden",
      "book hostel room"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 236,
    "question": "What is the contact email for university bus transport?",
    "answer": "For bus route inquiries and transportation passes, contact the Transport Department at transport@presidencyuniversity.in.",
    "category": "Contact details",
    "keywords": [
      "transport email",
      "bus contact",
      "transport office email"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 237,
    "question": "What is the procedure for verification of educational credentials by employers?",
    "answer": "Employers and background verification agencies must send an official verification request along with student degree/marksheet copy to registrar@presidencyuniversity.in or coe@presidencyuniversity.in.",
    "category": "Contact details",
    "keywords": [
      "background verification",
      "degree verification",
      "employer check",
      "transcript check"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 238,
    "question": "Where can I find the official academic calendar?",
    "answer": "The official academic calendar specifying semester start dates, mid-term tests, fest dates, holidays, and end-term exams is published at https://presidencyuniversity.in/ and in the student ERP dashboard.",
    "category": "Important notices",
    "keywords": [
      "academic calendar",
      "semester schedule",
      "holiday list",
      "exam dates calendar"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 240,
    "question": "Where is the cafeteria or food court located on campus?",
    "answer": "The main multi-cuisine Food Court and Cafeteria is located on the **Ground Floor of the Central Student Amenities Block** (adjacent to Academic Block 1 and directly facing the central landscaped green lawns).\n\n🚶 **Step-by-Step Walking Directions from Main Campus Entrance:**\n1. **Enter Campus**: Arrive at the Main Entrance Gate / Welcome Canopy on Doddaballapur Main Road (Rajanakunte).\n2. **Pass Admin Block**: Walk straight past the Admissions & Administrative Block (Block A) on your right.\n3. **Cross Central Quadrangle**: Walk straight across the central landscaped green lawns (~120 metres ahead).\n4. **Arrive at Amenities Block**: The Student Amenities Block is directly ahead facing the courtyard. Enter through the main doors to access the Ground Floor Food Court.\n\n🍴 **Key Food & Beverage Outlets on Campus:**\n• **Central Food Court**: Ground floor, Student Amenities Block. Serves authentic South Indian, North Indian, Chinese meals, biryani, and continental snacks with 1,200+ seating capacity.\n• **Café Coffee Day (CCD)**: Stationed near Academic Block 2 entrance and the Central Library concourse.\n• **Nescafe Outlets & Juice Kiosks**: Stationed near the Engineering complex, Indoor Sports complex, and Hostel promenade.\n• **Operating Timings**: Daily from 7:30 AM to 8:30 PM for day scholars, resident students, faculty, and campus visitors.\n\n[📍 Open Campus on Google Maps](https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru) • [🧭 Live Turn-by-Turn Navigation](https://www.google.com/maps/dir/?api=1&destination=Presidency+University+Bengaluru)",
    "category": "Location and campus",
    "keywords": [
      "location of cafeteria",
      "cafeteria location",
      "where is cafeteria",
      "where is food court",
      "location for cafeteria",
      "canteen location",
      "where is canteen",
      "food court location",
      "where to eat",
      "ccd location",
      "cafe coffee day location",
      "eating places on campus",
      "dining hall location",
      "cafetria location",
      "loaction for cafetria",
      "loaction cafeteria",
      "where is the cafeteria located",
      "directions to cafeteria",
      "how to reach cafeteria",
      "directions for cafeteria",
      "cafeteria directions",
      "cafetria",
      "canteen",
      "food court",
      "where is cafetria",
      "cafetria directions",
      "directions to cafetria",
      "where actually it is",
      "cafeteria navigation",
      "canteen directions",
      "google maps"
    ],
    "sourceUrl": "https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru",
    "sourceTitle": "Google Maps – Presidency University Bengaluru",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 241,
    "question": "Where is the Central Library located on campus?",
    "answer": "The Central Library (Dr. APJ Abdul Kalam Central Library) is centrally located within the Main Academic Complex, occupying the 1st and 2nd floors directly connected to Academic Blocks 1 and 2.\n\nHighlights & Accessibility:\n• **Location**: 1st & 2nd Floor, Central Academic Complex.\n• **Facilities**: KOHA RFID automated circulation desks, digital library with 100+ high-speed browsing systems, Knimbus remote digital database access, reference reading halls, and silent research cubicles.\n• **Timings**: Monday to Saturday: 8:00 AM to 8:00 PM (extended till 10:00 PM during mid-term and semester final examinations).",
    "category": "Location and campus",
    "keywords": [
      "library location",
      "where is library",
      "location of library",
      "central library location",
      "where is the library",
      "books location",
      "reading room location",
      "koha library where",
      "library building"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 242,
    "question": "Where is the Admissions Office and Counselling Centre located on campus?",
    "answer": "The University Admissions & Counselling Centre is situated on the Ground Floor of the Main Administrative Block (Block A), located immediately past the main campus entrance circle.\n\nVisitor Directions:\n• **On-Campus Office**: Ground Floor, Main Administrative Block (Block A), Presidency University, Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064.\n• **City Admissions Office**: University House, 8/1, King Street, Richmond Town, Bengaluru – 560025.\n• **Walk-in Hours**: Monday to Saturday: 9:00 AM to 5:30 PM.\n• **Assistance**: Dedicated admission counselors, document verification counters, eligibility checks, and campus tour coordinators are available on-site.",
    "category": "Location and campus",
    "keywords": [
      "admissions office location",
      "where is admissions office",
      "where to apply",
      "admission desk location",
      "where is counselling centre",
      "admission block",
      "walk in admission location",
      "admin block location",
      "where is admin office",
      "registrar office location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 243,
    "question": "Where is the School of Engineering (SOE) located on campus?",
    "answer": "The School of Engineering (SOE) spans Academic Blocks 1, 2, and 3 located in the northern and central sector of the campus.\n\nDepartment Layout:\n• **Block 1**: Department of Computer Science & Engineering (CSE), AI & Machine Learning, Data Science labs, and High-Performance GPU Computing centers.\n• **Block 2**: Electronics & Communication (ECE), Electrical & Electronics (EEE), and IoT Innovation Labs.\n• **Block 3 & Workshop Complex**: Mechanical Engineering, Mechatronics & Robotics Workshops, Civil Engineering Structural Labs, and Petroleum Engineering testing labs.\n• Modern elevator access, digital smart classrooms, and faculty consultation cubicles are available on all floors.",
    "category": "Location and campus",
    "keywords": [
      "engineering block location",
      "where is engineering block",
      "soe location",
      "cse block location",
      "computer science department location",
      "mechanical workshop location",
      "engineering labs where",
      "robotics lab location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 244,
    "question": "Where is the School of Management (SOM) located on campus?",
    "answer": "The School of Management (SOM) is located in Academic Block 2 (Floors 2 and 3).\n\nFeatures:\n• State-of-the-art amphitheater-style Harvard case-study lecture halls, executive corporate seminar rooms, digital finance lab (Bloomberg terminals), and incubation center for student startups.\n• Easily accessible from the Central Academic Lawn and main concourse.",
    "category": "Location and campus",
    "keywords": [
      "som location",
      "management block location",
      "where is mba block",
      "where is bba department",
      "school of management where",
      "business school location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 245,
    "question": "Where is the School of Law and Moot Court located on campus?",
    "answer": "The School of Law (SOL) is housed in a dedicated wing of Academic Block 1 (West Wing).\n\nKey Highlights:\n• **Moot Court Hall**: Located on the 1st Floor, fully air-conditioned, designed to replicate Supreme Court and High Court proceedings with digital recording and judges' bench.\n• **Legal Aid Clinic**: Ground Floor, School of Law wing, providing free community legal advice to adopted villages.\n• **Law Library**: Dedicated legal resource library holding complete SCC Online, Manupatra, LexisNexis, and AIR volumes.",
    "category": "Location and campus",
    "keywords": [
      "moot court location",
      "where is moot court",
      "school of law location",
      "where is law block",
      "sol location",
      "legal aid clinic location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 246,
    "question": "Where is the School of Design (SOD) located on campus?",
    "answer": "The School of Design (SOD) is located on the 3rd and 4th Floors of Academic Block 3.\n\nFacilities:\n• Fully equipped Apple iMac design studios, 3D prototyping labs, laser cutters, fashion draping and garment construction labs, space design drafting studios, and an open student exhibition gallery.",
    "category": "Location and campus",
    "keywords": [
      "design block location",
      "where is design school",
      "school of design location",
      "fashion design lab where",
      "product design studio location",
      "sod location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 247,
    "question": "Where are the student hostels located on campus?",
    "answer": "Presidency University has separate on-campus and near-campus residential zones for boys and girls:\n\n• **Girls' Hostels**: Located in a dedicated, high-security residential enclave on the eastern perimeter of the campus with 24/7 biometric security turnstiles, female security personnel, resident wardens, and separate dining mess.\n• **Boys' Hostels**: Located on the western residential wing of the campus, featuring biometric access, multi-purpose recreation halls, indoor games, and dining hall.\n• **Safety & Amenities**: Solar water heaters, laundry facilities, high-speed Wi-Fi, 24/7 power backup, RO drinking water plants, and resident doctor medical backup.",
    "category": "Location and campus",
    "keywords": [
      "hostel location",
      "where are hostels",
      "where is boys hostel",
      "where is girls hostel",
      "hostels on campus location",
      "hostel address",
      "student residence location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 248,
    "question": "Where is the ATM and banking facility located on campus?",
    "answer": "A 24/7 automated Bank of Baroda ATM and banking counter is located on the Ground Floor near the Main Campus Security Gate (Entrance Plaza), adjacent to the Student Amenities Block.\n\nFeatures:\n• 24-hour cash withdrawal, deposit machine, and passbook printing.\n• Operates seamlessly for day scholars, resident hostel students, faculty, and visiting parents.",
    "category": "Location and campus",
    "keywords": [
      "atm location",
      "where is atm",
      "bank on campus",
      "cash machine location",
      "where to withdraw money",
      "bank of baroda atm",
      "atm near campus"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 249,
    "question": "Where is the Health Care Centre and Medical Clinic located on campus?",
    "answer": "The University Health Care Centre (Infirmary) is located on the Ground Floor of the Student Amenities Block (adjacent to the Food Court).\n\nServices Available:\n• 24/7 on-duty medical officer (doctor) and certified nursing staff.\n• Emergency observation beds, essential medicine dispensary, first-aid and trauma stabilization.\n• Dedicated 24/7 campus ambulance stationed outside the Amenities Block for immediate transit to tertiary multispecialty partner hospitals in Yelahanka.",
    "category": "Location and campus",
    "keywords": [
      "medical centre location",
      "health centre location",
      "where is clinic",
      "where is doctor on campus",
      "hospital on campus",
      "infirmary location",
      "ambulance where",
      "first aid location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 250,
    "question": "Where is the University Auditorium and Seminar Halls located?",
    "answer": "The University features a grand central auditorium and multiple seminar complexes:\n\n• **Main University Auditorium**: Located on the Ground Floor of the Central University Block, with 1,000+ tiered seating, acoustic sound engineering, and dual 4K multimedia projection for convocations, Invincia inaugurations, and national symposiums.\n• **Engineering Seminar Hall**: 1st Floor, Academic Block 1 (250 seating).\n• **Management Executive Hall**: 2nd Floor, Academic Block 2 (200 seating).\n• **Open Air Amphitheatre**: Centrally located between Academic Blocks 1 and 2, surrounded by green lawns for student performances, open-mic sessions, and club activities.",
    "category": "Location and campus",
    "keywords": [
      "auditorium location",
      "where is auditorium",
      "seminar hall location",
      "where is amphitheatre",
      "convocation hall location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 251,
    "question": "Where are the sports grounds, football turf, and gymnasium located on campus?",
    "answer": "The sports infrastructure is spread across the expansive southern and western sports zone of the 65-acre campus:\n\n• **Football Turf & Cricket Oval**: Large natural grass stadium situated on the southern perimeter.\n• **Basketball & Tennis Courts**: Floodlit synthetic courts located adjacent to Academic Block 3.\n• **Indoor Sports Complex & Gymnasium**: Located near the Student Amenities Block, featuring wooden-floor badminton courts, table tennis tables, and a fully equipped cardio & strength training gym with certified fitness trainers.",
    "category": "Location and campus",
    "keywords": [
      "sports ground location",
      "where is gym",
      "gymnasium location",
      "football turf location",
      "cricket ground location",
      "basketball court location",
      "sports complex where"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 252,
    "question": "Where is visitor and student parking, and the university bus bay located?",
    "answer": "Vehicle parking and transportation hubs are situated near the campus perimeter for a pedestrian-safe campus:\n\n• **Visitor Parking**: Dedicated 4-wheeler and 2-wheeler visitor parking is located immediately to the right of the Main Security Gate at the campus entrance.\n• **Student & Faculty Parking**: Designated multi-bay parking lot with security surveillance located near the entrance gate.\n• **University Bus Bay**: A dedicated 50-bus parking bay with lane-wise GPS tracking and sheltered passenger boarding platforms is situated on the outer perimeter road near Gate 2.",
    "category": "Location and campus",
    "keywords": [
      "parking location",
      "where to park",
      "visitor parking",
      "bus bay location",
      "where do buses stop",
      "car parking where",
      "bike parking location"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Campus Guide",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 253,
    "question": "How do visitors navigate Presidency University / what is the campus layout?",
    "answer": "Presidency University Bengaluru is an eco-friendly 65-acre pedestrian-friendly campus. Here is a quick navigation guide for visitors and new students:\n\n1. **Main Entrance Gate**: On Rajanakunte-Doddaballapur Road. Stop at the Security Reception for visitor entry pass and parking.\n2. **Main Administrative Block (Block A)**: Straight ahead from the entrance circle. Houses Chancellor's Office, Registrar, Admissions & Counselling Centre (Ground Floor).\n3. **Central Academic Lawn**: Heart of the campus connecting Academic Block 1 (Engineering/Law), Block 2 (Management/ECE), and Block 3 (Design/Labs).\n4. **Student Amenities Block**: Located to the right of the Central Lawn. Houses the Multi-Cuisine Food Court (Ground Floor), Health Care Centre, and ATM.\n5. **Central Library**: 1st & 2nd floors linking Academic Blocks 1 and 2.\n6. **Residential Hostels & Sports Ground**: Located in the western and southern perimeter zones.\n\nSignage boards and directional maps are installed at every intersection, and campus security staff are stationed at each block to guide visitors.\n\n[📍 Open Campus on Google Maps](https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru) • [🧭 Live Turn-by-Turn Navigation](https://www.google.com/maps/dir/?api=1&destination=Presidency+University+Bengaluru)",
    "category": "Location and campus",
    "keywords": [
      "campus map",
      "campus layout",
      "how to navigate campus",
      "visitor guide",
      "directions inside campus",
      "where is everything",
      "campus tour",
      "map of presidency university",
      "loaction of campus",
      "google maps",
      "campus navigation",
      "directions"
    ],
    "sourceUrl": "https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru",
    "sourceTitle": "Google Maps – Presidency University Bengaluru",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 254,
    "question": "I am interested in robotics, which course should I take at Presidency University?",
    "answer": "If you are interested in robotics, automation, and intelligent machines, Presidency University Bengaluru offers specialized industry-aligned programs tailored to your specific focus:\n\n1. **B.Tech in Mechatronics Engineering** (Top Recommendation):\n• Combines mechanical engineering, electronics, computer science, and control systems.\n• Key Subjects: Industrial Robotics, Kinematics & Dynamics, Sensor Fusion, Microcontrollers, PLC Automation, Drone Technology, and ROS (Robot Operating System).\n\n2. **B.Tech in Computer Science and Engineering (AI & Machine Learning)**:\n• Ideal if your interest is in software intelligence, robotic computer vision, autonomous navigation, reinforcement learning, and neural network control.\n\n3. **B.Tech in Mechanical Engineering (Specialization in Robotics & Automation)**:\n• Focuses on mechanical actuator design, pneumatic/hydraulic robotic arms, CAD/CAM, and automated manufacturing systems.\n\n4. **B.Tech in Electronics & Communication Engineering (ECE - Embedded Systems & IoT)**:\n• Focuses on robotic hardware controller boards, sensor networks, microprocessors, and wireless robotics.\n\n**Campus Robotics Labs & Opportunities**:\n• Advanced Robotics & Mechatronics Workshop with industrial robot arms.\n• IEEE Robotics Chapter and Presidency Innovation & Maker Lab for building combat robots and participating in Smart India Hackathon and e-Yantra.\n\nTo apply for these programs for 2026-27, visit the Admissions Office or call the helpline at +91 90220 92222.",
    "category": "Courses and departments",
    "keywords": [
      "robotics",
      "robotics course",
      "interested in robotics",
      "which course for robotics",
      "whic source i need to take",
      "am intrested in robotics",
      "robotics engineering",
      "mechatronics",
      "mechatronics engineering",
      "automation course",
      "robot course",
      "which course to take for robotics",
      "robotics degree",
      "btech robotics",
      "drone engineering",
      "source for robotics"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 255,
    "question": "I am interested in Artificial Intelligence (AI) and Data Science, which course should I take?",
    "answer": "Presidency University offers leading computing programs for students aiming for careers in AI and Big Data:\n\n1. **B.Tech CSE (Artificial Intelligence & Machine Learning)**: Comprehensive engineering degree covering Deep Learning, NLP, Generative AI, Computer Vision, and PyTorch/TensorFlow.\n2. **B.Tech CSE (Data Science)**: Focuses on predictive statistical modeling, Big Data Hadoop/Spark architectures, data warehousing, and business intelligence.\n3. **BCA (AI & Machine Learning Specialization)**: 3-year undergraduate degree with heavy coding, Python, full-stack, and applied AI.\n4. **MCA (Data Science & AI Track)**: Postgraduate masters for advanced software engineers and AI developers.\n\nEligibility: 10+2 PCM with min 45% (40% for SC/ST) for B.Tech; 10+2 with Mathematics/CS for BCA.",
    "category": "Courses and departments",
    "keywords": [
      "interested in ai",
      "artificial intelligence course",
      "ai course to take",
      "data science course",
      "which course for ai",
      "btech cse ai ml",
      "ai degree"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 256,
    "question": "I am interested in Cyber Security and Ethical Hacking, which course should I take?",
    "answer": "For careers in ethical hacking, information defense, and network security, Presidency University offers:\n\n• **B.Tech CSE (Cyber Security)**: 4-year engineering program covering Cryptography, Penetration Testing, Malware Analysis, Network Defense, Cloud Security, Cyber Forensics, and Blockchain technology.\n• **Industry Labs**: Dedicated Cyber Security Centre of Excellence with live threat-simulation sandboxes.\n• **Careers**: Security Analyst, Penetration Tester, Chief Information Security Officer (CISO) track, and Cloud Security Engineer.",
    "category": "Courses and departments",
    "keywords": [
      "interested in cyber security",
      "ethical hacking course",
      "cyber security course",
      "which course for hacking",
      "btech cyber security"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 257,
    "question": "I am interested in Business Management and Entrepreneurship, which course should I take?",
    "answer": "Presidency University offers premier management programs across undergraduate and postgraduate levels:\n\n1. **BBA (General & Honors)**: Core management grounding in Marketing, Finance, HR, and Operations.\n2. **BBA Specializations**: BBA in Business Analytics, BBA in Aviation Management, and BBA in Digital Marketing.\n3. **MBA (2-Year Full-Time)**: Dual specializations in Marketing, Finance, HR, Business Analytics, and Logistics & Supply Chain Management.\n• Features Bloomberg finance lab, Harvard case studies, paid corporate internships, and incubation funding for student startups.",
    "category": "Courses and departments",
    "keywords": [
      "interested in business",
      "management course",
      "which course for mba",
      "bba course",
      "entrepreneurship course",
      "business administration"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Management",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 258,
    "question": "I am interested in Law and Corporate Legal Practice, which course should I take?",
    "answer": "Presidency University School of Law (approved by the Bar Council of India) offers 5-Year Integrated Honors Law programs:\n\n1. **B.A. LL.B. (Hons)**: Ideal for litigation, constitutional law, public policy, civil services, and criminal defense.\n2. **B.B.A. LL.B. (Hons)**: Perfect for corporate mergers & acquisitions, intellectual property rights (IPR), compliance, and contract law.\n3. **B.Com. LL.B. (Hons)**: Tailored for corporate taxation, banking & finance law, securities law, and fintech regulation.\n• Highlights: Air-conditioned Supreme Court replica Moot Court Hall, Legal Aid Cell, and mandatory internships with top law firms and judges.",
    "category": "Courses and departments",
    "keywords": [
      "interested in law",
      "law course to take",
      "which law course",
      "ba llb",
      "bba llb",
      "law degree",
      "corporate lawyer course"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Law",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 259,
    "question": "I am interested in Design, UI/UX, and Creative Arts, which course should I take?",
    "answer": "Presidency University School of Design offers the **Bachelor of Design (B.Des - 4 Years)** with specialized creative pathways:\n\n1. **Communication Design & UI/UX**: User experience, app interfaces, graphic visual storytelling, and motion design.\n2. **Product Design**: Industrial hardware, smart wearables, ergonomics, and sustainable consumer product prototyping.\n3. **Fashion Design**: Haute couture, garment technology, textile sciences, draping, and fashion runway production.\n4. **Game Design & Digital Media**: 3D game engines, AR/VR immersive spaces, and character animation.\n• Facilities: Apple iMac suites, 3D printing labs, laser cutters, and professional studio workshops.",
    "category": "Courses and departments",
    "keywords": [
      "interested in design",
      "ui ux course",
      "fashion design course",
      "product design course",
      "which course for design",
      "bdes",
      "design degree"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Design",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 260,
    "question": "What is the fee structure for B.Tech CSE (DevOps / Cloud & DevOps) at Presidency University?",
    "answer": "Here is the verified fee structure and program details for **B.Tech Computer Science & Engineering (DevOps / Cloud & DevOps)** for the 2026-27 academic session:\n\n• **Management Quota Tuition Fee**: ₹3,00,000 to ₹3,25,000 per year (approx. ₹1,50,000 to ₹1,62,500 per semester).\n• **Total 4-Year Tuition Cost**: ~₹12,00,000 to ₹13,00,000 (payable in semester-wise installments).\n• **KCET Government Quota Fee**: Approx. ₹1,07,000 to ₹1,15,000 per year (via KEA government seat matrix).\n• **COMEDK Merit Quota Fee**: Approx. ₹2,25,000 to ₹2,40,000 per year.\n\n🛠️ **What is Covered in B.Tech CSE (DevOps):**\n• Continuous Integration & Continuous Deployment (CI/CD) pipelines with Jenkins, GitLab & GitHub Actions\n• Containerization & Orchestration: Docker, Kubernetes, Microservices\n• Infrastructure as Code (IaC): Terraform, Ansible, Puppet\n• Multi-Cloud Platforms: Amazon Web Services (AWS), Microsoft Azure, Google Cloud (GCP)\n• Site Reliability Engineering (SRE), Linux Systems Administration & Automated Cloud Testing\n\n🏆 **Merit Scholarship Concessions on Tuition Fee:**\n• 90%+ in 10+2 PCM: Up to 50% tuition waiver (Save up to ₹1,62,500/year)\n• 85% to 89.9% in PCM: Up to 30% tuition waiver\n• 80% to 84.9% in PCM: Up to 20% tuition waiver\n\n🏠 **Optional Living & Transport Costs:**\n• Campus Hostels (Food + AC/Non-AC Stay): ₹1,10,000 to ₹1,80,000 per year\n• University Commuter Bus: ₹28,000 to ₹36,000 per year\n\nFor personal counseling or admission booking, contact the Admissions Office at **+91 90220 92222** or **080 4925 5555**.",
    "category": "Fee structure",
    "keywords": [
      "fees structure for cse core devops",
      "cse devops fees",
      "btech cse devops fee",
      "devops fee structure",
      "cse devops fee",
      "devops fees",
      "cse core devops fee",
      "fees for cse devops",
      "cse devops cost",
      "cloud and devops fees",
      "devops tuition",
      "fess structure cor cse core devops",
      "fess structure cse devops",
      "fee structure for cse devops",
      "devops course fees",
      "cse devops per year fee",
      "what is the fess structure cor cse core devops"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Computer Science & Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 261,
    "question": "What is the fee structure for each and every core track under B.Tech CSE at Presidency University?",
    "answer": "Here is the complete, granular fee structure breakdown for **each and every core specialization track under B.Tech Computer Science and Engineering (CSE)** at Presidency University Bengaluru (2026-27):\n\n1. **B.Tech CSE (Core / General)**:\n• Management Quota: ₹2,75,000 to ₹3,00,000/year (Total 4-Yr: ~₹11.0L - ₹12.0L)\n• Focus: Data Structures, Algorithms, OS, DBMS, Computer Networks, Software Engineering\n\n2. **B.Tech CSE - DevOps (Cloud & DevOps Engineering)**:\n• Management Quota: ₹3,00,000 to ₹3,25,000/year (Total 4-Yr: ~₹12.0L - ₹13.0L)\n• Focus: CI/CD, Docker, Kubernetes, Terraform, AWS/Azure, SRE Automation\n\n3. **B.Tech CSE - Artificial Intelligence & Machine Learning (AI & ML)**:\n• Management Quota: ₹3,25,000 to ₹3,50,000/year (Total 4-Yr: ~₹13.0L - ₹14.0L)\n• Focus: Deep Learning, Neural Networks, Computer Vision, NLP, NVIDIA GPU Computing\n\n4. **B.Tech CSE - Data Science & Big Data Analytics**:\n• Management Quota: ₹3,00,000 to ₹3,25,000/year (Total 4-Yr: ~₹12.0L - ₹13.0L)\n• Focus: Hadoop, Apache Spark, Python Data Analysis, Predictive Modeling, PowerBI\n\n5. **B.Tech CSE - Cyber Security & Digital Forensics**:\n• Management Quota: ₹3,00,000 to ₹3,25,000/year (Total 4-Yr: ~₹12.0L - ₹13.0L)\n• Focus: Ethical Hacking, SOC Operations, Cryptography, Network Defense, Penetration Testing\n\n6. **B.Tech CSE - Cloud Computing & Virtualization**:\n• Management Quota: ₹3,00,000 to ₹3,25,000/year (Total 4-Yr: ~₹12.0L - ₹13.0L)\n• Focus: Microservices, Cloud Security, Serverless Architecture, Distributed Systems\n\n7. **B.Tech CSE - Internet of Things (IoT) & Automation**:\n• Management Quota: ₹2,80,000 to ₹3,00,000/year (Total 4-Yr: ~₹11.2L - ₹12.0L)\n• Focus: Embedded Systems, Smart Sensors, Raspberry Pi, Industrial IoT\n\n8. **B.Tech CSE - Blockchain Technology**:\n• Management Quota: ₹3,00,000 to ₹3,25,000/year (Total 4-Yr: ~₹12.0L - ₹13.0L)\n• Focus: Smart Contracts, Ethereum, Solidity, DApps, Decentralized FinTech\n\n9. **B.Tech CSE - Full Stack Development**:\n• Management Quota: ₹2,80,000 to ₹3,10,000/year (Total 4-Yr: ~₹11.2L - ₹12.4L)\n• Focus: MERN/MEAN Stack, React, Node.js, REST APIs, Agile DevOps\n\n10. **B.Tech Information Science and Engineering (ISE)**:\n• Management Quota: ₹2,60,000 to ₹2,80,000/year (Total 4-Yr: ~₹10.4L - ₹11.2L)\n\n🏛️ **Government & Entrance Quota Subsidies (All Tracks):**\n• KCET Quota: ~₹1,07,000 to ₹1,15,000 per year across all CSE tracks\n• COMEDK Quota: ~₹2,25,000 to ₹2,40,000 per year\n\n🎁 **Presidential Merit Scholarships:**\n• 90%+ in 10+2 PCM: Up to 50% tuition fee waiver\n• 85% - 89.9% in PCM: Up to 30% waiver\n• 80% - 84.9% in PCM: Up to 20% waiver\n\nAdmissions Helpline: **+91 90220 92222 / 080 4925 5555**.",
    "category": "Fee structure",
    "keywords": [
      "each and every core under cse",
      "each and every core cse",
      "all cse specializations fees",
      "cse core fee structure",
      "cse branches fee",
      "btech cse fee list",
      "fees for cse tracks",
      "cse specialization fees list",
      "fee structure for all cse branches",
      "fess structure cor cse core",
      "cse core fees",
      "fee for every cse track",
      "fees of all cse courses",
      "cse fees",
      "cse fee structure"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University Official Fee Details",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 262,
    "question": "What is the fee structure for B.Tech CSE (Core / General) at Presidency University?",
    "answer": "The fee structure for the standard **B.Tech Computer Science and Engineering (CSE - Core)** program for the 2026-27 academic year is as follows:\n\n• **Management Quota Tuition Fee**: ₹2,75,000 to ₹3,00,000 per annum (payable in two semester installments of ~₹1,37,500 to ₹1,50,000).\n• **Total 4-Year Tuition Investment**: ~₹11,00,000 to ₹12,00,000.\n• **KCET Government Merit Seat**: ~₹1,07,000 to ₹1,15,000 per year.\n• **COMEDK Quota Seat**: ~₹2,25,000 per year.\n\n📚 **Core CSE Syllabus Pillars:**\nObject-Oriented Programming (Java/C++), Data Structures & Algorithms, Computer Architecture, Database Management Systems (SQL/NoSQL), Operating Systems, Computer Networks, Theory of Computation, Compiler Design, and Capstone Project.\n\n🏆 **Merit Concessions Available:**\nUp to 50% waiver for students scoring 90%+ in 10+2 PCM.\n\nInquiries: **admission@presidencyuniversity.in** | Call: **+91 90220 92222**.",
    "category": "Fee structure",
    "keywords": [
      "cse core fees",
      "btech cse core fee structure",
      "cse general fees",
      "fees for cse core",
      "core computer science fees",
      "btech cse core cost",
      "cse core tuition"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Computer Science & Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 263,
    "question": "What is the fee structure for B.Tech CSE (Artificial Intelligence & Machine Learning - AI & ML)?",
    "answer": "The fee structure for **B.Tech Computer Science & Engineering (AI & Machine Learning)** at Presidency University is:\n\n• **Management Quota Tuition Fee**: ₹3,25,000 to ₹3,50,000 per annum (due to specialized NVIDIA GPU computing clusters and advanced AI labs).\n• **Total 4-Year Tuition**: ~₹13,00,000 to ₹14,00,000.\n• **KCET Quota Fee**: ~₹1,07,000 to ₹1,15,000 per year.\n• **COMEDK Quota Fee**: ~₹2,25,000 to ₹2,40,000 per year.\n\n🤖 **Curriculum Highlights:**\nDeep Neural Networks, Natural Language Processing (NLP), Computer Vision, Generative AI & Large Language Models, Reinforcement Learning, Robotic Automation, and PyTorch/TensorFlow.\n\n🏆 **Scholarships**: Up to 50% tuition fee reduction for 90%+ marks in 12th PCM.\nHelpline: **+91 90220 92222**.",
    "category": "Fee structure",
    "keywords": [
      "cse ai ml fees",
      "btech cse ai fee structure",
      "fees for cse aiml",
      "artificial intelligence cse fees",
      "cse ai machine learning fees",
      "btech ai ml fees"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Computer Science & Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 264,
    "question": "What is the fee structure for B.Tech CSE (Cyber Security) at Presidency University?",
    "answer": "The fee structure for **B.Tech Computer Science & Engineering (Cyber Security)** is:\n\n• **Management Quota Tuition Fee**: ₹3,00,000 to ₹3,25,000 per annum.\n• **Total 4-Year Tuition**: ~₹12,00,000 to ₹13,00,000.\n• **KCET Quota**: ~₹1,07,000 to ₹1,15,000/year.\n• **COMEDK Quota**: ~₹2,25,000 to ₹2,40,000/year.\n\n🛡️ **Specialization Focus:**\nEthical Hacking, Security Operations Center (SOC) Simulation Labs, Network Intrusion Detection, Cryptography, Blockchain Security, Cyber Law & Digital Forensics, and Penetration Testing.\n\n🏆 **Scholarships**: Up to 50% merit concession for 90%+ in 10+2 PCM.\nHelpline: **+91 90220 92222**.",
    "category": "Fee structure",
    "keywords": [
      "cse cyber security fees",
      "btech cse cyber security fee structure",
      "cyber security cse fees",
      "ethical hacking course fees",
      "fees for cse cyber security"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Computer Science & Engineering",
    "lastVerifiedDate": "2026-10-24"
  },
  {
    "id": 265,
    "question": "What is the fee structure for B.Tech CSE (Data Science) at Presidency University?",
    "answer": "The fee structure for **B.Tech Computer Science & Engineering (Data Science)** is:\n\n• **Management Quota Tuition Fee**: ₹3,00,000 to ₹3,25,000 per year.\n• **Total 4-Year Tuition**: ~₹12,00,000 to ₹13,00,000.\n• **KCET Quota Fee**: ~₹1,07,000 to ₹1,15,000/year.\n• **COMEDK Quota Fee**: ~₹2,25,000 to ₹2,40,000/year.\n\n📊 **Specialization Focus:**\nBig Data Engineering, Hadoop, Apache Spark, Python/R Data Analytics, Predictive Modeling, Business Intelligence, Data Warehousing, and Cloud Analytics.\n\n🏆 **Scholarships**: Up to 50% merit waiver for 90%+ in 10+2 PCM.\nHelpline: **+91 90220 92222**.",
    "category": "Fee structure",
    "keywords": [
      "cse data science fees",
      "btech cse data science fee structure",
      "data science cse fees",
      "fees for cse data science",
      "btech data science cost"
    ],
    "sourceUrl": "https://presidencyuniversity.in/",
    "sourceTitle": "Presidency University School of Computer Science & Engineering",
    "lastVerifiedDate": "2026-10-24"
  }
];

export const categories = [
  "University overview",
  "History and establishment",
  "Location and campus",
  "Courses and departments",
  "Undergraduate programs",
  "Postgraduate programs",
  "Admission process",
  "Eligibility requirements",
  "Application procedure",
  "Admission deadlines",
  "Fee structure",
  "Scholarships",
  "Required documents",
  "Hostel facilities",
  "Transportation",
  "Library",
  "Laboratories",
  "Sports facilities",
  "Student clubs",
  "Campus events",
  "Placement information",
  "Career services",
  "Internship information",
  "Contact details",
  "Frequently asked questions",
  "Official application links",
  "Important notices"
];

export const universityMetadata = {
  name: "Presidency University",
  location: "Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064, Karnataka, India",
  cityOffice: "University House, 8/1, King Street, Richmond Town, Bengaluru – 560025",
  chancellor: "Dr. Nissar Ahmed",
  established: "2013 (Presidency University Act, 2013 - Karnataka Act No. 41 of 2013)",
  legacy: "Presidency Group of Institutions (Founded 1976 - 48+ Years of Academic Excellence)",
  campusArea: "65+ Acres Lush Green Eco-Friendly Campus",
  approvals: ["UGC (Section 2(f))", "AICTE", "Bar Council of India (BCI)", "Association of Indian Universities (AIU)"],
  helpline: "+91 90220 92222",
  boardLine: "080 4925 5555",
  emails: {
    admissions: "admission@presidencyuniversity.in",
    info: "info@presidencyuniversity.in",
    placements: "placements@presidencyuniversity.in",
    registrar: "registrar@presidencyuniversity.in",
    hostel: "hostel@presidencyuniversity.in",
    transport: "transport@presidencyuniversity.in"
  },
  officialLinks: {
    mainWebsite: "https://presidencyuniversity.in/",
    googleReference: "https://share.google/aed5CNFY68y6VE8UV",
    googleMaps: "https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru",
    campusNavigation: "https://www.google.com/maps/dir/?api=1&destination=Presidency+University+Bengaluru"
  },
  totalFAQEntries: 265,
  lastVerified: "2026-10-24"
};
