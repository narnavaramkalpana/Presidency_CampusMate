import urllib.request
import re
import os

req = urllib.request.Request(
    'https://presidencyuniversity.in/',
    headers={'User-Agent': 'Mozilla/5.0'}
)
html = urllib.request.urlopen(req).read().decode('utf-8', errors='ignore')

# Extract banner / campus images
found = set(re.findall(r'(?:https://presidencyuniversity\.in)?/?[a-zA-Z0-9_\-\./]+\.(?:jpg|jpeg|png|webp)', html))
campus_imgs = []
for item in found:
    if any(k in item.lower() for k in ['banner', 'campus', 'life', 'slide', 'hero', 'bg', 'infra', 'building', 'home']):
        if item.startswith('/'):
            item = 'https://presidencyuniversity.in' + item
        elif not item.startswith('http'):
            item = 'https://presidencyuniversity.in/' + item
        campus_imgs.append(item)

print("Found campus candidate images:")
for img in campus_imgs[:20]:
    print(img)
