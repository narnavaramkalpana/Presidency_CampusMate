# Building a FAQ Chatbot for a College Website

> **Presidency University Bengaluru** • Academic Project Demo  
> **Course / Subject:** Cloud Computing / Web Technologies  
> **Student Contributors:**  
> - **N Kalpana** (Roll No: `20241cdv0043`)  
> - **Poornima L** (Roll No: `20241cdv0045`)  

---

## 🌐 Live Demonstrations

- **Cloudflare Edge Live App:** [campusmate-presidency.pages.dev](https://campusmate-presidency.pages.dev/)
- **Interactive Presentation Slides:** [campusmate-presidency.pages.dev/presentation.html](https://campusmate-presidency.pages.dev/presentation.html)
- **PowerPoint Presentation Deck:** [`College_FAQ_Chatbot_Presentation.pptx`](./College_FAQ_Chatbot_Presentation.pptx)

---

## 📖 Project Overview

Prospective students, parents, and campus visitors frequently navigate extensive information to find details on 2026-27 admissions, KCET/COMEDK cutoffs, fee structures, up to 50% merit scholarships, hostel amenities, commuter bus routes, and exact building/floor physical locations.

This project delivers a responsive, intelligent **College FAQ Assistant** with:
- **Zero Latency Client-Side Retrieval:** Uses TF-IDF cosine similarity, keyword expansion, and typo tolerance (Levenshtein distance).
- **Approved Knowledge Base:** 265 verified Q&A records across 8 academic schools and 12 campus operations.
- **Voice Recognition:** Web Speech API integration for interactive voice queries.
- **Minimal, User-Centric UI:** Designed to feel like an authentic, clean university assistant rather than a robotic dashboard.
- **Robust Fallback Engine:** Safe guidance and official contact channels for unindexed queries.

---

## 🛠️ Tech Stack & Architecture

- **Frontend:** React 19, Vite 8, Tailwind CSS, Lucide Icons
- **Retrieval Engine:** Custom client-side vector space / cosine matching with domain token weighting
- **Hosting / CDN:** Cloudflare Workers & Pages Edge Network / GitHub Pages via GitHub Actions
- **Audio:** Web Speech Recognition & SpeechSynthesis APIs

---

## 🚀 Quickstart (Run Locally)

### Prerequisites
- Node.js (v18 or higher recommended)
- npm (v9 or higher)

### Setup & Run
```bash
# 1. Clone the repository
git clone https://github.com/narnavaramkalpana/college-faq-chatbot.git
cd college-faq-chatbot

# 2. Install dependencies
npm install

# 3. Start local development server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## 📦 Deployment to GitHub Pages

This repository includes automated GitHub Actions deployment located at [`.github/workflows/deploy.yml`](.github/workflows/deploy.yml).

To activate GitHub Pages hosting:
1. Go to your repository on GitHub: `https://github.com/<your-username>/<repo-name>`
2. Click **Settings** $\rightarrow$ **Pages**
3. Under **Build and deployment** $\rightarrow$ **Source**, choose **GitHub Actions**
4. Push any commit to `main` (or run the workflow manually), and your site will be live at:
   `https://<your-username>.github.io/<repo-name>/`
