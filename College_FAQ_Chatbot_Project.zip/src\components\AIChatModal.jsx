import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Send, 
  X, 
  Maximize2, 
  Minimize2, 
  Trash2, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  ExternalLink, 
  ArrowRight, 
  ArrowLeft,
  ShieldCheck, 
  RefreshCw,
  HelpCircle,
  MessageSquare,
  Mic,
  MicOff,
  ThumbsUp,
  ThumbsDown,
  Download,
  User,
  Bot,
  Compass,
  Navigation
} from 'lucide-react';
import { retrieveAnswer, getPopularSuggestedQuestions } from '../services/aiRetrievalEngine';
import { categories, universityMetadata } from '../data/universityDatabase';
import FormattedAIResponse from './FormattedAIResponse';

export default function AIChatModal({ 
  isOpen, 
  onClose, 
  fullPageMode = false, 
  initialQuery = '',
  onOpenMap
}) {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'assistant',
      text: "Hi! 👋 How can I help you today?\n\nAsk me anything about admissions, courses, fee structures, hostels, or campus directions at Presidency University.",
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      relatedQuestions: [
        "What is the fee for B.Tech CSE DevOps?",
        "Where is the cafeteria located?",
        "What was the highest placement package?"
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [speakingId, setSpeakingId] = useState(null);
  const [feedbackGiven, setFeedbackGiven] = useState({});
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [lastTopicContext, setLastTopicContext] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [isListening, setIsListening] = useState(false);

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const recognitionRef = useRef(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen || fullPageMode) {
      scrollToBottom();
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [messages, isOpen, isTyping, fullPageMode]);

  // Handle initial query if passed
  useEffect(() => {
    if (initialQuery && initialQuery.trim()) {
      handleSend(initialQuery);
    }
  }, [initialQuery]);

  // Initialize Speech-to-Text (Microphone)
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-IN';

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputValue(transcript);
          handleSend(transcript);
        }
      };
      recognitionRef.current = recognition;
    }
  }, []);

  const handleToggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert("Voice speech recognition is not supported in this browser. Please use Google Chrome or Microsoft Edge.");
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
      } catch (err) {
        recognitionRef.current.stop();
      }
    }
  };

  // Handle Text-to-Speech
  const handleToggleSpeech = (msgId, text) => {
    if (!('speechSynthesis' in window)) {
      alert("Text-to-speech audio is not supported in this browser.");
      return;
    }

    if (speakingId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean text for speech
    const cleanText = text.replace(/[*_#`[\]()•]/g, ' ').replace(/\s+/g, ' ');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Copy to clipboard
  const handleCopy = (id, text) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Handle Feedback
  const handleFeedback = (msgId, isPositive) => {
    setFeedbackGiven(prev => ({ ...prev, [msgId]: isPositive ? 'up' : 'down' }));
  };

  // Export Chat Transcript
  const handleExportChat = () => {
    const transcript = messages.map(m => {
      const sender = m.sender === 'user' ? 'User' : 'College FAQ Chatbot';
      return `[${m.timestamp}] ${sender}:\n${m.text}\n${m.sourceUrl ? `Source: ${m.sourceUrl}\n` : ''}`;
    }).join('\n----------------------------------------\n\n');

    const blob = new Blob([`Presidency University Bengaluru - College FAQ Chatbot Transcript\nGenerated: ${new Date().toLocaleString()}\n\n${transcript}`], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `College-FAQ-Chatbot-Transcript-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Clear conversation
  const handleClearChat = () => {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setSpeakingId(null);
    setLastTopicContext('');
    setFeedbackGiven({});
    setMessages([
      {
        id: Date.now(),
        sender: 'assistant',
        text: "Conversation cleared. How can I help you?",
        sourceUrl: universityMetadata.officialLinks.mainWebsite,
        relatedQuestions: [
          "What is the fee for B.Tech CSE DevOps?",
          "Where is the cafeteria located?",
          "What was the highest placement package?"
        ],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  // Handle sending a query
  const handleSend = (queryToSend) => {
    const query = (queryToSend || inputValue).trim();
    if (!query || isTyping) return;

    // Add user message
    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    // Natural simulated typing latency (300-450ms)
    setTimeout(() => {
      let response;
      try {
        response = retrieveAnswer(query, {
          lastTopic: lastTopicContext,
          preferredCategory: selectedCategory !== 'All' ? selectedCategory : null
        });
      } catch (err) {
        console.error("CampusMate AI Retrieval error:", err);
        response = {
          answer: "I'm sorry, an unexpected error occurred while querying university records. You can try asking another question or reach the official Presidency University helpdesk directly at **+91 90220 92222** or **admission@presidencyuniversity.in**.",
          category: 'Helpdesk',
          confidence: 'Low',
          status: 'error',
          sourceUrl: universityMetadata.officialLinks.mainWebsite,
          sourceTitle: 'Presidency University Admissions Helpdesk',
          lastVerifiedDate: universityMetadata.lastVerified,
          relatedQuestions: [
            "What is the eligibility for B.Tech CSE?",
            "What is the fee structure across courses?",
            "How can I apply online for 2026-27?"
          ]
        };
      }

      // Update contextual memory
      if (response && response.category) {
        setLastTopicContext(response.category + ' ' + (response.matchedEntry?.keywords || []).slice(0, 3).join(' '));
      }

      const assistantMsg = {
        id: Date.now() + 1,
        sender: 'assistant',
        text: (response && response.answer) ? response.answer : "I couldn't locate specific records for that query. Please ask about courses, eligibility, fee structures, scholarships, or placements.",
        category: response?.category || 'General',
        confidence: response?.confidence || 'Medium',
        status: response?.status || 'found',
        sourceUrl: response?.sourceUrl,
        sourceTitle: response?.sourceTitle,
        lastVerifiedDate: response?.lastVerifiedDate,
        relatedQuestions: response?.relatedQuestions || [],
        waypointId: response?.waypointId,
        isCampusLocation: response?.isCampusLocation,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 380);
  };

  if (!isOpen && !fullPageMode) return null;

  const containerClasses = fullPageMode
    ? "w-full bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-800 flex flex-col h-[750px] overflow-hidden"
    : isExpanded
      ? "fixed inset-0 sm:inset-6 z-50 bg-white dark:bg-slate-900 rounded-none sm:rounded-2xl shadow-2xl border-0 sm:border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      : "fixed inset-0 sm:inset-auto sm:bottom-6 sm:right-6 sm:w-[390px] sm:h-[580px] h-[100dvh] sm:max-h-[85vh] z-50 bg-white dark:bg-slate-900 rounded-none sm:rounded-2xl shadow-2xl border-0 sm:border border-slate-200/90 dark:border-slate-800 flex flex-col overflow-hidden animate-in slide-in-from-bottom-3 duration-200";

  return (
    <>
      {/* Mobile Backdrop when modal is active */}
      {!fullPageMode && (
        <div 
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-40 sm:hidden" 
          onClick={onClose} 
        />
      )}

      {/* Desktop Backdrop when expanded */}
      {!fullPageMode && isExpanded && (
        <div 
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-40 hidden sm:block" 
          onClick={() => setIsExpanded(false)} 
        />
      )}

      <div className={containerClasses}>
        {/* Chat Header: Clean, Minimal, Friendly */}
        <div className="bg-[#091b33] text-white px-4 py-3 flex items-center justify-between border-b border-slate-800 shadow-xs flex-shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            {/* Mobile Back Button */}
            {!fullPageMode && (
              <button
                onClick={onClose}
                className="p-1 -ml-1 text-slate-300 hover:text-white rounded-lg transition sm:hidden flex-shrink-0"
                title="Back to site"
                aria-label="Back to site"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}

            <div className="relative flex-shrink-0">
              <div className="w-8 h-8 rounded-full bg-white p-0.5 flex items-center justify-center shadow-xs overflow-hidden">
                <img src="/assets/presidency_crest_symbol.png" alt="Presidency Crest" className="w-full h-full object-contain" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#091b33] rounded-full"></span>
            </div>

            <div className="min-w-0">
              <h3 className="font-semibold text-sm tracking-tight font-sans truncate text-white">
                Presidency Assistant
              </h3>
              <p className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>Online</span>
              </p>
            </div>
          </div>

          {/* Header Controls */}
          <div className="flex items-center gap-1 flex-shrink-0">
            {/* Clear Chat */}
            <button
              onClick={handleClearChat}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
              title="Clear conversation"
              aria-label="Clear conversation"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            {!fullPageMode && (
              <button
                onClick={onClose}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
                title="Close chat"
                aria-label="Close chat"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-3.5 sm:p-5 space-y-4 sm:space-y-5 bg-gradient-to-b from-slate-50/80 to-slate-100/60 dark:from-slate-900/90 dark:to-slate-950 overscroll-contain">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-2 sm:gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {/* Bot Avatar for Assistant Messages */}
              {msg.sender === 'assistant' && (
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-white dark:bg-slate-800 border border-blue-200 dark:border-slate-700 shadow-xs p-0.5 flex-shrink-0 flex items-center justify-center mt-1">
                  <img src="/assets/presidency_crest_symbol.png" alt="Bot" className="w-full h-full object-contain" />
                </div>
              )}

              {/* Message Content Container */}
              <div className={`flex flex-col ${msg.sender === 'user' ? 'items-end max-w-[88%] sm:max-w-[85%]' : 'items-start max-w-[96%] sm:max-w-[85%]'}`}>
                {/* Message Bubble */}
                <div
                  className={`rounded-2xl px-3.5 sm:px-5 py-3 sm:py-3.5 leading-relaxed shadow-sm transition-all ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-br from-[#091b33] to-[#163e72] text-white rounded-br-xs text-[13px] sm:text-[14px]'
                      : 'bg-white dark:bg-slate-800/95 text-slate-800 dark:text-slate-100 border border-slate-200/90 dark:border-slate-700 rounded-bl-xs'
                  }`}
                >
                  {/* Formatted Content */}
                  {msg.sender === 'assistant' ? (
                    <FormattedAIResponse text={msg.text} />
                  ) : (
                    <div className="whitespace-pre-line font-medium">{msg.text}</div>
                  )}

                  {/* Campus Map Waypoint Trigger */}
                  {msg.sender === 'assistant' && msg.waypointId && onOpenMap && (
                    <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-700/60">
                      <button
                        onClick={() => onOpenMap(msg.waypointId)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-900/40 hover:bg-blue-100 dark:hover:bg-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold transition cursor-pointer"
                      >
                        <Compass className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                        <span>View on Campus Map</span>
                      </button>
                    </div>
                  )}

                  {/* Subtle Link Citation */}
                  {msg.sender === 'assistant' && msg.sourceUrl && (
                    <div className="mt-2 pt-1.5 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                      <a
                        href={msg.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1 text-[11px] font-medium"
                      >
                        <span>presidencyuniversity.in</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </div>
                  )}
                </div>

                {/* Message Action Toolbar */}
                <div className="flex items-center gap-2 mt-1 px-1 text-[10px] text-slate-400 dark:text-slate-500">
                  <span>{msg.timestamp}</span>

                  {msg.sender === 'assistant' && (
                    <>
                      <span>•</span>
                      <button
                        onClick={() => handleCopy(msg.id, msg.text)}
                        className="hover:text-slate-700 dark:hover:text-slate-300 transition flex items-center gap-1 cursor-pointer"
                        title="Copy text"
                      >
                        {copiedId === msg.id ? (
                          <span className="text-emerald-600 dark:text-emerald-400 font-medium">Copied</span>
                        ) : (
                          <span>Copy</span>
                        )}
                      </button>

                      <span>•</span>
                      <button
                        onClick={() => handleToggleSpeech(msg.id, msg.text)}
                        className="hover:text-slate-700 dark:hover:text-slate-300 transition flex items-center gap-1 cursor-pointer"
                        title={speakingId === msg.id ? "Stop audio" : "Listen to answer"}
                      >
                        <span>{speakingId === msg.id ? "Stop" : "Listen"}</span>
                      </button>
                    </>
                  )}
                </div>

                {/* Suggested Follow-up Prompts */}
                {msg.sender === 'assistant' && msg.relatedQuestions && msg.relatedQuestions.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {msg.relatedQuestions.slice(0, 3).map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSend(q)}
                        className="text-[11px] px-2.5 py-1 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-full transition shadow-2xs font-normal cursor-pointer"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* User Avatar */}
              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#091b33] to-[#163e72] text-white shadow-xs flex-shrink-0 flex items-center justify-center mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-center gap-2 p-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/90 dark:border-slate-700 shadow-xs max-w-xs animate-pulse">
              <div className="w-7 h-7 rounded-xl bg-blue-50 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 animate-bounce"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 animate-bounce [animation-delay:0.15s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 animate-bounce [animation-delay:0.3s]"></span>
                  <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200 ml-1.5">Analyzing verified records...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar: Modern Mobile-Friendly Prompt Console */}
        <div className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200/80 dark:border-slate-800 pb-[max(env(safe-area-inset-bottom),12px)] flex-shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="relative flex items-center gap-2"
          >
            {/* Input Box */}
            <div className="relative flex-1 flex items-center">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about admissions, fees, B.Tech CSE, hostels, placements..."
                className="w-full bg-slate-100/90 dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/80 focus:bg-white dark:focus:bg-slate-800 text-base sm:text-sm text-slate-800 dark:text-white pl-4 pr-11 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 focus:border-blue-500 dark:focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 focus:outline-none transition shadow-inner font-sans"
              />

              {/* Microphone Voice Input Button */}
              <button
                type="button"
                onClick={handleToggleVoiceInput}
                className={`absolute right-2.5 p-1.5 rounded-xl transition cursor-pointer ${
                  isListening 
                    ? 'bg-rose-500 text-white animate-pulse shadow-md' 
                    : 'text-slate-400 hover:text-[#091b33] dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-700'
                }`}
                title={isListening ? "Listening... Click to stop" : "Speak your question (Voice Input)"}
                aria-label="Speak your question"
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>

            {/* Send Button */}
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className={`p-3 rounded-2xl font-bold transition flex items-center justify-center shadow-md flex-shrink-0 min-w-[44px] min-h-[44px] ${
                inputValue.trim() && !isTyping
                  ? 'bg-gradient-to-r from-[#091b33] to-[#163e72] hover:from-[#0d2346] hover:to-[#1a4985] text-white cursor-pointer hover:scale-105 active:scale-95'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
              }`}
              title="Send question to College FAQ Chatbot"
              aria-label="Send question"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
