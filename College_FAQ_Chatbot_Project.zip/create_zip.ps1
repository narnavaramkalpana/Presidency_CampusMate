param(
    [string]$SourceDir = "C:\Users\ASUS\.gemini\antigravity\scratch\campusmate-presidency",
    [string]$ZipOutput = "C:\Users\ASUS\.gemini\antigravity\scratch\campusmate-presidency\College_FAQ_Chatbot_Project.zip"
)

$ErrorActionPreference = "Stop"

$tempGuid = [System.Guid]::NewGuid().ToString()
$tempRoot = Join-Path $env:TEMP "chatbot_pack_$tempGuid"
$projectPackDir = Join-Path $tempRoot "College-FAQ-Chatbot-Presidency"

Write-Host "Creating packaging directory at $projectPackDir..."
New-Item -ItemType Directory -Path $projectPackDir -Force | Out-Null

$excludeList = @('node_modules', '.git', '.wrangler', '*.zip')

$items = Get-ChildItem -Path $SourceDir -Exclude $excludeList
foreach ($item in $items) {
    Write-Host "Copying $($item.Name)..."
    Copy-Item -Path $item.FullName -Destination $projectPackDir -Recurse -Force
}

if (Test-Path $ZipOutput) {
    Remove-Item $ZipOutput -Force
}

Write-Host "Compressing archive to $ZipOutput..."
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($projectPackDir, $ZipOutput)

Remove-Item -Path $tempRoot -Recurse -Force

$zipFile = Get-Item $ZipOutput
$sizeMB = [math]::Round($zipFile.Length / 1MB, 2)
Write-Host "SUCCESS! Zip archive created:"
Write-Host "Path: $($zipFile.FullName)"
Write-Host "Size: $sizeMB MB"
