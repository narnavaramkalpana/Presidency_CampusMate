import React, { useState } from 'react';
import AIChatModal from '../components/AIChatModal';
import { 
  Sparkles, 
  HelpCircle, 
  ShieldCheck, 
  BookOpen, 
  Award, 
  ExternalLink, 
  MessageSquare, 
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Clock,
  CheckCircle2,
  Cpu,
  GraduationCap,
  DollarSign,
  Home as HomeIcon,
  Bus,
  Briefcase,
  Compass
} from 'lucide-react';
import { categories, universityMetadata } from '../data/universityDatabase';

export default function CampusMateAssistant({ initialQuery, onOpenMap }) {
  const [selectedQuickQuestion, setSelectedQuickQuestion] = useState(initialQuery || '');

  const quickPromptTopics = [
    {
      category: 'Admissions & Cutoffs',
      icon: GraduationCap,
      color: 'text-blue-600 bg-blue-50 border-blue-200 dark:bg-blue-900/40 dark:border-blue-800 dark:text-blue-300',
      queries: [
        'What is the eligibility for B.Tech CSE?',
        'How can I apply online for 2026-27?',
        'What entrance exams are accepted?'
      ]
    },
    {
      category: 'Fees & Scholarships',
      icon: DollarSign,
      color: 'text-blue-700 bg-blue-50 border-blue-200 dark:bg-blue-900/40 dark:border-blue-800 dark:text-blue-300',
      queries: [
        'What is the fee structure across courses?',
        'what is the fess structure cor cse core devops',
        'Are scholarships available for 90%+ students?'
      ]
    },
    {
      category: 'Placements & Careers',
      icon: Briefcase,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-900/40 dark:border-emerald-800 dark:text-emerald-300',
      queries: [
        'What was the highest placement package?',
        'Which companies recruit from campus?',
        'Are internships provided during the course?'
      ]
    },
    {
      category: 'Campus Living & Transport',
      icon: HomeIcon,
      color: 'text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-900/40 dark:border-amber-800 dark:text-amber-300',
      queries: [
        'Where is the cafeteria located on campus?',
        'What hostel facilities and fees are offered?',
        'Which areas are covered by university buses?'
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-900 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Building a FAQ Chatbot for a College Website</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-[#091b33] dark:text-white font-serif tracking-tight">
            College FAQ Chatbot
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Answers common college FAQs from an approved 265-record sample knowledge base with intent-based retrieval, typo tolerance, and verified fallbacks.
          </p>
        </div>

        {/* Quick Map trigger */}
        {onOpenMap && (
          <button
            onClick={() => onOpenMap()}
            className="self-start md:self-auto inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs font-bold border border-blue-200 dark:border-blue-800 transition cursor-pointer shadow-2xs"
          >
            <Compass className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>Interactive Campus Map</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Quick Prompts & Contact Info */}
        <div className="lg:col-span-4 space-y-6 order-2 lg:order-1">
          {/* Quick Prompt Cards */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Popular Inquiries
              </h3>
              <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-800">
                1-Click Prompt
              </span>
            </div>

            <div className="space-y-4">
              {quickPromptTopics.map((topic, tIdx) => {
                const Icon = topic.icon;
                return (
                  <div key={tIdx} className="space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                      <div className={`p-1 rounded-lg border ${topic.color}`}>
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <span>{topic.category}</span>
                    </div>

                    <div className="space-y-1.5 pl-6">
                      {topic.queries.map((q, qIdx) => (
                        <button
                          key={qIdx}
                          onClick={() => setSelectedQuickQuestion(q)}
                          className="w-full text-left text-[11px] p-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-blue-50/80 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-blue-950 dark:hover:text-white border border-slate-200/60 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-500 transition flex items-center justify-between group cursor-pointer"
                        >
                          <span className="line-clamp-1">{q}</span>
                          <ArrowRight className="w-3 h-3 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 group-hover:translate-x-0.5 transition flex-shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Official Verification & Contact Card */}
          <div className="relative rounded-3xl p-6 text-white shadow-lg space-y-4 overflow-hidden border border-slate-800">
            <div 
              className="absolute inset-0 bg-cover bg-center bg-no-repeat"
              style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
            />
            <div className="absolute inset-0 bg-gradient-to-br from-[#091b33]/92 to-[#163e72]/85 backdrop-blur-[1px]" />
            <div className="relative z-10 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white p-1 flex items-center justify-center shadow-md">
                  <img src="/assets/presidency_crest_symbol.png" alt="Crest" className="w-full h-full object-contain" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white">Presidency University</h4>
                  <p className="text-[11px] text-blue-300">Bengaluru • Estd. 2013</p>
                </div>
              </div>

            <div className="text-xs text-slate-200 space-y-2 border-t border-white/10 pt-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>UGC §2(f) • AICTE • BCI • AIU Approved</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <span>Admissions Office: Mon - Sat, 9 AM - 5 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <a href="tel:+919022092222" className="hover:underline text-white font-semibold">
                  Helpline: +91 90220 92222
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <a href="mailto:admission@presidencyuniversity.in" className="hover:underline text-white">
                  admission@presidencyuniversity.in
                </a>
              </div>
            </div>

            <a
              href="https://presidencyuniversity.in/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-sm"
            >
              <span>Visit Official University Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            </div>
          </div>
        </div>

        {/* Right Main Column: Full AI Chat Assistant */}
        <div className="lg:col-span-8 order-1 lg:order-2">
          <AIChatModal 
            isOpen={true} 
            fullPageMode={true} 
            initialQuery={selectedQuickQuestion}
            onOpenMap={onOpenMap}
          />
        </div>
      </div>
    </div>
  );
}
