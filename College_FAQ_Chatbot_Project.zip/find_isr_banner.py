import re

f = open(r'C:\Users\ASUS\.gemini\antigravity\brain\8066d25f-8824-4ec2-a544-b32cbbecdc86\.system_generated\steps\166\content.md', encoding='utf-8').read()
matches = re.findall(r'<section[^>]*>[\s\S]*?</section>', f)
for m in matches[:5]:
    if 'img' in m or 'background' in m or 'banner' in m:
        print("MATCH:", m[:300])
        print("---")
