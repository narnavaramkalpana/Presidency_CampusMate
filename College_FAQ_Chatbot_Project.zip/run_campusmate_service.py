import subprocess
import re
import time
import os
import sys
import threading
import urllib.request

PORT = 3001
app_dir = r"C:\Users\ASUS\.gemini\antigravity\scratch\campusmate-presidency"
os.chdir(app_dir)

# 1. Kill old processes
os.system("taskkill /F /IM cloudflared.exe 2>nul")

# 2. Start Vite Preview
print("Starting Vite preview server on port 3001...")
preview_log = open(os.path.join(app_dir, "preview.log"), "w", encoding="utf-8")
preview_proc = subprocess.Popen(
    ["npm", "run", "preview", "--", "--port", str(PORT), "--host"],
    cwd=app_dir,
    shell=True,
    stdout=preview_log,
    stderr=preview_log
)

# 3. Wait for local server
print("Waiting for local server on http://127.0.0.1:3001...")
ready = False
for _ in range(30):
    try:
        resp = urllib.request.urlopen(f"http://127.0.0.1:{PORT}", timeout=2)
        if resp.getcode() == 200:
            ready = True
            print("Local server is UP!")
            break
    except Exception:
        time.sleep(1)

if not ready:
    print("Failed to start local server.")
    sys.exit(1)

# 4. Start Cloudflare Tunnel with thread-drained logging
cloudflared_bin = r"C:\Users\ASUS\.gemini\antigravity\scratch\cloudflared.exe"
print("Launching Cloudflare tunnel...")

tunnel_log = open(os.path.join(app_dir, "tunnel.log"), "w", encoding="utf-8")
tunnel_proc = subprocess.Popen(
    [cloudflared_bin, "tunnel", "--url", f"http://127.0.0.1:{PORT}"],
    stderr=subprocess.PIPE,
    stdout=subprocess.DEVNULL,
    text=True,
    encoding="utf-8",
    errors="replace"
)

tunnel_url = None
url_event = threading.Event()

def drain_tunnel():
    global tunnel_url
    for line in iter(tunnel_proc.stderr.readline, ''):
        tunnel_log.write(line)
        tunnel_log.flush()
        if not tunnel_url:
            match = re.search(r'https:\/\/[a-zA-Z0-9\-]+\.trycloudflare\.com', line)
            if match:
                tunnel_url = match.group(0)
                url_event.set()

drain_thread = threading.Thread(target=drain_tunnel, daemon=True)
drain_thread.start()

# Wait for tunnel URL
if not url_event.wait(timeout=35):
    print("Could not obtain Cloudflare tunnel URL within timeout.")
    sys.exit(1)

print(f"\n==========================================")
print(f"PUBLIC URL: {tunnel_url}")
print(f"==========================================\n")
sys.stdout.flush()

with open(os.path.join(app_dir, "public_url.txt"), "w") as f:
    f.write(tunnel_url)

# 5. Verify the public URL
time.sleep(2)
try:
    req = urllib.request.Request(
        tunnel_url,
        headers={"User-Agent": "Mozilla/5.0"}
    )
    res = urllib.request.urlopen(req, timeout=12)
    print(f"Public URL verification status: {res.getcode()} (OK)")
except Exception as e:
    print(f"Public URL verification note: {e}")

sys.stdout.flush()

# Keep alive loop
try:
    while True:
        time.sleep(60)
except KeyboardInterrupt:
    pass
