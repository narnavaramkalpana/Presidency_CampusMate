import React from 'react';
import { CheckCircle2, ChevronRight, ExternalLink, Phone, Mail, MapPin, Navigation } from 'lucide-react';

/**
 * Intelligent Markdown & Text Formatter for CampusMate AI Responses
 * Parses markdown links, bold text, lists, fee amounts, phone numbers, emails, and Google Maps links into interactive UI components.
 */
export default function FormattedAIResponse({ text }) {
  if (!text) return null;

  // Split text by newlines
  const lines = text.split('\n');

  // Helper to parse markdown links [Label](url) first, then bold (**...**), then inline tokens
  const formatInlineText = (str) => {
    if (!str) return null;

    // Phase 1: Parse Markdown Links [label](url)
    const linkRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
    const segments = [];
    let lastLinkIdx = 0;
    let matchLink;
    let linkKey = 0;

    while ((matchLink = linkRegex.exec(str)) !== null) {
      if (matchLink.index > lastLinkIdx) {
        segments.push({ type: 'text', content: str.substring(lastLinkIdx, matchLink.index) });
      }

      const label = matchLink[1];
      const url = matchLink[2];
      const isMapLink = /maps\.app\.goo\.gl|google\.com\/maps|maps\.google/i.test(url) || /map|directions|location/i.test(label);

      segments.push({
        type: 'link',
        label,
        url,
        isMapLink,
        key: `link-${linkKey++}`
      });

      lastLinkIdx = linkRegex.lastIndex;
    }

    if (lastLinkIdx < str.length) {
      segments.push({ type: 'text', content: str.substring(lastLinkIdx) });
    }

    // Phase 2: For each text segment, process bold (**...**)
    const renderedParts = [];
    let boldKey = 0;

    segments.forEach((seg, sIdx) => {
      if (seg.type === 'link') {
        if (seg.isMapLink) {
          const isDirections = /direction|navigation/i.test(seg.label);
          renderedParts.push(
            <a
              key={seg.key}
              href={seg.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 my-1 mr-2 rounded-xl text-white font-bold text-xs shadow-md transition hover:scale-105 active:scale-95 no-underline cursor-pointer ${
                isDirections ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-blue-600 hover:bg-blue-500'
              }`}
            >
              {isDirections ? (
                <Navigation className="w-3.5 h-3.5 text-emerald-200" />
              ) : (
                <MapPin className="w-3.5 h-3.5 text-blue-200" />
              )}
              <span>{seg.label}</span>
              <ExternalLink className="w-3 h-3 opacity-80" />
            </a>
          );
        } else {
          renderedParts.push(
            <a
              key={seg.key}
              href={seg.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 underline font-semibold inline-flex items-center gap-0.5 mx-0.5"
            >
              <span>{seg.label}</span>
              <ExternalLink className="w-2.5 h-2.5 inline" />
            </a>
          );
        }
        return;
      }

      // Process bold inside text segment
      const textChunk = seg.content;
      const boldRegex = /\*\*(.*?)\*\*/g;
      let lastBoldIdx = 0;
      let matchBold;

      while ((matchBold = boldRegex.exec(textChunk)) !== null) {
        if (matchBold.index > lastBoldIdx) {
          renderedParts.push(formatTokens(textChunk.substring(lastBoldIdx, matchBold.index), `txt-${sIdx}-${boldKey++}`));
        }
        renderedParts.push(
          <strong key={`bold-${sIdx}-${boldKey++}`} className="font-bold text-[#091b33]">
            {matchBold[1]}
          </strong>
        );
        lastBoldIdx = boldRegex.lastIndex;
      }

      if (lastBoldIdx < textChunk.length) {
        renderedParts.push(formatTokens(textChunk.substring(lastBoldIdx), `txt-${sIdx}-${boldKey++}`));
      }
    });

    return renderedParts;
  };

  // Helper to parse currency, raw URLs, phones, and emails
  const formatTokens = (rawText, baseKey) => {
    if (!rawText) return null;
    const words = rawText.split(/(\s+)/);

    return words.map((w, wIdx) => {
      // Highlight Currency / LPA / Percentages
      if (/^(₹|Rs\.?)\s?[\d,]+(\.[\d]+)?(\s*(Lakhs?|Crores?|LPA|per year|\/year|\/annum))?/i.test(w) ||
          /^\d+(\.\d+)?\s*(LPA|%)/.test(w)) {
        return (
          <span key={`${baseKey}-curr-${wIdx}`} className="inline-block px-1.5 py-0.5 mx-0.5 rounded-md bg-blue-50 text-blue-900 border border-blue-200 font-bold text-[12px]">
            {w}
          </span>
        );
      }

      // Raw URLs
      if (/^https?:\/\//i.test(w)) {
        const cleanUrl = w.replace(/[.,;)]+$/, '');
        const trailing = w.slice(cleanUrl.length);
        const isMap = /maps\.app\.goo\.gl|google\.com\/maps/i.test(cleanUrl);

        return (
          <React.Fragment key={`${baseKey}-url-${wIdx}`}>
            {isMap ? (
              <a 
                href={cleanUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center gap-1.5 px-3 py-1 my-1 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-xs no-underline cursor-pointer"
              >
                <MapPin className="w-3 h-3 text-blue-200" />
                <span>Open Google Maps</span>
                <ExternalLink className="w-2.5 h-2.5 text-blue-200" />
              </a>
            ) : (
              <a 
                href={cleanUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-600 hover:text-blue-800 underline font-semibold inline-flex items-center gap-0.5 mx-0.5"
              >
                <span>{cleanUrl.replace(/^https?:\/\/(www\.)?/, '')}</span>
                <ExternalLink className="w-2.5 h-2.5 inline" />
              </a>
            )}
            {trailing}
          </React.Fragment>
        );
      }

      // Highlight Phone Numbers
      if (/^(\+91[\d\s-]{8,}|\d{3,4}[\s-]?\d{6,8})/.test(w) && w.length >= 8) {
        const cleanPhone = w.replace(/[^\d+]/g, '');
        return (
          <a 
            key={`${baseKey}-phone-${wIdx}`}
            href={`tel:${cleanPhone}`} 
            className="text-emerald-700 hover:text-emerald-900 font-semibold inline-flex items-center gap-0.5 underline bg-emerald-50 px-1 py-0.2 rounded border border-emerald-200"
          >
            <Phone className="w-2.5 h-2.5" />
            <span>{w}</span>
          </a>
        );
      }

      // Highlight Email Addresses
      if (/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(w)) {
        return (
          <a 
            key={`${baseKey}-mail-${wIdx}`}
            href={`mailto:${w}`} 
            className="text-indigo-600 hover:text-indigo-800 font-semibold inline-flex items-center gap-0.5 underline bg-indigo-50 px-1 py-0.2 rounded border border-indigo-200"
          >
            <Mail className="w-2.5 h-2.5" />
            <span>{w}</span>
          </a>
        );
      }

      return w;
    });
  };

  return (
    <div className="space-y-2 text-slate-800 leading-relaxed font-sans">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={idx} className="h-1.5" />;
        }

        // Bullet line (starts with • or - or *)
        if (/^[•\-*]\s+/.test(trimmed)) {
          const content = trimmed.replace(/^[•\-*]\s+/, '');
          return (
            <div key={idx} className="flex items-start gap-2.5 pl-1 my-1">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-2 flex-shrink-0" />
              <div className="flex-1 text-[13px] sm:text-[13.5px]">
                {formatInlineText(content)}
              </div>
            </div>
          );
        }

        // Numbered list item (e.g. "1. ", "2. ")
        if (/^\d+\.\s+/.test(trimmed)) {
          const numMatch = trimmed.match(/^(\d+)\.\s+/);
          const num = numMatch ? numMatch[1] : '';
          const content = trimmed.replace(/^\d+\.\s+/, '');
          return (
            <div key={idx} className="flex items-start gap-2.5 pl-1 my-1.5">
              <span className="w-5 h-5 rounded-full bg-[#091b33] text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5 shadow-2xs">
                {num}
              </span>
              <div className="flex-1 text-[13px] sm:text-[13.5px]">
                {formatInlineText(content)}
              </div>
            </div>
          );
        }

        // Section header line (starts with ###)
        if (trimmed.startsWith('###')) {
          return (
            <h4 key={idx} className="font-bold text-sm text-[#091b33] mt-2 mb-1 flex items-center gap-1.5">
              <ChevronRight className="w-3.5 h-3.5 text-blue-600" />
              <span>{formatInlineText(trimmed.replace(/^###\s*/, ''))}</span>
            </h4>
          );
        }

        // Normal paragraph line
        return (
          <p key={idx} className="text-[13px] sm:text-[13.5px]">
            {formatInlineText(trimmed)}
          </p>
        );
      })}
    </div>
  );
}
