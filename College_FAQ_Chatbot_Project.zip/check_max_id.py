import re

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    text = f.read()

ids = [int(x) for x in re.findall(r'"id":\s*(\d+)', text)]
print(f"Total entries: {len(ids)}, Min ID: {min(ids)}, Max ID: {max(ids)}")
for i in range(250, max(ids) + 1):
    m = re.search(rf'\{{\s*"id":\s*{i},[\s\S]*?"question":\s*"([^"]+)"', text)
    if m:
        print(f"ID {i}: {m.group(1)}")
