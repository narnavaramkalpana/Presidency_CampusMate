import re

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    text = f.read()

def print_entry(id_num):
    m = re.search(rf'\{{\s*"id":\s*{id_num},[\s\S]*?\n  \}}', text)
    if m:
        print(f"=== ENTRY {id_num} ===")
        # encode safe
        print(m.group(0).encode('ascii', 'backslashreplace').decode('ascii'))

print_entry(27)
print_entry(239)
