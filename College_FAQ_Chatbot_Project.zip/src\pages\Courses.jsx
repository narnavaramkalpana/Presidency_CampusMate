import React, { useState } from 'react';
import { 
  GraduationCap, 
  Search, 
  Sparkles, 
  ArrowRight, 
  Clock, 
  Award, 
  CheckCircle2, 
  ExternalLink,
  BookOpen,
  Filter
} from 'lucide-react';

export default function Courses({ onAskAI, setActivePage }) {
  const [selectedSchool, setSelectedSchool] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const schools = [
    { id: 'All', name: 'All Schools' },
    { id: 'Engineering', name: 'School of Engineering (SOE)' },
    { id: 'Management', name: 'School of Management (SOM)' },
    { id: 'Law', name: 'School of Law (SOL)' },
    { id: 'Design', name: 'School of Design (SOD)' },
    { id: 'Computer Science', name: 'School of Computer Science (BCA/MCA)' },
    { id: 'Commerce', name: 'School of Commerce (SOC)' },
    { id: 'Allied Health', name: 'School of Allied Health Sciences' },
    { id: 'Media', name: 'School of Media Studies' },
    { id: 'Basic Sciences', name: 'School of Basic Sciences & Humanities' }
  ];

  const coursesList = [
    // Engineering
    {
      id: 'btech-cse',
      name: 'B.Tech in Computer Science and Engineering (CSE)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% aggregate in Physics & Maths (40% for Karnataka SC/ST/OBC) + KCET/COMEDK/JEE/University Test',
      highlights: 'NVIDIA GPU AI lab, full stack coding, cloud computing, top recruiter favorite (Microsoft, Amazon, Infosys).',
      careers: 'Software Development Engineer, Cloud Architect, Systems Analyst, Backend Specialist.'
    },
    {
      id: 'btech-ai-ml',
      name: 'B.Tech CSE (Artificial Intelligence & Machine Learning)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM (40% for reserved) + valid entrance test score',
      highlights: 'Deep learning frameworks, natural language processing, computer vision, PyTorch & TensorFlow clusters.',
      careers: 'AI Engineer, Machine Learning Specialist, Data Scientist, NLP Researcher.'
    },
    {
      id: 'btech-data-science',
      name: 'B.Tech CSE (Data Science)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Big data analytics, distributed computing with Spark, Tableau/PowerBI visual analytics, statistical modeling.',
      careers: 'Data Scientist, Business Intelligence Developer, Big Data Architect.'
    },
    {
      id: 'btech-cyber-security',
      name: 'B.Tech CSE (Cyber Security)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Ethical hacking lab, network penetration testing, cryptography, ISO/NIST compliance.',
      careers: 'Cyber Security Analyst, Information Security Officer, Penetration Tester, Cryptographer.'
    },
    {
      id: 'btech-iot-blockchain',
      name: 'B.Tech CSE (IoT & Blockchain)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Smart sensors, microcontrollers, embedded IoT, smart contracts, decentralized ledgers.',
      careers: 'IoT Solutions Architect, Blockchain Developer, Smart City Infrastructure Engineer.'
    },
    {
      id: 'btech-ise',
      name: 'B.Tech in Information Science and Engineering (ISE)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Software engineering, database architecture, network administration, human-computer interaction.',
      careers: 'IT Consultant, Database Administrator, Enterprise Software Engineer.'
    },
    {
      id: 'btech-ece',
      name: 'B.Tech in Electronics & Communication Engineering (ECE)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'VLSI chip design, embedded systems, 5G wireless communication, cadence design tools.',
      careers: 'VLSI Design Engineer, Embedded Firmware Developer, Telecom Systems Specialist.'
    },
    {
      id: 'btech-eee',
      name: 'B.Tech in Electrical & Electronics Engineering (EEE)',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Smart grids, electric vehicle (EV) powertrain systems, renewable energy, power electronics.',
      careers: 'Power Systems Engineer, EV Powertrain Specialist, Renewable Energy Consultant.'
    },
    {
      id: 'btech-mechanical',
      name: 'B.Tech in Mechanical Engineering',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'CAD/CAM/CAE prototyping, robotics, thermal fluid analysis, manufacturing automation.',
      careers: 'Design Engineer, Thermal Engineer, Automotive Specialist, Production Manager.'
    },
    {
      id: 'btech-mechatronics',
      name: 'B.Tech in Mechatronics Engineering',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Integration of mechanics, electronics, pneumatic automation, microcontrollers, and industrial robotics.',
      careers: 'Robotics Engineer, Industrial Automation Specialist, Control Systems Engineer.'
    },
    {
      id: 'btech-petroleum',
      name: 'B.Tech in Petroleum Engineering',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Drilling engineering, reservoir simulation, petroleum geology, downstream refining processes.',
      careers: 'Petroleum Geologist, Reservoir Engineer, Offshore Drilling Supervisor.'
    },
    {
      id: 'btech-civil',
      name: 'B.Tech in Civil Engineering',
      school: 'Engineering',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in PCM + valid entrance test score',
      highlights: 'Building Information Modeling (BIM), structural analytics, green buildings, geotechnical surveys.',
      careers: 'Structural Consultant, BIM Engineer, Urban Transport Planner, Site Project Manager.'
    },
    {
      id: 'mtech-cse',
      name: 'M.Tech in Computer Science & Engineering',
      school: 'Engineering',
      level: 'Postgraduate',
      duration: '2 Years (4 Semesters)',
      eligibility: 'B.E./B.Tech with min 50% aggregate (45% for reserved) + GATE/PGCET',
      highlights: 'Advanced distributed architectures, machine learning research, cloud computing security.',
      careers: 'Lead Systems Architect, Senior Research Scientist, Technical Lead.'
    },
    {
      id: 'mtech-vlsi',
      name: 'M.Tech in Embedded Systems & VLSI',
      school: 'Engineering',
      level: 'Postgraduate',
      duration: '2 Years (4 Semesters)',
      eligibility: 'B.Tech in ECE/EEE/Instrumentation with min 50% + GATE/PGCET',
      highlights: 'ASIC/FPGA design, low-power CMOS architectures, system-on-chip (SoC) verification.',
      careers: 'Senior VLSI Verification Engineer, SoC Designer, Firmware Architect.'
    },

    // Management
    {
      id: 'mba-general',
      name: 'MBA (Master of Business Administration)',
      school: 'Management',
      level: 'Postgraduate',
      duration: '2 Years (4 Semesters)',
      eligibility: 'Bachelor degree of min 3 years with 50% marks (45% for reserved) + PGCET/CAT/MAT/XAT/KMAT',
      highlights: 'Dual specializations in Marketing, Finance, HR, Business Analytics, Digital Marketing, and Supply Chain.',
      careers: 'Management Consultant, Financial Analyst, Marketing Manager, Operations Director.'
    },
    {
      id: 'bba-general',
      name: 'BBA (Bachelor of Business Administration)',
      school: 'Management',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 / PUC in any stream with minimum 45% aggregate',
      highlights: 'Fundamental business administration, financial accounting, marketing principles, case study pedagogy.',
      careers: 'Business Analyst, Marketing Executive, HR Associate, Management Trainee.'
    },
    {
      id: 'bba-aviation',
      name: 'BBA in Aviation Management',
      school: 'Management',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 / PUC in any stream with minimum 45% aggregate',
      highlights: 'Airport operations, air cargo logistics, aviation safety, airline revenue management.',
      careers: 'Airport Operations Executive, Airline Duty Manager, Cargo Logistics Coordinator.'
    },
    {
      id: 'bba-analytics',
      name: 'BBA in Business Analytics',
      school: 'Management',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 / PUC with minimum 45% aggregate (Math/Stats background preferred)',
      highlights: 'Python for business, predictive modeling, financial analytics, consumer behavior data mining.',
      careers: 'Junior Business Analyst, Market Research Specialist, Operations Analyst.'
    },

    // Law
    {
      id: 'ba-llb',
      name: 'B.A. LL.B. (Hons.) - 5 Year Integrated Law',
      school: 'Law',
      level: 'Undergraduate',
      duration: '5 Years (10 Semesters)',
      eligibility: '10+2 in any stream with min 45% aggregate (40% for SC/ST) + CLAT/LSAT/PULAT',
      highlights: 'BCI Approved, moot court training, legal aid clinic, judicial internships, constitutional law.',
      careers: 'Litigation Advocate, Corporate Legal Advisor, Judicial Services, Public Prosecutor.'
    },
    {
      id: 'bba-llb',
      name: 'B.B.A. LL.B. (Hons.) - 5 Year Integrated Law',
      school: 'Law',
      level: 'Undergraduate',
      duration: '5 Years (10 Semesters)',
      eligibility: '10+2 in any stream with min 45% aggregate (40% for SC/ST) + CLAT/LSAT/PULAT',
      highlights: 'Mergers & acquisitions, corporate restructuring, securities law, intellectual property rights.',
      careers: 'Corporate Law Associate, Legal Compliance Specialist, M&A Consultant.'
    },
    {
      id: 'bcom-llb',
      name: 'B.Com. LL.B. (Hons.) - 5 Year Integrated Law',
      school: 'Law',
      level: 'Undergraduate',
      duration: '5 Years (10 Semesters)',
      eligibility: '10+2 in Commerce or relevant stream with min 45% aggregate + CLAT/LSAT/PULAT',
      highlights: 'Taxation laws, GST, banking regulations, mercantile law, insolvency & bankruptcy code.',
      careers: 'Taxation Advocate, Banking Legal Officer, Insolvency Consultant.'
    },
    {
      id: 'llm',
      name: 'LL.M. (Master of Laws)',
      school: 'Law',
      level: 'Postgraduate',
      duration: '1 Year (2 Semesters)',
      eligibility: 'LL.B. degree from a recognized university with min 50% aggregate (45% for reserved)',
      highlights: 'Specializations in Intellectual Property Rights (IPR) and Corporate & Commercial Law.',
      careers: 'Senior Legal Consultant, Academic Professor, In-house General Counsel.'
    },

    // Design
    {
      id: 'bdes-product',
      name: 'B.Des in Product Design',
      school: 'Design',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% aggregate in any stream + Presidency DAT / UCEED + Portfolio',
      highlights: 'Ergonomics, 3D prototyping, material science, user research, CAD/Solidworks design.',
      careers: 'Industrial Product Designer, Consumer Goods Stylist, UX Hardware Designer.'
    },
    {
      id: 'bdes-fashion',
      name: 'B.Des in Fashion Design',
      school: 'Design',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in any stream + Presidency DAT / UCEED + Portfolio',
      highlights: 'Textile chemistry, garment construction, pattern making, trend forecasting, runway production.',
      careers: 'Fashion Stylist, Apparel Designer, Fashion Merchandiser, Costume Designer.'
    },
    {
      id: 'bdes-game',
      name: 'B.Des in Game Design & Augmented Reality',
      school: 'Design',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in any stream + DAT / UCEED + Portfolio',
      highlights: '3D modeling with Maya/Blender, Unreal Engine, game psychology, AR/VR immersive worlds.',
      careers: 'Game Level Designer, 3D Character Artist, VR Environment Creator.'
    },
    {
      id: 'bdes-communication',
      name: 'B.Des in Communication Design',
      school: 'Design',
      level: 'Undergraduate',
      duration: '4 Years (8 Semesters)',
      eligibility: '10+2 with 45% in any stream + DAT / UCEED + Portfolio',
      highlights: 'Typography, branding, UI/UX interaction design, motion graphics, advertising campaigns.',
      careers: 'UI/UX Designer, Brand Identity Specialist, Motion Graphic Designer.'
    },

    // Computer Science & Info Science (BCA/MCA)
    {
      id: 'bca-general',
      name: 'BCA (Bachelor of Computer Applications)',
      school: 'Computer Science',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 with 45% aggregate with Mathematics, Computer Science, or Statistics preference',
      highlights: 'Object-oriented programming in Java & C++, web technologies, database management, cloud basics.',
      careers: 'Software Developer, Web Developer, Quality Assurance Engineer, Systems Support Specialist.'
    },
    {
      id: 'bca-cloud-ai',
      name: 'BCA with Cloud Computing & AI',
      school: 'Computer Science',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 with 45% aggregate with Mathematics or Computer Science',
      highlights: 'AWS and Azure cloud architectures, machine learning models, containerization with Docker.',
      careers: 'Cloud Support Associate, Junior ML Developer, DevOps Associate.'
    },
    {
      id: 'mca',
      name: 'MCA (Master of Computer Applications)',
      school: 'Computer Science',
      level: 'Postgraduate',
      duration: '2 Years (4 Semesters)',
      eligibility: 'BCA / B.Sc. (CS/IT) or graduation with Mathematics at 10+2 or Degree level with min 50% + PGCET/KMAT',
      highlights: 'Enterprise full stack development, software engineering, AI integrations, capstone industry project.',
      careers: 'Senior Software Engineer, Full Stack Developer, Technical Consultant.'
    },

    // Commerce
    {
      id: 'bcom-hons',
      name: 'B.Com (Honours)',
      school: 'Commerce',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 / PUC in Commerce or Science with minimum 45% aggregate',
      highlights: 'Corporate financial accounting, business law, cost accounting, auditing standards.',
      careers: 'Accountant, Financial Auditor, Tax Consultant, Commercial Banking Executive.'
    },
    {
      id: 'bcom-taxation',
      name: 'B.Com (Corporate Accounting & Taxation)',
      school: 'Commerce',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 / PUC in Commerce or Science with minimum 45% aggregate',
      highlights: 'Direct tax, GST compliance, international taxation, Ind-AS accounting principles, ACCA alignment.',
      careers: 'Tax Associate, Corporate Accountant, Financial Compliance Analyst.'
    },

    // Allied Health Sciences
    {
      id: 'bsc-mlt',
      name: 'B.Sc. Medical Laboratory Technology (MLT)',
      school: 'Allied Health',
      level: 'Undergraduate',
      duration: '3.5 to 4 Years (including internship)',
      eligibility: '10+2 with Physics, Chemistry, Biology (PCB) with minimum 45% aggregate',
      highlights: 'Clinical biochemistry, hematology, microbiology, pathology labs, diagnostic testing.',
      careers: 'Clinical Lab Scientist, Pathology Specialist, Diagnostic Lab Manager.'
    },
    {
      id: 'bsc-radiology',
      name: 'B.Sc. Medical Imaging Technology (Radiology)',
      school: 'Allied Health',
      level: 'Undergraduate',
      duration: '3.5 to 4 Years (including clinical internship)',
      eligibility: '10+2 with Physics, Chemistry, Biology (PCB) with minimum 45% aggregate',
      highlights: 'X-Ray, Computed Tomography (CT), Magnetic Resonance Imaging (MRI), radiation safety.',
      careers: 'Radiology Technologist, MRI/CT Scan Specialist, Diagnostic Imaging Officer.'
    },
    {
      id: 'bsc-anesthesia-ot',
      name: 'B.Sc. Anesthesia & Operation Theatre Technology',
      school: 'Allied Health',
      level: 'Undergraduate',
      duration: '3.5 to 4 Years (including internship)',
      eligibility: '10+2 with Physics, Chemistry, Biology (PCB) with minimum 45% aggregate',
      highlights: 'Surgical preparation, anesthesia machinery, patient vitals monitoring in ICU and operation theatres.',
      careers: 'Anesthesia Technologist, OT In-Charge, Critical Care Support Specialist.'
    },
    {
      id: 'bsc-optometry',
      name: 'B.Sc. Optometry',
      school: 'Allied Health',
      level: 'Undergraduate',
      duration: '4 Years (including 1 year clinical internship)',
      eligibility: '10+2 with Physics, Chemistry, Biology (PCB) with minimum 45% aggregate',
      highlights: 'Refraction diagnostics, contact lens fitting, ocular disease screening, vision rehabilitation.',
      careers: 'Optometrist, Vision Care Specialist, Ophthalmic Clinical Assistant.'
    },

    // Media
    {
      id: 'ba-journalism',
      name: 'B.A. in Journalism and Mass Communication',
      school: 'Media',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 in any stream from a recognized board with min 45% aggregate',
      highlights: 'Print reporting, TV studio production, digital podcasts, PR, advertising campaigns.',
      careers: 'Journalist, News Anchor, Digital Content Creator, PR Executive, Corporate Communications Officer.'
    },

    // Basic Sciences
    {
      id: 'bsc-forensic',
      name: 'B.Sc. in Forensic Science',
      school: 'Basic Sciences',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 with Science stream (Physics, Chemistry, Biology/Maths) with min 45% aggregate',
      highlights: 'Crime scene simulation, fingerprinting, questioned documents, toxicology, forensic DNA profiling.',
      careers: 'Forensic Investigator, Crime Scene Analyst, Laboratory Fingerprint Expert.'
    },
    {
      id: 'bsc-biotechnology',
      name: 'B.Sc. in Biotechnology',
      school: 'Basic Sciences',
      level: 'Undergraduate',
      duration: '3 Years (6 Semesters)',
      eligibility: '10+2 with Physics, Chemistry, Biology with min 45% aggregate',
      highlights: 'Genetic engineering, molecular biology, fermentation technology, bio-safety laminar flow hoods.',
      careers: 'Biotech Research Assistant, Quality Control Analyst in Pharma, Bioprocess Technician.'
    }
  ];

  // Filtering
  const filteredCourses = coursesList.filter((course) => {
    const matchesSchool = selectedSchool === 'All' || course.school === selectedSchool;
    const matchesLevel = selectedLevel === 'All' || course.level === selectedLevel;
    const matchesSearch = searchQuery === '' || 
      course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.highlights.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.careers.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSchool && matchesLevel && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Page Title Banner */}
      <div className="relative rounded-3xl p-8 sm:p-12 text-white shadow-xl overflow-hidden border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/88 via-[#0d2346]/80 to-[#163e72]/75 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Academic Programs Catalog 2026-27</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Courses & Academic Programs
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Discover undergraduate, postgraduate, and doctoral degrees offered across 9 specialized schools at Presidency University Bengaluru.
          </p>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5">
        <div className="flex flex-col md:flex-row items-center gap-4 justify-between">
          {/* Search Box */}
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search course name, subjects, careers..."
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 focus:outline-none transition"
            />
          </div>

          {/* Level Filter (UG / PG / All) */}
          <div className="flex items-center gap-2 self-start md:self-auto text-xs">
            <span className="text-slate-500 font-medium flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Level:</span>
            </span>
            {['All', 'Undergraduate', 'Postgraduate'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  selectedLevel === lvl
                    ? 'bg-[#091b33] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        {/* School Horizontal Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
          {schools.map((sch) => (
            <button
              key={sch.id}
              onClick={() => setSelectedSchool(sch.id)}
              className={`px-3.5 py-2 rounded-xl whitespace-nowrap font-semibold transition flex items-center gap-1.5 ${
                selectedSchool === sch.id
                  ? 'bg-blue-600 text-[#091b33] shadow-md font-bold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>{sch.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-500 px-1">
          <span>Showing <strong>{filteredCourses.length}</strong> academic programs</span>
          <span>Click "Ask AI" on any course for instant verified criteria</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredCourses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-blue-400 shadow-sm hover:shadow-md transition flex flex-col justify-between group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-bold text-blue-800 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded uppercase tracking-wider">
                    {course.school}
                  </span>
                  <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    {course.level}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 group-hover:text-[#091b33] transition">
                  {course.name}
                </h3>

                <div className="flex items-center gap-4 text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-blue-600" />
                    <span>{course.duration}</span>
                  </span>
                </div>

                {/* Eligibility Summary */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    Eligibility Requirement:
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {course.eligibility}
                  </p>
                </div>

                {/* Highlights */}
                <div>
                  <span className="text-[11px] font-bold text-slate-700 block mb-0.5">
                    Program Focus & Labs:
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {course.highlights}
                  </p>
                </div>

                {/* Career Pathways */}
                <div>
                  <span className="text-[11px] font-bold text-slate-700 block mb-0.5">
                    Career Opportunities:
                  </span>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {course.careers}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => onAskAI(`What is the eligibility and fee for ${course.name}?`)}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-xs rounded-lg border border-blue-400/30 transition flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>Ask AI Details</span>
                </button>

                <button
                  onClick={() => setActivePage('admissions')}
                  className="px-3.5 py-1.5 bg-[#091b33] hover:bg-[#163e72] text-white text-xs font-semibold rounded-lg transition flex items-center gap-1"
                >
                  <span>Apply Now</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
