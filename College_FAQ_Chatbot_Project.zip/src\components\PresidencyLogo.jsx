import React from 'react';

export default function PresidencyLogo({ className = "h-11 sm:h-12", light = false }) {
  return (
    <div className={`flex items-center select-none ${className}`}>
      {/* Official Presidency University Logo */}
      <img 
        src={light ? "/assets/presidency_official_logo_white.png" : "/assets/presidency_official_logo.png"}
        alt="Presidency University Bengaluru Logo" 
        className="h-full w-auto max-h-12 object-contain drop-shadow-sm transition-transform duration-200 group-hover:scale-[1.02]"
        loading="eager"
      />
    </div>
  );
}
