import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AIChatModal from './components/AIChatModal';
import QuickSearchModal from './components/QuickSearchModal';
import CampusMapModal from './components/CampusMapModal';
import Topic23ExplainerModal from './components/Topic23ExplainerModal';

// 12 Complete Pages
import Home from './pages/Home';
import About from './pages/About';
import Courses from './pages/Courses';
import Admissions from './pages/Admissions';
import FeesScholarships from './pages/FeesScholarships';
import CampusFacilities from './pages/CampusFacilities';
import HostelTransport from './pages/HostelTransport';
import Placements from './pages/Placements';
import CampusLife from './pages/CampusLife';
import EventsNotices from './pages/EventsNotices';
import Contact from './pages/Contact';
import CampusMateAssistant from './pages/CampusMateAssistant';

import { Sparkles, Compass } from 'lucide-react';

export default function App() {
  const validPages = ['home', 'about', 'courses', 'admissions', 'fees', 'facilities', 'hostel', 'placements', 'campus-life', 'events', 'contact', 'assistant'];

  const getInitialPage = () => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      if (validPages.includes(hash)) return hash;
      const params = new URLSearchParams(window.location.search);
      const pageParam = params.get('page')?.toLowerCase();
      if (validPages.includes(pageParam)) return pageParam;
    }
    return 'home';
  };

  const [activePage, setActivePageState] = useState(getInitialPage);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [selectedMapWaypoint, setSelectedMapWaypoint] = useState(null);
  const [currentAIQuery, setCurrentAIQuery] = useState('');
  const [isExplainerOpen, setIsExplainerOpen] = useState(false);

  // Dark Mode Theme State & Persistence
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('campusmate_theme');
      if (savedTheme === 'dark' || savedTheme === 'light') return savedTheme;
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
    }
    return 'light';
  });

  // Apply theme class to document element
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    try {
      localStorage.setItem('campusmate_theme', theme);
    } catch (e) {
      // Ignore local storage error in restricted contexts
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const setActivePage = (page) => {
    setActivePageState(page);
    if (typeof window !== 'undefined') {
      window.location.hash = page;
    }
  };

  // Sync with browser back/forward and hash changes
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      if (validPages.includes(hash)) {
        setActivePageState(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Handle direct "Ask AI" from any component/page
  const handleAskAI = (query) => {
    setCurrentAIQuery(query);
    setIsAIChatOpen(true);
  };

  // Handle opening campus map
  const handleOpenMap = (waypointId = null) => {
    setSelectedMapWaypoint(waypointId);
    setIsMapOpen(true);
  };

  // Scroll to top on page switch
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activePage]);

  // Render current active page with shared handlers
  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return <Home setActivePage={setActivePage} onAskAI={handleAskAI} onOpenMap={handleOpenMap} onOpenExplainer={() => setIsExplainerOpen(true)} />;
      case 'about':
        return <About setActivePage={setActivePage} onAskAI={handleAskAI} />;
      case 'courses':
        return <Courses setActivePage={setActivePage} onAskAI={handleAskAI} />;
      case 'admissions':
        return <Admissions setActivePage={setActivePage} onAskAI={handleAskAI} />;
      case 'fees':
        return <FeesScholarships setActivePage={setActivePage} onAskAI={handleAskAI} />;
      case 'facilities':
        return <CampusFacilities setActivePage={setActivePage} onAskAI={handleAskAI} onOpenMap={handleOpenMap} />;
      case 'hostel':
        return <HostelTransport setActivePage={setActivePage} onAskAI={handleAskAI} onOpenMap={handleOpenMap} />;
      case 'placements':
        return <Placements setActivePage={setActivePage} onAskAI={handleAskAI} />;
      case 'campus-life':
        return <CampusLife setActivePage={setActivePage} onAskAI={handleAskAI} onOpenMap={handleOpenMap} />;
      case 'events':
        return <EventsNotices setActivePage={setActivePage} onAskAI={handleAskAI} />;
      case 'contact':
        return <Contact setActivePage={setActivePage} onAskAI={handleAskAI} onOpenMap={handleOpenMap} />;
      case 'assistant':
        return <CampusMateAssistant initialQuery={currentAIQuery} onOpenMap={handleOpenMap} />;
      default:
        return <Home setActivePage={setActivePage} onAskAI={handleAskAI} onOpenMap={handleOpenMap} onOpenExplainer={() => setIsExplainerOpen(true)} />;
    }
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-sans antialiased selection:bg-blue-600 selection:text-white transition-colors duration-200">
      {/* Navigation Header */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        theme={theme}
        toggleTheme={toggleTheme}
        onOpenMap={handleOpenMap}
        onOpenExplainer={() => setIsExplainerOpen(true)}
      />

      {/* Main Page Content */}
      <main className="flex-1 pb-20 sm:pb-12">
        {renderPage()}
      </main>

      {/* University Footer */}
      <Footer
        setActivePage={setActivePage}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        onOpenMap={handleOpenMap}
      />

      {/* Persistent Floating AI Chat Trigger Widget (Hidden when on dedicated assistant page) */}
      {activePage !== 'assistant' && (
        <aside className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40" aria-label="College FAQ Chatbot floating launcher">
          <button
            onClick={() => setIsAIChatOpen(true)}
            className="flex items-center gap-2 sm:gap-3 pl-2 sm:pl-2.5 pr-3 sm:pr-4 py-2 sm:py-2.5 rounded-full bg-gradient-to-r from-[#091b33] via-[#0d2346] to-[#163e72] hover:from-[#0d2346] hover:to-[#1a4985] text-white shadow-2xl border border-blue-400/40 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer group"
            aria-label="Open College FAQ Chatbot"
          >
            <div className="relative flex-shrink-0">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white p-0.5 flex items-center justify-center shadow-xs">
                <img src="/assets/presidency_crest_symbol.png" alt="Crest" className="w-full h-full object-contain" />
              </div>
              <span className="absolute -top-0.5 -right-0.5 w-2 sm:w-2.5 h-2 sm:h-2.5 bg-emerald-400 rounded-full border-2 border-[#091b33] animate-ping"></span>
            </div>
            <div className="text-left flex-shrink-0">
              <div className="flex items-center gap-1 font-bold text-xs sm:text-sm tracking-wide text-white">
                <span className="hidden sm:inline">College FAQ Bot</span>
                <span className="sm:hidden">FAQ Bot</span>
                <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-300 group-hover:rotate-12 transition transform" />
              </div>
              <div className="text-[10px] text-slate-300 font-medium hidden sm:block">Verified FAQ Assistant</div>
            </div>
          </button>
        </aside>
      )}

      {/* Floating AI Chat Modal */}
      <AIChatModal
        isOpen={isAIChatOpen && activePage !== 'assistant'}
        onClose={() => setIsAIChatOpen(false)}
        initialQuery={currentAIQuery}
        onOpenMap={handleOpenMap}
      />

      {/* Global Quick Search Modal (Ctrl+K) */}
      <QuickSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectQuestion={(q) => handleAskAI(q)}
        setActivePage={setActivePage}
      />

      {/* Interactive Campus Map Navigator Modal */}
      <CampusMapModal
        isOpen={isMapOpen}
        onClose={() => setIsMapOpen(false)}
        onAskAI={handleAskAI}
        initialWaypointId={selectedMapWaypoint}
      />

      {/* Topic 23 Explainer & Architecture Modal */}
      <Topic23ExplainerModal
        isOpen={isExplainerOpen}
        onClose={() => setIsExplainerOpen(false)}
        onRunDemoQuery={(q) => handleAskAI(q)}
      />
    </div>
  );
}
