import React, { useState, useEffect, useRef } from 'react';
import { Search, X, BookOpen, ExternalLink, Sparkles, ArrowRight, CornerDownLeft } from 'lucide-react';
import { searchKnowledgeBase } from '../services/aiRetrievalEngine';
import { universityMetadata } from '../data/universityDatabase';

export default function QuickSearchModal({ isOpen, onClose, onSelectQuestion, setActivePage }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState([]);
  const inputRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setSearchQuery('');
      setResults([]);
    }
  }, [isOpen]);

  // Handle Ctrl+K shortcut
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else onClose(true);
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Handle Search Input Change
  const handleInputChange = (e) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (val.trim().length > 1) {
      const hits = searchKnowledgeBase(val, 10);
      setResults(hits);
    } else {
      setResults([]);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-150 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3 bg-slate-50 dark:bg-slate-900">
          <Search className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={handleInputChange}
            placeholder="Search across courses, admissions, fees, hostel, placements, syllabus..."
            className="flex-1 bg-transparent border-none text-sm text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => {
                setSearchQuery('');
                setResults([]);
              }}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 px-2 py-1 bg-slate-200/80 dark:bg-slate-800 rounded border border-slate-300 dark:border-slate-700 cursor-pointer font-mono"
          >
            ESC
          </button>
        </div>

        {/* Results Container */}
        <div className="overflow-y-auto p-3 flex-1 space-y-2 dark:bg-slate-900">
          {searchQuery.trim().length <= 1 ? (
            <div className="p-6 text-center text-slate-500 dark:text-slate-400">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-blue-50 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-400">
                <Search className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1">Search Presidency University Knowledge</h4>
              <p className="text-xs text-slate-400 dark:text-slate-500 max-w-sm mx-auto">
                Type course names (e.g. "B.Tech CSE DevOps", "MBA"), "fees", "hostel rules", "scholarships", or "placements" to view instant verified answers.
              </p>

              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {[
                  "B.Tech CSE DevOps Fees",
                  "Cafeteria Location",
                  "Hostel Fees",
                  "Highest Package",
                  "Bus Transportation",
                  "Scholarships 90%+"
                ].map((sample) => (
                  <button
                    key={sample}
                    onClick={() => {
                      setSearchQuery(sample);
                      setResults(searchKnowledgeBase(sample, 8));
                    }}
                    className="text-xs px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-blue-800 dark:hover:text-blue-300 rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                  >
                    {sample}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center text-slate-500 dark:text-slate-400">
              <p className="text-sm font-medium">No direct matches found for "{searchQuery}"</p>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 mb-4">
                You can ask the College FAQ Chatbot to find the closest match or check the official university website.
              </p>
              <button
                onClick={() => {
                  onClose();
                  onSelectQuestion(searchQuery);
                }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#091b33] dark:bg-blue-600 hover:bg-[#163e72] dark:hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition shadow-md cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-blue-300 dark:text-white" />
                <span>Ask FAQ Chatbot: "{searchQuery}"</span>
              </button>
            </div>
          ) : (
            results.map((entry) => (
              <div
                key={entry.id}
                onClick={() => {
                  onClose();
                  onSelectQuestion(entry.question);
                }}
                className="p-3 bg-white dark:bg-slate-800/80 hover:bg-blue-50/60 dark:hover:bg-slate-700/60 rounded-xl border border-slate-200 dark:border-slate-700/80 hover:border-blue-300 dark:hover:border-blue-500 transition cursor-pointer group"
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-[10px] font-bold text-blue-800 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/40 border border-blue-200 dark:border-blue-800 px-2 py-0.5 rounded uppercase tracking-wider">
                    {entry.category}
                  </span>
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 group-hover:text-blue-700 dark:group-hover:text-blue-400 transition">
                    <span>Ask in chat</span>
                    <CornerDownLeft className="w-3 h-3" />
                  </span>
                </div>
                <h5 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-[#091b33] dark:group-hover:text-blue-300 transition">
                  {entry.question}
                </h5>
                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                  {entry.answer}
                </p>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between px-4">
          <span className="flex items-center gap-1.5 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>Search {universityMetadata.totalFAQEntries}+ verified university records</span>
          </span>
          <span className="hidden sm:inline font-mono text-[10px] text-slate-400">ESC to close</span>
        </div>
      </div>
    </div>
  );
}
