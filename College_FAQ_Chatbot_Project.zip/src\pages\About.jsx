import React from 'react';
import { 
  Building2, 
  Award, 
  ShieldCheck, 
  BookOpen, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  ExternalLink,
  ChevronRight,
  GraduationCap
} from 'lucide-react';
import { universityMetadata } from '../data/universityDatabase';

export default function About({ setActivePage, onAskAI }) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner with Real Campus Background */}
      <div className="rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden bg-slate-950 border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/80 via-[#0a1e3b]/65 to-[#091b33]/60 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-500/20 text-blue-200 text-xs font-semibold border border-blue-400/30">
            <Award className="w-3.5 h-3.5 text-blue-300" />
            <span>Statutory State Private University • Estd. 2013</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif text-white tracking-tight">
            About Presidency University
          </h1>
          <p className="text-sm text-slate-200 leading-relaxed font-normal">
            Presidency University, Bengaluru was constituted by the Karnataka Act No. 41 of 2013, drawing upon the 48-year educational legacy of the Presidency Group of Institutions (founded in 1976).
          </p>
          <div className="flex flex-wrap gap-2 pt-2">
            <span className="text-[11px] bg-white/10 text-slate-200 px-3 py-1 rounded-full border border-white/20">
              UGC Recognised Section 2(f)
            </span>
            <span className="text-[11px] bg-white/10 text-slate-200 px-3 py-1 rounded-full border border-white/20">
              AICTE Approved
            </span>
            <span className="text-[11px] bg-white/10 text-slate-200 px-3 py-1 rounded-full border border-white/20">
              Bar Council of India Approved
            </span>
            <span className="text-[11px] bg-white/10 text-slate-200 px-3 py-1 rounded-full border border-white/20">
              AIU Member
            </span>
          </div>
        </div>
      </div>

      {/* Leadership & Chancellor */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm">
        <div className="lg:col-span-1 text-center bg-slate-50 rounded-2xl p-6 border border-slate-200">
          <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-tr from-[#091b33] to-blue-700 p-1 mb-4 shadow-lg ring-4 ring-blue-100/70 overflow-hidden">
            <img 
              src="/assets/chancellor-dr-nissar-ahmed.webp" 
              alt="Dr. Nissar Ahmed - Chancellor, Presidency University" 
              className="w-full h-full object-cover object-top rounded-full bg-slate-100" 
            />
          </div>
          <h3 className="text-lg font-bold text-[#091b33]">Dr. Nissar Ahmed</h3>
          <p className="text-xs font-semibold text-blue-600 mt-0.5">Chancellor & Founder</p>
          <p className="text-[11px] text-slate-500 mt-2">
            Chairman, Presidency Group of Institutions (PGI)
          </p>
          <button
            onClick={() => onAskAI("Who is the Chancellor of Presidency University?")}
            className="mt-4 px-3 py-1.5 bg-white text-xs font-semibold text-slate-700 hover:text-blue-800 rounded-lg border border-slate-200 hover:border-blue-300 transition flex items-center justify-center gap-1.5 w-full cursor-pointer shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Ask AI About Leadership</span>
          </button>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
            Chancellor's Vision & Heritage
          </div>
          <h2 className="text-2xl font-bold text-[#091b33] font-serif">
            "Gain More Knowledge, Reach Greater Heights"
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Dr. Nissar Ahmed founded the Presidency Group in 1976 with a vision of holistic value-based education. Over nearly five decades, the group has nurtured more than 50,000 students across premier schools and colleges. 
          </p>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Presidency University stands as the pinnacle of this educational journey, offering global-standard academic infrastructure, contemporary interdisciplinary curriculum, international academic partnerships, and strong corporate integration.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-base font-bold text-[#091b33]">1976</div>
              <div className="text-[10px] text-slate-500">Group Established</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-base font-bold text-[#091b33]">2013</div>
              <div className="text-[10px] text-slate-500">University Enacted</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-base font-bold text-[#091b33]">65+ Acres</div>
              <div className="text-[10px] text-slate-500">Lush Green Campus</div>
            </div>
          </div>
        </div>
      </div>

      {/* Vision, Mission, & Core Values */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs hover:border-blue-300 transition">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-4">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-2">Our Vision</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            To be a world-class institution of higher education and innovative research, empowering future leaders who create sustainable global impact and advance human welfare.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs hover:border-blue-300 transition">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-4">
            <GraduationCap className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-2">Our Mission</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            To provide transformative learning experiences, cutting-edge experiential pedagogy, industry immersion, and strong ethical grounding across multidisciplinary domains.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs hover:border-blue-300 transition">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-4">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-2">Core Values</h3>
          <ul className="text-xs text-slate-600 space-y-1.5">
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Academic Integrity & Excellence</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Innovation & Research Driven</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Inclusivity & Social Responsibility</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Global Citizenship & Ethics</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Statutory Status & Recognitions */}
      <div className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-200 space-y-6">
        <div>
          <h3 className="text-xl font-bold text-[#091b33] font-serif">
            Statutory Status & Recognitions
          </h3>
          <p className="text-xs text-slate-600 mt-1">
            Presidency University operates strictly in accordance with state and national higher education regulatory frameworks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h4 className="text-xs font-bold text-slate-900">UGC Recognition</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              Recognized under Section 2(f) of the UGC Act, 1956 as a State Private University empowered to award degrees.
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h4 className="text-xs font-bold text-slate-900">AICTE Approval</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              Approved by the All India Council for Technical Education (AICTE), New Delhi for engineering and technical curricula.
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h4 className="text-xs font-bold text-slate-900">Bar Council of India</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              School of Law 5-year integrated law programs are approved by the Bar Council of India (BCI).
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h4 className="text-xs font-bold text-slate-900">AIU Membership</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              Member of the Association of Indian Universities (AIU), facilitating national and international degree equivalence.
            </p>
          </div>
        </div>
      </div>

      {/* Official Links & Verification Banner */}
      <div className="bg-[#091b33] text-white rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-white">Need Official Documents or Disclosures?</h4>
          <p className="text-xs text-slate-300 mt-0.5">
            Visit the official university statutory disclosures and mandatory committee reports.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="https://presidencyuniversity.in/"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg transition flex items-center gap-1.5"
          >
            <span>presidencyuniversity.in</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            onClick={() => onAskAI("When was Presidency University established?")}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-lg border border-white/20 transition flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Ask AI About Act</span>
          </button>
        </div>
      </div>
    </div>
  );
}
