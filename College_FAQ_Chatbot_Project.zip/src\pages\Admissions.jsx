import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  FileText, 
  ExternalLink, 
  Sparkles, 
  ArrowRight, 
  Calendar, 
  HelpCircle,
  Phone,
  Mail,
  Award
} from 'lucide-react';
import { universityMetadata } from '../data/universityDatabase';

export default function Admissions({ onAskAI, setActivePage }) {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryCourse, setInquiryCourse] = useState('B.Tech Computer Science');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (inquiryName && inquiryPhone) {
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    }
  };

  const steps = [
    {
      num: '01',
      title: 'Online Application / Registration',
      desc: 'Visit presidencyuniversity.in, register with email & mobile, complete personal details, and pay the nominal application fee (~₹1,000).'
    },
    {
      num: '02',
      title: 'Submit Academic & Entrance Scores',
      desc: 'Upload 10th and 12th / Degree marks cards, along with valid scorecards of KCET, COMEDK, JEE Main, PGCET, CAT, MAT, CLAT, or DAT.'
    },
    {
      num: '03',
      title: 'Admissions Committee Evaluation',
      desc: 'The committee evaluates applications on academic merit and entrance performance. Personal interviews / design aptitude tests are scheduled where applicable.'
    },
    {
      num: '04',
      title: 'Provisional Offer & Seat Confirmation',
      desc: 'Eligible candidates receive a Provisional Admission Offer Letter. Candidates confirm their seat by depositing the initial enrollment fee.'
    },
    {
      num: '05',
      title: 'Document Verification & Enrollment',
      desc: 'Produce original certificates (Marks cards, TC, Migration) for registrar verification and receive student ID and ERP credentials.'
    }
  ];

  const exams = [
    { program: 'B.Tech Engineering', exams: 'Karnataka CET (KCET), COMEDK UGET, JEE Main, or University Evaluation Test' },
    { program: 'MBA (Management)', exams: 'Karnataka PGCET, CAT, MAT, XAT, CMAT, ATMA, KMAT' },
    { program: 'School of Law (BA LLB / BBA LLB)', exams: 'CLAT, LSAT-India, or Presidency University Law Admission Test (PULAT)' },
    { program: 'School of Design (B.Des)', exams: 'Presidency Design Aptitude Test (DAT) / UCEED + Portfolio Review' },
    { program: 'MCA / M.Tech', exams: 'Karnataka PGCET, GATE, or University Entrance Test' }
  ];

  const documents = [
    "Class 10th / SSLC Marks Card (Proof of Date of Birth)",
    "Class 12th / PUC / Equivalent Marks Card",
    "Undergraduate Degree Marks Cards & Provisional Degree Certificate (For PG / MBA / M.Tech applicants)",
    "Transfer Certificate (TC) from previous institution",
    "Migration Certificate (For students outside Karnataka or non-state boards like CBSE/ICSE)",
    "Entrance Examination Scorecard / Rank Card (KCET, COMEDK, JEE, CLAT, CAT, etc.)",
    "Conduct / Character Certificate",
    "Caste / Category / Income Certificate (If claiming reservation under Karnataka govt norms)",
    "Copy of Aadhar Card / Valid Photo ID Proof",
    "Recent passport-size color photographs (6 copies)"
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-8 sm:p-12 text-white shadow-xl overflow-hidden border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/88 via-[#0d2346]/80 to-[#163e72]/75 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Admissions Session 2026-27</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Admissions & Eligibility Guide
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Presidency University Bengaluru welcomes aspiring engineers, managers, lawyers, designers, and scientists. Admissions are granted on academic merit, national entrance rankings, and state quotas.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="https://presidencyuniversity.in/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-1.5"
            >
              <span>Apply Online at Official Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => onAskAI("What is the admission process for B.Tech CSE?")}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Ask AI About Process</span>
            </button>
          </div>
        </div>
      </div>

      {/* Step-by-Step Workflow */}
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-[#091b33] font-serif">
            Step-by-Step Admission Process
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Follow these streamlined steps to complete your admission at Presidency University.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {steps.map((st) => (
            <div
              key={st.num}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:border-blue-300 transition flex flex-col justify-between"
            >
              <div>
                <span className="font-mono text-xs font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md inline-block mb-3 border border-blue-200">
                  Step {st.num}
                </span>
                <h3 className="text-sm font-bold text-slate-900 mb-2">{st.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{st.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Accepted Entrance Exams Table */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h3 className="text-xl font-bold text-[#091b33] font-serif">
            Accepted Entrance Examinations
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Scores from state, national, and university entrance examinations are accepted across various schools.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Program / Discipline</th>
                <th className="py-3 px-4">Accepted Entrance Examinations</th>
                <th className="py-3 px-4 text-right">Instant AI Lookup</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {exams.map((ex, idx) => (
                <tr key={idx} className="hover:bg-blue-50/40 transition">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{ex.program}</td>
                  <td className="py-3.5 px-4 text-slate-600">{ex.exams}</td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => onAskAI(`What entrance exams are accepted for ${ex.program}?`)}
                      className="text-[11px] font-semibold text-blue-700 hover:text-blue-900 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 hover:bg-blue-100 transition inline-flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-blue-600" />
                      <span>Ask AI</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Required Documents Checklist */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-bold text-[#091b33]">
              Required Documents Checklist
            </h3>
          </div>
          <p className="text-xs text-slate-600">
            Please prepare original copies along with 2 sets of attested photocopies for document verification:
          </p>

          <ul className="space-y-2.5 pt-2">
            {documents.map((doc, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span>{doc}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Quick Admission Assistance Card */}
        <div className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-200 space-y-5">
          <div>
            <span className="text-[10px] font-bold text-blue-700 bg-blue-100 px-2.5 py-0.5 rounded uppercase tracking-wider">
              Admissions Desk
            </span>
            <h3 className="text-lg font-bold text-[#091b33] mt-1.5">
              Request Admission Assistance
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Have questions regarding seat allotment or eligibility? Submit your details for guidance from our admission counselors.
            </p>
          </div>

          {submitted ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs text-center space-y-1">
              <div className="font-bold">Thank You! Your Inquiry Has Been Recorded.</div>
              <p>An admission counselor will contact you shortly on {inquiryPhone}.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={inquiryName}
                  onChange={(e) => setInquiryName(e.target.value)}
                  placeholder="Student or Parent Full Name"
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Mobile Contact Number</label>
                <input
                  type="tel"
                  required
                  value={inquiryPhone}
                  onChange={(e) => setInquiryPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Interested Program</label>
                <select
                  value={inquiryCourse}
                  onChange={(e) => setInquiryCourse(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none"
                >
                  <option value="B.Tech Computer Science">B.Tech Computer Science & Engg</option>
                  <option value="B.Tech AI & ML">B.Tech AI & Machine Learning</option>
                  <option value="MBA">MBA (Master of Business Admin)</option>
                  <option value="B.A. LL.B. (Hons)">B.A. LL.B. (5 Year Law)</option>
                  <option value="B.Des">B.Des (Design)</option>
                  <option value="BCA">BCA (Computer Applications)</option>
                  <option value="B.Sc Allied Health">B.Sc Allied Health Sciences</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#091b33] hover:bg-[#163e72] text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
              >
                Submit Admission Request
              </button>
            </form>
          )}

          <div className="pt-2 border-t border-slate-200 text-xs text-slate-600 space-y-1.5">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-blue-600" />
              <span>Helpline: +91 90220 92222 / 080 4925 5555</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-blue-600" />
              <span>admission@presidencyuniversity.in</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
