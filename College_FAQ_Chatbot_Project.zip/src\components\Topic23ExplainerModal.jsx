import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  BookOpen, 
  Database, 
  Cpu, 
  ShieldAlert, 
  PlayCircle, 
  CheckCircle2, 
  ArrowRight,
  ExternalLink,
  MessageSquare,
  HelpCircle,
  Search,
  Code
} from 'lucide-react';

export default function Topic23ExplainerModal({ isOpen, onClose, onRunDemoQuery }) {
  const [activeTab, setActiveTab] = useState('overview');

  if (!isOpen) return null;

  const demoScenarios = [
    {
      title: "1. Specific Program & Fee Inquiry",
      badge: "Intent: Fee Structure",
      query: "What is the fee structure for B.Tech CSE DevOps?",
      description: "Tests TF-IDF exact token weighting for specialized degree tracks (CSE DevOps) vs general CSE.",
      expected: "Returns exact annual tuition (₹2,75,000/yr) with hostel & bus fee options."
    },
    {
      title: "2. Typo & Student Slang Normalization",
      badge: "Intent: Typo Tolerance",
      query: "what is the fess of cse in presidancy colg",
      description: "Tests dictionary normalization ('fess' -> fee, 'presidancy colg' -> Presidency College/University) and Levenshtein distance.",
      expected: "Successfully maps to B.Tech Computer Science fees without error."
    },
    {
      title: "3. Contextual Multi-Turn Follow-Up",
      badge: "Intent: Context Follow-Up",
      query: "What about its placements and highest package?",
      description: "Tests conversational entity memory to resolve 'its' with the previously discussed program or university.",
      expected: "Returns ₹13.58 LPA highest package, 97% placement rate, and top recruiters."
    },
    {
      title: "4. Physical Campus Navigation & Waypoint",
      badge: "Intent: Campus Location",
      query: "Where is the cafeteria located on campus?",
      description: "Tests location intent recognition, provides building & floor directions, and renders the interactive campus map button.",
      expected: "Floor directions for Central Food Court + 'View on Interactive Map' button."
    },
    {
      title: "5. Safe Fallback Response (Anti-Hallucination)",
      badge: "Intent: Graceful Fallback",
      query: "Who won the FIFA World Cup in 2022?",
      description: "Tests out-of-domain query detection where confidence score falls below the threshold.",
      expected: "Polite fallback refusing off-topic facts, displaying official university helpdesk contacts & suggested queries."
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl max-h-[90vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden text-slate-800 dark:text-slate-100 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#091b33] via-[#0e2a52] to-[#163e72] text-white px-5 sm:px-8 py-5 flex items-center justify-between border-b border-blue-500/30">
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-blue-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-400/20 text-blue-300 border border-blue-400/40 uppercase tracking-wider">
                  TOPIC 23
                </span>
                <span className="text-[11px] text-blue-200 font-medium hidden sm:inline">
                  Academic Project Evaluation Guide
                </span>
              </div>
              <h2 className="text-base sm:text-xl font-bold tracking-tight text-white mt-0.5">
                Building a FAQ Chatbot for a College Website
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-full transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 sm:gap-2 px-4 sm:px-8 pt-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/60 overflow-x-auto text-xs sm:text-sm font-semibold">
          {[
            { id: 'overview', label: '1. Overview & Goal', icon: Sparkles },
            { id: 'knowledge', label: '2. Sample KB (265)', icon: Database },
            { id: 'retrieval', label: '3. Intents & Retrieval', icon: Cpu },
            { id: 'fallback', label: '4. Fallback Logic', icon: ShieldAlert },
            { id: 'demo', label: '5. Live Demo Suite', icon: PlayCircle }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 py-3 px-3 sm:px-4 border-b-2 whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 font-bold bg-white dark:bg-slate-800 rounded-t-xl'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-blue-50/70 dark:bg-blue-950/40 p-4 sm:p-5 rounded-2xl border border-blue-200 dark:border-blue-800">
                <h3 className="text-sm font-bold text-blue-900 dark:text-blue-200 uppercase tracking-wider mb-1">
                  Assignment Title & Problem Statement
                </h3>
                <p className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  TOPIC 23: Building a FAQ Chatbot for a College Website
                </p>
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 mt-2 leading-relaxed">
                  "Design a chatbot that answers common college FAQs from an approved sample knowledge base; explain intents or retrieval, fallback responses and a demo."
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-2">
                  <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-sm">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Real-World College Need</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    Presidency University spans 65+ acres with over 80 academic programs. Prospective students, parents, and admitted students frequently ask repetitive questions regarding fees, eligibility cutoffs, scholarship percentages, hostel dining, and building directions.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-2">
                  <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Zero-Hallucination Philosophy</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    Unlike non-deterministic LLMs that may hallucinate inaccurate fee structures or eligibility policies, this chatbot strictly binds its answers to an approved, authoritative knowledge base with official citation links.
                  </p>
                </div>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-5 bg-slate-50/50 dark:bg-slate-800/40 space-y-3">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Core Evaluation Requirements Fulfilled
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">1</span>
                    <div>
                      <strong className="block text-slate-800 dark:text-slate-100">Approved Knowledge Base:</strong>
                      <span className="text-slate-600 dark:text-slate-400">265 verified records across 8 university schools.</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">2</span>
                    <div>
                      <strong className="block text-slate-800 dark:text-slate-100">Intent & Retrieval System:</strong>
                      <span className="text-slate-600 dark:text-slate-400">TF-IDF tokenization, Cosine Similarity & Levenshtein matching.</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">3</span>
                    <div>
                      <strong className="block text-slate-800 dark:text-slate-100">Fallback Strategy:</strong>
                      <span className="text-slate-600 dark:text-slate-400">Threshold guardrails, official helpline handoff & suggestions.</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">4</span>
                    <div>
                      <strong className="block text-slate-800 dark:text-slate-100">Interactive Demo:</strong>
                      <span className="text-slate-600 dark:text-slate-400">Live chat modal, voice speech-to-text, and 10-waypoint map.</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SAMPLE KNOWLEDGE BASE */}
          {activeTab === 'knowledge' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Approved Sample Knowledge Base (265 Records)
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                    Structured in-memory JSON repository curated directly from official Presidency University prospectuses and university statutes.
                  </p>
                </div>
                <div className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 rounded-full text-xs font-bold border border-emerald-300 dark:border-emerald-800">
                  100% Verified
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-xl font-extrabold text-blue-600 dark:text-blue-400">80+</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-medium">Degree Programs</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-xl font-extrabold text-blue-600 dark:text-blue-400">265</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-medium">FAQ Question Pairs</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-xl font-extrabold text-blue-600 dark:text-blue-400">8</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-medium">Academic Schools</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-xl font-extrabold text-blue-600 dark:text-blue-400">10</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-medium">Campus Waypoints</div>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Knowledge Base Coverage Categories
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">School of Engineering (B.Tech CSE, AIML, DevOps)</span>
                    <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">64 FAQs</span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Admissions 2026-27 & Entrance Exam Criteria</span>
                    <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">42 FAQs</span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Tuition Fees, Hostels, Mess & Bus Transit</span>
                    <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">48 FAQs</span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Merit Scholarships (Up to 50% Tuition Waiver)</span>
                    <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">24 FAQs</span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Placements, Highest CTC & 550+ Recruiters</span>
                    <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">35 FAQs</span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Physical Campus Directions & Floor Locations</span>
                    <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">52 FAQs</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: INTENTS & RETRIEVAL */}
          {activeTab === 'retrieval' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Intent Classification & Retrieval Engine Architecture
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  How CampusMate translates natural language student queries into accurate knowledge base retrieval.
                </p>
              </div>

              {/* Retrieval Pipeline Steps */}
              <div className="space-y-3">
                <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-sm flex items-center justify-center flex-shrink-0">
                    1
                  </div>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-900 dark:text-white block text-sm">Preprocessing & Slang Normalization</strong>
                    <p className="text-slate-600 dark:text-slate-300">
                      Lowercases input, removes punctuation, and expands student slang / misspellings via a domain dictionary:
                      <code className="ml-1 text-[11px] bg-white dark:bg-slate-800 px-1 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                        fess → fee, colg/clg → college, univercity → university, cantin → cafeteria
                      </code>
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-sm flex items-center justify-center flex-shrink-0">
                    2
                  </div>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-900 dark:text-white block text-sm">TF-IDF Token Weighting & Exact Match Boosts</strong>
                    <p className="text-slate-600 dark:text-slate-300">
                      Calculates term frequencies against inverse document frequency. Distinct course identifiers like <span className="font-semibold text-blue-600 dark:text-blue-400">DevOps</span>, <span className="font-semibold text-blue-600 dark:text-blue-400">Cyber Security</span>, or <span className="font-semibold text-blue-600 dark:text-blue-400">Robotics</span> receive 4x importance multipliers so specific queries do not get conflated with general CSE.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-sm flex items-center justify-center flex-shrink-0">
                    3
                  </div>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-900 dark:text-white block text-sm">Cosine Vector Similarity & Levenshtein Fallback</strong>
                    <p className="text-slate-600 dark:text-slate-300">
                      Calculates dot-product cosine similarity between query and candidate question vectors. If exact match fails, a Levenshtein character distance matrix identifies closest matching keywords.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-sm flex items-center justify-center flex-shrink-0">
                    4
                  </div>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-900 dark:text-white block text-sm">Contextual Multi-Turn Follow-Up Resolution</strong>
                    <p className="text-slate-600 dark:text-slate-300">
                      When a user asks pronoun-based questions (e.g. <em>"what about its eligibility?"</em> or <em>"where is it?"</em>), the engine inherits entity tokens from the previous turn to retrieve the correct sub-record without requiring the user to retype the subject.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: FALLBACK STRATEGY */}
          {activeTab === 'fallback' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Fallback Responses & Anti-Hallucination Policy
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  Preserving university integrity when queries are unknown, ambiguous, or out-of-domain.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 dark:text-amber-200 space-y-1">
                  <strong className="text-sm font-bold block">Strict Non-Hallucination Guardrail</strong>
                  <p>
                    A college chatbot must never invent admission deadlines, fee figures, or placement packages. If the similarity score is below the confidence cutoff (0.15 threshold), the query is immediately intercepted by the fallback pipeline.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  The 4 Elements of a Verified Fallback Response:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-1">
                    <strong className="text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      1. Transparent Disclaimer
                    </strong>
                    <p className="text-slate-600 dark:text-slate-400">
                      Informs the student that the question is outside the approved college knowledge base.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-1">
                    <strong className="text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      2. Official University Contacts
                    </strong>
                    <p className="text-slate-600 dark:text-slate-400">
                      Supplies verified email (`admissions@presidencyuniversity.in`) and telephone (+91 90220 92222).
                    </p>
                  </div>

                  <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-1">
                    <strong className="text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      3. Official Portal Reference Link
                    </strong>
                    <p className="text-slate-600 dark:text-slate-400">
                      Renders direct clickable link to the official site (<a href="https://presidencyuniversity.in/" target="_blank" rel="noreferrer" className="text-blue-500 underline">presidencyuniversity.in</a>).
                    </p>
                  </div>

                  <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-1">
                    <strong className="text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      4. Clickable Suggestion Chips
                    </strong>
                    <p className="text-slate-600 dark:text-slate-400">
                      Offers popular college FAQ chips so the student can easily navigate to verified topics.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: LIVE DEMO TEST SUITE */}
          {activeTab === 'demo' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Live Evaluation Demo Suite
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                    Click any test scenario below to automatically launch and verify the chatbot live!
                  </p>
                </div>
                <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-3 py-1 rounded-full border border-blue-200 dark:border-blue-800">
                  Ready for Evaluation
                </div>
              </div>

              <div className="space-y-3">
                {demoScenarios.map((demo, idx) => (
                  <div 
                    key={idx}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-blue-400 dark:hover:border-blue-500 transition shadow-2xs space-y-2.5"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">{demo.title}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300">
                          {demo.badge}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          onClose();
                          if (onRunDemoQuery) onRunDemoQuery(demo.query);
                        }}
                        className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
                      >
                        <PlayCircle className="w-3.5 h-3.5" />
                        <span>Run Test in Chatbot</span>
                      </button>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-900/70 p-2.5 rounded-xl border border-slate-200/80 dark:border-slate-800 text-xs font-mono text-blue-600 dark:text-blue-300">
                      "{demo.query}"
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 font-semibold">Test Rationale: </span>
                        <span className="text-slate-700 dark:text-slate-300">{demo.description}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 font-semibold">Expected Output: </span>
                        <span className="text-emerald-700 dark:text-emerald-400 font-medium">{demo.expected}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 sm:px-8 py-4 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
            <span>Presidency University Bengaluru</span>
            <span>•</span>
            <span>Topic 23 CA-3 Project</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
}
