import re
import json

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    content = f.read()

questions = re.findall(r'"question":\s*"([^"]+)"', content)
print(f"Total Questions: {len(questions)}")

keywords_to_check = ['exam', 'student support', 'grievance', 'anti-ragging', 'counselling', 'disability', 'international', 're-evaluation', 'grading', 'attendance', 'hall ticket']

for kw in keywords_to_check:
    matches = [q for q in questions if kw.lower() in q.lower()]
    print(f"Keyword '{kw}': {len(matches)} matches")
    for m in matches[:2]:
        print(f"   - {m}")
