import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

import { cloudflare } from "@cloudflare/vite-plugin";

// https://vite.dev/config/
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss(), cloudflare()],
  preview: {
    allowedHosts: true,
    host: true,
    port: 3001
  },
  server: {
    allowedHosts: true,
    host: true,
    port: 3001
  }
})