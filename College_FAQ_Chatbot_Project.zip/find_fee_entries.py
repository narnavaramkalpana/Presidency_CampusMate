import re

with open('src/data/universityDatabase.js', 'r', encoding='utf-8') as f:
    text = f.read()

entries = re.findall(r'\{\s*"id":\s*(\d+),[\s\S]*?"question":\s*"([^"]+)",[\s\S]*?"answer":\s*"([^"]+)"[\s\S]*?"category":\s*"([^"]+)"', text)
for id_num, q, ans, cat in entries:
    if cat == "Fee structure" or "fee" in q.lower():
        print(f"ID {id_num}: {q}")
        print("  Answer preview:", ans[:250].replace('\n', ' '))
        print()
