import React, { useState, useEffect } from 'react';
import { 
  X, 
  MapPin, 
  Navigation, 
  Search, 
  ExternalLink, 
  Compass, 
  Clock, 
  Building2, 
  BookOpen, 
  Coffee, 
  Home as HomeIcon, 
  Cpu, 
  Activity, 
  Heart, 
  Bus, 
  Sparkles,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';

export const CAMPUS_WAYPOINTS = [
  {
    id: 'main-gate',
    name: 'Main Entrance & Security Gate',
    shortName: 'Main Gate',
    category: 'Entry & Transit',
    block: 'Campus Perimeter',
    floor: 'Ground Level',
    icon: Navigation,
    color: '#2563eb',
    coordinates: { x: 50, y: 88 },
    timings: '24/7 Security Access (Visitors: 9:00 AM - 5:00 PM)',
    description: 'Primary campus entry point on Rajanakunte Main Road with visitor registration, biometric turnstiles, and security kiosk.',
    directions: 'Located directly at the entrance facing Rajanakunte Main Road. All auto, taxi, and BMTC drop-offs happen here.',
    landmarks: 'Security Checkpoint 1, Visitor Reception Booth, Main Flag Mast',
    aiQuery: 'Where is the main entrance and how to reach Presidency University?'
  },
  {
    id: 'admin-block',
    name: 'Block A – Administrative & Admissions Office',
    shortName: 'Admin Block A',
    category: 'Administration',
    block: 'Block A',
    floor: 'Ground & 1st Floor',
    icon: Building2,
    color: '#0284c7',
    coordinates: { x: 50, y: 70 },
    timings: 'Monday – Saturday: 9:00 AM – 5:30 PM',
    description: 'Central administrative headquarters housing the Admissions Office, Vice Chancellor Secretariat, Registrar, Finance, and Student Grievance cell.',
    directions: 'From Main Gate, walk straight ahead along the central palm avenue for 100 meters. Block A is the prominent white-pillared building directly facing you.',
    landmarks: 'Ground Floor Admissions Helpdesk, Central Reception, University Boardroom',
    aiQuery: 'Where is the admission office located in Block A?'
  },
  {
    id: 'engineering-block',
    name: 'Block B & C – School of Engineering & Computing',
    shortName: 'Engineering Blocks',
    category: 'Academic',
    block: 'Blocks B & C',
    floor: 'Floors 1 to 4',
    icon: Cpu,
    color: '#4f46e5',
    coordinates: { x: 32, y: 52 },
    timings: 'Monday – Saturday: 8:30 AM – 5:00 PM',
    description: 'Core engineering classrooms, Dean of Engineering office, Computer Science lecture halls, NVIDIA GPU AI Lab, and Apple Mac Lab.',
    directions: 'From Block A, take the left covered pathway towards the academic quadrangle. Block B connects directly to Block C via skywalks on Floors 2 and 3.',
    landmarks: 'Apple Mac Lab (Floor 2), AI Research Centre, Engineering Dean Secretariat',
    aiQuery: 'Where are the engineering classrooms and computer labs located?'
  },
  {
    id: 'central-library',
    name: 'Dr. APJ Abdul Kalam Central Library',
    shortName: 'Central Library',
    category: 'Academic',
    block: 'Learning Hub (East Wing)',
    floor: 'Ground & 1st Floor',
    icon: BookOpen,
    color: '#059669',
    coordinates: { x: 68, y: 52 },
    timings: 'Monday – Saturday: 8:30 AM – 8:00 PM (Exam weeks till 10:00 PM)',
    description: 'Automated 2-floor knowledge center with 40,500+ volumes, KOHA LMS, Knimbus digital portals, quiet reading halls, and IEEE e-journal terminals.',
    directions: 'From Block A, take the right walkway past the fountain plaza. The Central Library entrance is framed by floor-to-ceiling glass arches.',
    landmarks: 'RFID Checkout Kiosk, Digital Reference Section, Periodicals Gallery',
    aiQuery: 'Where is the Dr. APJ Abdul Kalam Central Library located?'
  },
  {
    id: 'cafeteria',
    name: 'Central Cafeteria & Food Court',
    shortName: 'Cafeteria & CCD',
    category: 'Dining',
    block: 'Student Amenities Pavilion',
    floor: 'Ground Floor',
    icon: Coffee,
    color: '#ea580c',
    coordinates: { x: 50, y: 38 },
    timings: 'Daily: 7:30 AM – 9:00 PM',
    description: 'Spacious multi-cuisine food pavilion serving North & South Indian meals, fresh fruit juice bar, bakery, Café Coffee Day (CCD), and Nescafe kiosk.',
    directions: 'Located right in the center of the campus behind the academic quadrangle, easily accessible from both Engineering Blocks and the Central Library.',
    landmarks: 'Covered outdoor garden seating, CCD counter, Nescafe express kiosk',
    aiQuery: 'Where is the cafeteria located on campus?'
  },
  {
    id: 'hostels',
    name: 'Student Hostels (Boys & Girls)',
    shortName: 'Student Hostels',
    category: 'Residence',
    block: 'Residential Zone (North Campus)',
    floor: 'Floors 1 to 6',
    icon: HomeIcon,
    color: '#d97706',
    coordinates: { x: 25, y: 22 },
    timings: '24/7 Biometric Entry (Curfew: 8:30 PM)',
    description: 'Separate furnished hostels for boys and girls with AC/non-AC 2/3 sharing rooms, attached washrooms, Wi-Fi, 4-meal mess, and indoor recreation.',
    directions: 'From the Cafeteria, proceed north along the tree-lined residential driveway for 150 meters. Boys hostels are to the left, Girls hostels to the right.',
    landmarks: 'Hostel Dining Hall, Biometric Turnstiles, Warden Office, Laundry Room',
    aiQuery: 'What hostel facilities and fees are offered?'
  },
  {
    id: 'labs-workshop',
    name: 'Advanced Robotics & Mechanical Workshop',
    shortName: 'Robotics Labs',
    category: 'Laboratories',
    block: 'Heavy Engineering Complex',
    floor: 'Ground Floor',
    icon: Cpu,
    color: '#7c3aed',
    coordinates: { x: 75, y: 25 },
    timings: 'Monday – Saturday: 9:00 AM – 5:00 PM',
    description: 'Hands-on engineering workshops housing CNC machines, industrial robotics arms, 3D printing suites, and materials testing rigs.',
    directions: 'Located in the northeast corner of the campus behind the Central Library. Follow the Workshop Avenue signs from the library exit.',
    landmarks: '3D Prototyping Centre, CNC Machine Shop, Automotive Simulation Bay',
    aiQuery: 'Where are the robotics and engineering workshops located?'
  },
  {
    id: 'sports-arena',
    name: 'Sports Arena & Gymnasium',
    shortName: 'Sports Complex',
    category: 'Sports & Wellness',
    block: 'Athletics Zone (West Campus)',
    floor: 'Ground & Mezzanine',
    icon: Activity,
    color: '#10b981',
    coordinates: { x: 20, y: 65 },
    timings: 'Daily: 6:00 AM – 8:30 AM & 4:30 PM – 8:00 PM',
    description: 'Full-size cricket ground with turf nets, FIFA-standard football pitch, floodlit basketball and tennis courts, modern gym, and badminton halls.',
    directions: 'From Main Gate, turn immediately left onto the sports promenade before reaching Block A. The sports pavilions are clearly visible.',
    landmarks: 'Cricket Pavilion, Synthetic Basketball Courts, Student Fitness Gym',
    aiQuery: 'What sports and gym facilities are available on campus?'
  },
  {
    id: 'health-atm',
    name: 'Health Care Centre & Bank of Baroda ATM',
    shortName: 'Clinic & ATM',
    category: 'Amenities',
    block: 'Student Convenience Centre',
    floor: 'Ground Floor',
    icon: Heart,
    color: '#e11d48',
    coordinates: { x: 78, y: 70 },
    timings: 'Health Centre: 24/7 • ATM: 24/7 Banking',
    description: '24/7 on-campus medical clinic with resident doctors, nursing staff, emergency observation beds, ambulance, and Bank of Baroda ATM kiosk.',
    directions: 'Located on the right side of Block A, adjacent to the visitor parking zone and primary student convenience store.',
    landmarks: 'Stationed Emergency Ambulance, Bank of Baroda 24/7 Cash Machine',
    aiQuery: 'Where is the medical clinic and ATM on campus?'
  },
  {
    id: 'bus-parking',
    name: '50+ Commuter Bus Bays & Visitor Parking',
    shortName: 'Bus Bay & Parking',
    category: 'Entry & Transit',
    block: 'Transit Terminal',
    floor: 'Ground Level',
    icon: Bus,
    color: '#0d9488',
    coordinates: { x: 50, y: 95 },
    timings: 'Daily: 6:30 AM – 8:00 PM',
    description: 'Dedicated transportation terminal accommodating over 50 GPS-enabled air-conditioned university commuter buses, two-wheeler and four-wheeler visitor lots.',
    directions: 'Located immediately inside Gate 2, just 50 meters south of the Main Security Gate. Visitor passes are issued here.',
    landmarks: 'Bus Route Board, Transportation Office, Visitor Vehicle Shelter',
    aiQuery: 'Where is the university bus parking and pickup point?'
  }
];

export default function CampusMapModal({ isOpen, onClose, onAskAI, initialWaypointId = null }) {
  const [selectedWaypoint, setSelectedWaypoint] = useState(CAMPUS_WAYPOINTS[1]); // Default to Block A
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('map'); // 'map' or 'list'

  const categories = ['All', 'Academic', 'Administration', 'Dining', 'Residence', 'Laboratories', 'Sports & Wellness', 'Entry & Transit', 'Amenities'];

  useEffect(() => {
    if (initialWaypointId) {
      const found = CAMPUS_WAYPOINTS.find(w => w.id === initialWaypointId);
      if (found) setSelectedWaypoint(found);
    }
  }, [initialWaypointId, isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredWaypoints = CAMPUS_WAYPOINTS.filter(wp => {
    const matchesCategory = activeCategory === 'All' || wp.category === activeCategory;
    const matchesSearch = !searchQuery.trim() || 
      wp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wp.shortName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wp.block.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wp.landmarks.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="map-modal-title"
    >
      <div 
        className="w-full max-w-6xl h-[92vh] max-h-[850px] bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden transition-colors duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-slate-50 via-white to-blue-50/40 dark:from-slate-900 dark:via-slate-900 dark:to-blue-950/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md flex-shrink-0">
              <Compass className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="map-modal-title" className="text-base sm:text-lg font-bold text-slate-900 dark:text-white font-serif">
                  Presidency University Campus Navigator
                </h2>
                <span className="hidden sm:inline-block text-[10px] font-bold text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-900/60 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-800">
                  65+ Acres • Rajanakunte
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Interactive waypoints, floor directions, and walking guide
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            {/* Direct Google Maps Navigation Link */}
            <a
              href="https://maps.app.goo.gl/YKo4kaj7VsPtktNh7"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/50 hover:bg-blue-100 dark:hover:bg-blue-900 rounded-xl border border-blue-200 dark:border-blue-800 transition cursor-pointer"
              title="Open verified location in Google Maps"
            >
              <Navigation className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Google Maps</span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </a>

            {/* Mobile View Toggle */}
            <div className="flex sm:hidden border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden p-0.5 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => setViewMode('map')}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition ${
                  viewMode === 'map' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-xs' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Map
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition ${
                  viewMode === 'list' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-xs' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                List
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              aria-label="Close campus map"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Bar & Search */}
        <div className="p-3 sm:px-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`text-xs px-3 py-1.5 rounded-full font-medium whitespace-nowrap transition cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search cafeteria, library, labs..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 dark:focus:border-blue-400"
            />
          </div>
        </div>

        {/* Modal Main Body (Map + Inspection Panel) */}
        <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
          
          {/* Left/Main Column: Visual Schematic Interactive Map */}
          <div className={`flex-1 relative bg-slate-900 dark:bg-slate-950 p-3 sm:p-5 overflow-auto flex items-center justify-center ${viewMode === 'list' ? 'hidden sm:flex' : 'flex'}`}>
            
            {/* SVG Schematic Blueprint */}
            <div className="relative w-full max-w-[700px] aspect-[4/3] rounded-2xl overflow-hidden border border-slate-800 bg-[#071322] shadow-inner select-none">
              
              {/* Background Campus Grid & Landscaping */}
              <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                  <pattern id="campus-grid" width="10" height="10" patternUnits="userSpaceOnUse">
                    <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#132642" strokeWidth="0.3" />
                  </pattern>
                  <linearGradient id="lawn-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#082b20" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#06382b" stopOpacity="0.6" />
                  </linearGradient>
                </defs>

                {/* Grid */}
                <rect width="100" height="100" fill="url(#campus-grid)" />

                {/* Campus Boundary Fence */}
                <rect x="5" y="8" width="90" height="88" rx="4" fill="none" stroke="#1e3a5f" strokeWidth="0.8" strokeDasharray="1.5,1" />

                {/* Green Lawns */}
                <rect x="10" y="55" width="22" height="28" rx="2" fill="url(#lawn-grad)" stroke="#10b981" strokeWidth="0.4" />
                <rect x="15" y="15" width="22" height="22" rx="2" fill="url(#lawn-grad)" stroke="#10b981" strokeWidth="0.4" />
                <rect x="65" y="60" width="22" height="22" rx="2" fill="url(#lawn-grad)" stroke="#10b981" strokeWidth="0.4" />
                <circle cx="50" cy="52" r="6" fill="#0c2340" stroke="#2563eb" strokeWidth="0.5" />

                {/* Main Avenues / Walking Pathways */}
                <path d="M 50 96 L 50 40 M 15 52 L 85 52 M 50 40 L 25 22 M 50 40 L 75 25 M 20 65 L 50 65 M 78 70 L 50 70" 
                      fill="none" stroke="#2a4d75" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M 50 96 L 50 40 M 15 52 L 85 52" fill="none" stroke="#38bdf8" strokeWidth="0.6" strokeDasharray="1.5,1.5" />

                {/* Buildings Geometry */}
                {/* Block A Admin */}
                <rect x="42" y="64" width="16" height="10" rx="1.5" fill="#133660" stroke="#38bdf8" strokeWidth="0.8" />
                <text x="50" y="70" fill="#bae6fd" fontSize="2.8" fontWeight="bold" textAnchor="middle">BLOCK A</text>

                {/* Blocks B & C Engineering */}
                <rect x="23" y="46" width="18" height="12" rx="1.5" fill="#1d2d5a" stroke="#818cf8" strokeWidth="0.8" />
                <text x="32" y="53" fill="#c7d2fe" fontSize="2.6" fontWeight="bold" textAnchor="middle">BLOCK B & C</text>

                {/* Central Library */}
                <rect x="59" y="46" width="18" height="12" rx="1.5" fill="#064e3b" stroke="#34d399" strokeWidth="0.8" />
                <text x="68" y="53" fill="#a7f3d0" fontSize="2.6" fontWeight="bold" textAnchor="middle">LIBRARY</text>

                {/* Cafeteria */}
                <rect x="42" y="33" width="16" height="10" rx="1.5" fill="#7c2d12" stroke="#fb923c" strokeWidth="0.8" />
                <text x="50" y="39" fill="#fed7aa" fontSize="2.5" fontWeight="bold" textAnchor="middle">CAFETERIA</text>

                {/* Hostels */}
                <rect x="16" y="16" width="18" height="12" rx="1.5" fill="#78350f" stroke="#fbbf24" strokeWidth="0.8" />
                <text x="25" y="23" fill="#fde68a" fontSize="2.5" fontWeight="bold" textAnchor="middle">HOSTELS</text>

                {/* Robotics Labs */}
                <rect x="66" y="19" width="18" height="12" rx="1.5" fill="#4c1d95" stroke="#a78bfa" strokeWidth="0.8" />
                <text x="75" y="26" fill="#ddd6fe" fontSize="2.5" fontWeight="bold" textAnchor="middle">TECH LABS</text>

                {/* Main Gate */}
                <rect x="44" y="86" width="12" height="5" rx="1" fill="#1e3a5f" stroke="#60a5fa" strokeWidth="0.8" />
                <text x="50" y="89.5" fill="#e0f2fe" fontSize="2" fontWeight="bold" textAnchor="middle">MAIN GATE</text>
              </svg>

              {/* Interactive Pulsing Map Pin Waypoints */}
              {CAMPUS_WAYPOINTS.map((wp) => {
                const isSelected = selectedWaypoint?.id === wp.id;
                const Icon = wp.icon;
                return (
                  <button
                    key={wp.id}
                    onClick={() => setSelectedWaypoint(wp)}
                    style={{ left: `${wp.coordinates.x}%`, top: `${wp.coordinates.y}%` }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer focus:outline-none transition-transform duration-200 z-10 ${
                      isSelected ? 'scale-125 z-30' : 'hover:scale-115'
                    }`}
                    title={wp.name}
                  >
                    {/* Pulsing ring around selected pin */}
                    {isSelected && (
                      <span 
                        className="absolute inset-0 rounded-full animate-ping opacity-75"
                        style={{ backgroundColor: wp.color }}
                      />
                    )}
                    
                    {/* Pin Circle */}
                    <div 
                      className={`relative w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white shadow-lg border-2 transition-all ${
                        isSelected 
                          ? 'border-white ring-4 ring-white/30 shadow-2xl' 
                          : 'border-white/80 hover:border-white shadow-md'
                      }`}
                      style={{ backgroundColor: wp.color }}
                    >
                      <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>

                    {/* Small Label Pill */}
                    <span className={`absolute top-full mt-1 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 rounded shadow-md pointer-events-none transition-all ${
                      isSelected 
                        ? 'bg-white text-slate-900 shadow-lg scale-105' 
                        : 'bg-slate-900/90 text-slate-200 opacity-90 group-hover:opacity-100'
                    }`}>
                      {wp.shortName}
                    </span>
                  </button>
                );
              })}

              {/* Legend Watermark */}
              <div className="absolute top-2 left-2 pointer-events-none bg-slate-950/70 backdrop-blur-xs px-2 py-1 rounded text-[10px] text-slate-400 font-mono">
                Presidency University Campus Grid • Click any pin to inspect
              </div>
            </div>
          </div>

          {/* Right Column: Waypoint Inspection Card & Directory */}
          <div className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col overflow-hidden">
            
            {/* Active Waypoint Details Card */}
            {selectedWaypoint && (
              <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/80 space-y-3.5 overflow-y-auto max-h-[300px] sm:max-h-none flex-shrink-0">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div 
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-md flex-shrink-0"
                      style={{ backgroundColor: selectedWaypoint.color }}
                    >
                      <selectedWaypoint.icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                        {selectedWaypoint.category}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                        {selectedWaypoint.name}
                      </h3>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700">
                    <div className="text-[10px] text-slate-400 font-medium">Location</div>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{selectedWaypoint.block}</div>
                  </div>
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700">
                    <div className="text-[10px] text-slate-400 font-medium">Floor Level</div>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{selectedWaypoint.floor}</div>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-semibold">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-[11px]">{selectedWaypoint.timings}</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {selectedWaypoint.description}
                  </p>
                </div>

                {/* Walking Directions from Main Gate */}
                <div className="p-2.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200/70 dark:border-blue-900/60 text-xs space-y-1">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-blue-800 dark:text-blue-300">
                    <Navigation className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                    <span>How to Reach from Main Gate:</span>
                  </div>
                  <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                    {selectedWaypoint.directions}
                  </p>
                </div>

                {/* Action: Ask AI about this place */}
                <button
                  onClick={() => {
                    onClose();
                    onAskAI(selectedWaypoint.aiQuery);
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-[#163e72] hover:from-blue-500 hover:to-blue-700 text-white font-bold text-xs transition shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Ask FAQ Chatbot About {selectedWaypoint.shortName}</span>
                </button>
              </div>
            )}

            {/* Waypoint Fast Directory List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                All Campus Landmarks ({filteredWaypoints.length})
              </div>
              {filteredWaypoints.map((wp) => {
                const isSelected = selectedWaypoint?.id === wp.id;
                const Icon = wp.icon;
                return (
                  <button
                    key={wp.id}
                    onClick={() => setSelectedWaypoint(wp)}
                    className={`w-full text-left p-2.5 rounded-xl transition flex items-center justify-between text-xs cursor-pointer ${
                      isSelected 
                        ? 'bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200 font-bold' 
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div 
                        className="w-6 h-6 rounded-lg flex items-center justify-center text-white text-[10px] flex-shrink-0"
                        style={{ backgroundColor: wp.color }}
                      >
                        <Icon className="w-3 h-3" />
                      </div>
                      <div className="truncate">
                        <div className="truncate font-medium">{wp.name}</div>
                        <div className="text-[10px] text-slate-400 truncate">{wp.block} • {wp.floor}</div>
                      </div>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0 ml-1" />
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer Note */}
        <div className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 text-[11px] text-slate-500 dark:text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-1">
          <div className="flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-blue-500" />
            <span>Presidency University Bengaluru • Itgalpur, Rajanakunte, Yelahanka – 560064</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Verified Coordinates</span>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <a 
              href="https://presidencyuniversity.in/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5"
            >
              <span>Official Portal</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
