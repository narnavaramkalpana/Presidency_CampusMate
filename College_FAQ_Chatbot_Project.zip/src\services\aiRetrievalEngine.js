// AI Retrieval Engine for CampusMate AI
// Presidency University Bengaluru
import { universityDatabase, categories, universityMetadata } from '../data/universityDatabase.js';

// Comprehensive domain-specific synonym dictionary
const SYNONYMS = {
  // Fees and finance
  fee: ['fees', 'fess', 'feee', 'tuition', 'cost', 'charge', 'charges', 'price', 'pricing', 'expense', 'expenses', 'payment', 'installment', 'package', 'structure'],
  fees: ['fee', 'fess', 'feee', 'tuition', 'cost', 'charges', 'price', 'pricing', 'expense', 'expenses', 'payment', 'package', 'structure'],
  fess: ['fee', 'fees', 'tuition', 'cost', 'fee structure'],
  tuition: ['fee', 'fees', 'cost'],
  cost: ['fee', 'fees', 'charges', 'tuition'],
  scholarship: ['scholarships', 'waiver', 'concession', 'discount', 'financial aid', 'merit award', 'stipend'],
  scholarships: ['scholarship', 'waiver', 'waivers', 'concessions', 'discounts', 'financial aid'],
  
  // Accommodation & Living
  hostel: ['hostels', 'accommodation', 'dorm', 'dormitory', 'residence', 'housing', 'stay', 'room', 'rooms', 'living', 'mess', 'boarding'],
  hostels: ['hostel', 'accommodation', 'dorm', 'residence', 'housing', 'rooms', 'stay', 'mess'],
  // Food, Dining & Cafeteria
  cafeteria: ['canteen', 'food court', 'cafe', 'mess', 'dining', 'ccd', 'snacks', 'food', 'restaurant', 'coffee day', 'nescafe'],
  canteen: ['cafeteria', 'food court', 'mess', 'dining', 'snacks', 'food'],
  food: ['mess', 'dining', 'canteen', 'cafeteria', 'meal', 'meals', 'lunch', 'breakfast', 'dinner', 'snacks', 'ccd', 'food court'],
  mess: ['food', 'dining', 'hostel mess', 'meals', 'cafeteria', 'canteen'],

  // Robotics & Mechatronics
  robotics: ['robot', 'robots', 'mechatronics', 'automation', 'embedded', 'autonomous', 'drone', 'ai robotics', 'btech mechatronics'],
  mechatronics: ['robotics', 'automation', 'mechanical robotics', 'sensors', 'actuators', 'btech mechatronics'],
  robot: ['robotics', 'mechatronics', 'automation'],
  
  // Programs & Degrees
  course: ['courses', 'program', 'programs', 'degree', 'degrees', 'branch', 'branches', 'specialization', 'specializations', 'curriculum', 'study'],
  courses: ['course', 'program', 'programs', 'degrees', 'branches', 'specializations', 'study'],
  engineering: ['btech', 'b.tech', 'be', 'b.e', 'tech', 'engineer'],
  btech: ['engineering', 'b.tech', 'be', 'b.e', 'tech', 'bachelor of technology'],
  cse: ['computer science', 'computer science and engineering', 'cs', 'software', 'programming', 'computing', 'it', 'cse core', 'cse devops', 'devops'],
  devops: ['dev-ops', 'dev ops', 'cloud devops', 'cloud and devops', 'ci cd', 'infrastructure as code', 'kubernetes', 'docker', 'cse devops'],
  core: ['cse core', 'core cse', 'computer science core', 'general cse', 'core branch'],
  mba: ['management', 'business administration', 'master of business administration', 'pgdm', 'business school'],
  bba: ['bachelor of business administration', 'business management', 'undergraduate management'],
  law: ['llb', 'll.b', 'ba llb', 'bba llb', 'bcom llb', 'llm', 'advocate', 'legal', 'lawyer', 'bci'],
  design: ['bdes', 'b.des', 'fashion design', 'product design', 'game design', 'interior design'],
  bca: ['bachelor of computer applications', 'computer applications', 'coding', 'it degree'],
  mca: ['master of computer applications', 'pg computer applications'],
  
  // Admissions & Eligibility
  admission: ['admissions', 'apply', 'applying', 'application', 'enroll', 'enrollment', 'join', 'registration', 'register', 'seat'],
  admissions: ['admission', 'apply', 'application', 'enrollment', 'registration', 'seats'],
  apply: ['admission', 'application', 'register', 'registration', 'enroll'],
  eligibility: ['eligible', 'criteria', 'requirement', 'requirements', 'cutoff', 'cut-off', 'qualification', 'marks', 'percentage'],
  eligible: ['eligibility', 'criteria', 'requirements', 'qualification', 'marks'],
  entrance: ['exam', 'test', 'entrance exam', 'kcet', 'comedk', 'jee', 'jee main', 'pgcet', 'cat', 'mat', 'clat', 'pulat', 'dat'],
  
  // Jobs & Internships
  placement: ['placements', 'job', 'jobs', 'career', 'careers', 'recruitment', 'recruiter', 'recruiters', 'package', 'ctc', 'salary', 'hiring', 'companies'],
  placements: ['placement', 'job', 'jobs', 'careers', 'packages', 'salary', 'recruitment', 'companies', 'hiring'],
  package: ['packages', 'salary', 'ctc', 'highest package', 'average package', 'pay', 'lpa'],
  packages: ['package', 'salary', 'ctc', 'lpa'],
  highest: ['top', 'maximum', 'peak'],
  salary: ['package', 'ctc', 'highest package', 'average package', 'pay', 'income', 'stipend'],
  internship: ['internships', 'industrial training', 'intern', 'summer internship', 'ppo', 'stipend'],
  
  // Transport
  transport: ['transportation', 'bus', 'buses', 'shuttle', 'route', 'routes', 'commute', 'pickup', 'travel', 'bus pass'],
  transportation: ['transport', 'bus', 'buses', 'shuttle', 'routes'],
  bus: ['buses', 'transport', 'transportation', 'shuttle', 'routes', 'bus route'],
  buses: ['bus', 'transport', 'transportation', 'routes'],
  
  // Facilities & Campus
  facility: ['facilities', 'infrastructure', 'amenities', 'campus', 'labs', 'library', 'sports', 'gym', 'auditorium'],
  facilities: ['facility', 'infrastructure', 'amenities', 'campus'],
  library: ['books', 'koha', 'knimbus', 'reading room', 'e-books', 'journals', 'digital library'],
  lab: ['labs', 'laboratories', 'laboratory', 'workshop', 'mac lab', 'ai lab', 'gpu', 'workstations'],
  sports: ['games', 'cricket', 'football', 'basketball', 'badminton', 'tennis', 'gym', 'athletics', 'kreedotsava', 'fitness'],
  gym: ['gymnasium', 'fitness', 'workout', 'weights', 'trainers'],
  
  // Fests & Clubs
  fest: ['fests', 'events', 'festival', 'invincia', 'cultural', 'celebration', 'hackathon', 'pro-nite', 'concert'],
  invincia: ['fest', 'cultural fest', 'annual fest', 'concert', 'college festival'],
  club: ['clubs', 'societies', 'student clubs', 'rotaract', 'ncc', 'nss', 'acm', 'ieee', 'dsa'],
  clubs: ['club', 'societies', 'student clubs'],
  
  // Location, Navigation & Contact
  location: ['located', 'where', 'place', 'situated', 'reach', 'direction', 'directions', 'distance', 'map', 'maps', 'building', 'block', 'floor', 'navigation', 'guide', 'route', 'spot', 'itgalpur', 'rajanakunte', 'yelahanka'],
  located: ['location', 'where', 'place', 'situated', 'building', 'block', 'floor', 'directions', 'map'],
  where: ['location', 'located', 'place', 'situated', 'reach', 'find', 'directions', 'map', 'navigation', 'guide'],
  directions: ['direction', 'route', 'reach', 'how to reach', 'location', 'where', 'map', 'maps', 'navigation', 'guide', 'way'],
  direction: ['directions', 'route', 'reach', 'location', 'where', 'map', 'navigation', 'guide'],
  route: ['directions', 'reach', 'way', 'map', 'navigation', 'guide'],
  reach: ['directions', 'how to reach', 'location', 'route', 'way', 'map'],
  map: ['maps', 'google maps', 'directions', 'location', 'navigation', 'gps', 'route'],
  maps: ['map', 'google maps', 'directions', 'location', 'navigation', 'gps'],
  contact: ['phone', 'mobile', 'call', 'number', 'helpline', 'email', 'mail', 'reach out', 'office', 'inquiry', 'enquiry'],
  timing: ['timings', 'hours', 'working hours', 'opening time', 'closing time', 'schedule'],
  document: ['documents', 'certificates', 'marksheet', 'checklist', 'tc', 'migration'],
  documents: ['document', 'certificates', 'marks card', 'checklist', 'tc']
};

// Common English stopwords and conversational fillers to ignore in scoring (notice 'where' is omitted so location queries are detected)
const STOPWORDS = new Set([
  'a', 'about', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'can', 'for', 'from',
  'how', 'in', 'is', 'it', 'of', 'on', 'or', 'that', 'the', 'this', 'to', 'was',
  'what', 'when', 'which', 'who', 'will', 'with', 'do', 'does', 'did',
  'i', 'im', 'am', 'me', 'my', 'you', 'your', 'so', 'need', 'take', 'want', 'like',
  'should', 'would', 'could', 'tell', 'suggest', 'recommend', 'help', 'give', 'know',
  'please', 'available', 'presidency', 'university'
]);

// Basic Levenshtein distance for typo tolerance
function levenshteinDistance(s1, s2) {
  if (s1 === s2) return 0;
  if (!s1.length) return s2.length;
  if (!s2.length) return s1.length;

  const dp = Array.from({ length: s1.length + 1 }, () => 
    new Array(s2.length + 1).fill(0)
  );

  for (let i = 0; i <= s1.length; i++) dp[i][0] = i;
  for (let j = 0; j <= s2.length; j++) dp[0][j] = j;

  for (let i = 1; i <= s1.length; i++) {
    for (let j = 1; j <= s2.length; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }

  return dp[s1.length][s2.length];
}

// Check if two tokens are fuzzy matches
function isFuzzyMatch(t1, t2) {
  if (t1 === t2) return true;
  if (t1.length < 4 || t2.length < 4) return false;
  if (Math.abs(t1.length - t2.length) > 2) return false;
  return levenshteinDistance(t1, t2) <= 1;
}

// Tokenize and clean text with domain normalization & typo corrections
export function tokenize(text) {
  if (!text) return [];
  const rawTokens = text
    .toLowerCase()
    .replace(/b\.tech/g, 'btech')
    .replace(/m\.tech/g, 'mtech')
    .replace(/c\.s\.e/g, 'cse')
    .replace(/b\.des/g, 'bdes')
    .replace(/\bfess\b/g, 'fees')
    .replace(/\bfeee\b/g, 'fees')
    .replace(/\bfe\b/g, 'fee')
    .replace(/\bhostle\b/g, 'hostel')
    .replace(/\bhostell\b/g, 'hostel')
    .replace(/\badmision\b/g, 'admission')
    .replace(/\baddmission\b/g, 'admission')
    .replace(/\badmisison\b/g, 'admission')
    .replace(/\bplacment\b/g, 'placement')
    .replace(/\bcurse\b/g, 'course')
    .replace(/\bcources\b/g, 'courses')
    .replace(/\bsource\b/g, 'course')
    .replace(/\bwhic\b/g, 'which')
    .replace(/\bwich\b/g, 'which')
    .replace(/\bintrested\b/g, 'interested')
    .replace(/\bintrest\b/g, 'interest')
    .replace(/\bloaction\b/g, 'location')
    .replace(/\bloactions\b/g, 'location')
    .replace(/\blocationn\b/g, 'location')
    .replace(/\bcafetria\b/g, 'cafeteria')
    .replace(/\bcafteria\b/g, 'cafeteria')
    .replace(/\bcafteriaa\b/g, 'cafeteria')
    .replace(/\bcafeteriya\b/g, 'cafeteria')
    .replace(/\bcanteenn\b/g, 'canteen')
    .replace(/\bdirecton\b/g, 'direction')
    .replace(/\bdirectons\b/g, 'directions')
    .replace(/\bdiretion\b/g, 'direction')
    .replace(/\bdiretions\b/g, 'directions')
    .replace(/\bnavagation\b/g, 'navigation')
    .replace(/\brobotix\b/g, 'robotics')
    .replace(/\brobotic\b/g, 'robotics')
    .replace(/\bmechatronic\b/g, 'mechatronics')
    .replace(/\bvisiter\b/g, 'visitor')
    .replace(/\bcor\b/g, 'for')
    .replace(/\bcask\b/g, 'ask')
    .replace(/\bdevops\b/g, 'devops')
    .replace(/\bdev-ops\b/g, 'devops')
    .replace(/\bdev\s+ops\b/g, 'devops')
    .replace(/\bdev\s+op\b/g, 'devops')
    .replace(/\bspecialisation\b/g, 'specialization')
    .replace(/\bspecialisations\b/g, 'specializations')
    .replace(/\bspecilization\b/g, 'specialization')
    .replace(/\bspecilizations\b/g, 'specializations')
    .replace(/\bscolorship\b/g, 'scholarship')
    .replace(/\bpresidancy\b/g, 'presidency')
    .replace(/\bpresidenci\b/g, 'presidency')
    .replace(/\bpresidencyy\b/g, 'presidency')
    .replace(/\bunivercity\b/g, 'university')
    .replace(/\bunversity\b/g, 'university')
    .replace(/\buniv\b/g, 'university')
    .replace(/\bclg\b/g, 'college')
    .replace(/\bcolg\b/g, 'college')
    .replace(/\bsubjcet\b/g, 'subject')
    .replace(/\bsubjets\b/g, 'subjects')
    .replace(/\bexam\b/g, 'examination')
    .replace(/\bexm\b/g, 'examination')
    .replace(/\bexmination\b/g, 'examination')
    .replace(/\bacademcs\b/g, 'academics')
    .replace(/\bacedemics\b/g, 'academics')
    .replace(/\btransportaion\b/g, 'transport')
    .replace(/\btrnsport\b/g, 'transport')
    .replace(/\beligiblity\b/g, 'eligibility')
    .replace(/\beligibilty\b/g, 'eligibility')
    .replace(/\belgibility\b/g, 'eligibility')
    .replace(/\bpalcements\b/g, 'placements')
    .replace(/\bpalcement\b/g, 'placement')
    .replace(/\bplacments\b/g, 'placements')
    .replace(/\bplacment\b/g, 'placement')
    .replace(/\bplacemnt\b/g, 'placement')
    .replace(/\bpckg\b/g, 'package')
    .replace(/\bpakage\b/g, 'package')
    .replace(/\bsalry\b/g, 'salary')
    .replace(/\bcantin\b/g, 'canteen')
    .replace(/\bfee\s+structure\b/g, 'fees')
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 0);

  const filtered = rawTokens.filter(t => t.length > 1 && !STOPWORDS.has(t));
  if (filtered.length === 0 && rawTokens.length > 0) {
    return rawTokens.filter(t => t.length > 1);
  }
  return filtered;
}

// Expand a set of tokens with their synonyms
export function expandTokensWithSynonyms(tokens) {
  const expanded = new Set(tokens);
  for (const token of tokens) {
    if (SYNONYMS[token]) {
      for (const syn of SYNONYMS[token]) {
        for (const subToken of syn.split(' ')) {
          if (!STOPWORDS.has(subToken) && subToken.length > 1) {
            expanded.add(subToken);
          }
        }
      }
    }
  }
  return Array.from(expanded);
}

/**
 * Intelligent Retrieval Engine
 * @param {string} userQuery - The input query from user
 * @param {object} options - Retrieval options (context, category, etc.)
 */
export function retrieveAnswer(userQuery, options = {}) {
  const query = (userQuery || '').trim();
  if (!query) {
    return {
      status: 'empty',
      answer: "Please ask a question about Presidency University admissions, courses, fees, hostels, placements, or campus life.",
      confidence: 0,
      matchedEntry: null,
      relatedQuestions: getPopularSuggestedQuestions().slice(0, 4)
    };
  }

  const queryClean = query.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 1: Greetings
  // -------------------------------------------------------------
  const GREETING_EXACT = new Set([
    'hi', 'hello', 'hey', 'hiya', 'hola', 'namaste', 'namaskar',
    'good morning', 'good afternoon', 'good evening', 'greetings',
    'wassup', 'yo', 'heya', 'morning', 'afternoon', 'evening',
    'hii', 'hiii', 'heyy', 'heyyy', 'hai', 'helloo'
  ]);
  const isGreeting = GREETING_EXACT.has(queryClean) || 
    /^(hi|hello|hey|hiya|hola|namaste|good\s+(morning|afternoon|evening)|greetings|yo)\b/.test(queryClean);

  if (isGreeting) {
    return {
      status: 'greeting',
      answer: "Hi! 👋 How can I help you today?\n\nAsk me anything about admissions, courses, fee structures, hostels, or campus directions at Presidency University.",
      confidence: 1.0,
      matchedEntry: { id: 'greeting', question: 'Greeting', category: 'General' },
      category: 'General',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Official Portal',
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: [
        "What is the fee for B.Tech CSE DevOps?",
        "Where is the cafeteria located?",
        "What was the highest placement package?"
      ]
    };
  }

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 2: Project Authors, Creators & Identity
  // -------------------------------------------------------------
  const isIdentity = (
    queryClean === 'who are you' ||
    queryClean === 'what can you do' ||
    queryClean === 'who made you' ||
    queryClean === 'who created you' ||
    queryClean === 'who developed you' ||
    queryClean === 'what is this' ||
    queryClean === 'about you' ||
    queryClean === 'tell me about yourself' ||
    queryClean.includes('creators') ||
    queryClean.includes('authors') ||
    queryClean.includes('presenters') ||
    queryClean.includes('developers') ||
    queryClean.includes('roll number') ||
    queryClean.includes('roll no') ||
    queryClean.includes('kalpana') ||
    queryClean.includes('poornima') ||
    queryClean.includes('20241cdv0043') ||
    queryClean.includes('20241cdv0045') ||
    queryClean.includes('cdv3400') ||
    queryClean.includes('cloud computing ca') ||
    queryClean.includes('project details') ||
    queryClean.includes('topic 23')
  );

  if (isIdentity) {
    return {
      status: 'identity',
      answer: "I am the **College FAQ Chatbot**, developed for **Presidency University, Bengaluru** as part of the **CDV3400 Cloud Computing CA-3** project on **Building a FAQ Chatbot for a College Website**.\n\n**Project Authors & Presenters:**\n• **N Kalpana** — Roll Number: **20241cdv0043**\n• **Poornima L** — Roll Number: **20241cdv0045**\n\n**Key System Capabilities:**\n• **265-Record Knowledge Base**: Approved, verified college data across courses, admissions, fees, hostels, and placements.\n• **Intent-Based Retrieval**: Handles typos, spelling mistakes, fuzzy matching, and context follow-ups.\n• **Zero Hallucination Guardrails**: Safe fallback responses with direct university helpline references.\n• **Campus Navigation**: Integrated interactive map with waypoints and floor directions.\n• **Voice Support**: Speech-to-Text query input and Text-to-Speech audio narration.\n\nFeel free to ask any question to test my responses!",
      confidence: 1.0,
      matchedEntry: { id: 'identity', question: 'Chatbot Identity & Project Details', category: 'Project Overview' },
      category: 'Project Overview',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Cloud Computing Project',
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: [
        "What is the fee structure across courses?",
        "What is the eligibility for B.Tech CSE?",
        "Where is the cafeteria located on campus?",
        "What was the highest placement package?"
      ]
    };
  }

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 3: University Overview & About Presidency
  // -------------------------------------------------------------
  const isOverview = (
    queryClean === 'about university' ||
    queryClean === 'tell me about university' ||
    queryClean === 'about presidency university' ||
    queryClean === 'about presidency' ||
    queryClean === 'tell me about presidency' ||
    queryClean === 'tell me about presidency university' ||
    queryClean === 'what is presidency university' ||
    queryClean === 'overview' ||
    queryClean === 'university overview' ||
    queryClean === 'why presidency' ||
    queryClean === 'why choose presidency university' ||
    queryClean === 'why choose presidency' ||
    queryClean === 'about college' ||
    queryClean === 'tell me about college' ||
    queryClean === 'about this college'
  );

  if (isOverview) {
    return {
      status: 'overview',
      answer: "**Presidency University, Bengaluru** is a premier private university established in Karnataka by the Presidency Group of Institutions under the Presidency University Act, 2013 (Karnataka Act No. 41 of 2013).\n\n**Key Institutional Highlights:**\n• **Approvals & Recognition**: Recognized by the UGC under Section 2(f), approved by AICTE, member of the Association of Indian Universities (AIU), and Bar Council of India (BCI) approved for Law.\n• **Sprawling 65+ Acre Campus**: Located at Itgalpur, Rajanakunte, Yelahanka, North Bengaluru with modern academic blocks, advanced research labs, and expansive sports complexes.\n• **Academic Programs**: Offers programs across Engineering (B.Tech CSE Core, DevOps, AI&ML, Cyber Security), Management (MBA, BBA), Law (BA.LL.B, BBA.LL.B, LL.M), Design (B.Des), and Computer Applications (BCA, MCA).\n• **Placements Record**: ₹13.58 LPA highest package, ₹5.21 LPA average package, and 550+ visiting recruiters including Fortune 500 tech companies.\n• **Student Facilities**: Air-conditioned Central Library (Koha/Knimbus), multi-cuisine food courts, AC/Non-AC student hostels, 85+ bus routes across Bengaluru, and on-campus healthcare with 24/7 ambulance.\n\nFor official inquiries, visit **https://presidencyuniversity.in/** or call the Admissions Helpline at **+91 90220 92222**.",
      confidence: 1.0,
      matchedEntry: universityDatabase[0],
      category: 'University overview',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Official Portal',
      lastVerifiedDate: universityMetadata.lastVerified,
      waypointId: 'main-gate',
      isCampusLocation: true,
      relatedQuestions: [
        "What is the fee structure across courses?",
        "What is the eligibility for B.Tech CSE?",
        "Where is the cafeteria located on campus?",
        "What was the highest placement package?"
      ]
    };
  }

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 4: Gratitude & Compliments
  // -------------------------------------------------------------
  const isGratitude = (
    queryClean === 'thanks' ||
    queryClean === 'thank you' ||
    queryClean === 'thx' ||
    queryClean === 'thank u' ||
    queryClean === 'thanks a lot' ||
    queryClean === 'thank you so much' ||
    queryClean === 'appreciate it' ||
    queryClean === 'great' ||
    queryClean === 'awesome' ||
    queryClean === 'super' ||
    queryClean === 'perfect' ||
    queryClean === 'nice' ||
    queryClean === 'good job' ||
    queryClean === 'well done'
  );

  if (isGratitude) {
    return {
      status: 'gratitude',
      answer: "You're very welcome! 😊 I am glad I could help you with verified college information.\n\nFeel free to ask if you need details about course fees, admissions, hostel accommodations, or campus directions. Best wishes for your academic journey!",
      confidence: 1.0,
      matchedEntry: { id: 'gratitude', question: 'Gratitude', category: 'General' },
      category: 'General',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Official Information',
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: [
        "What hostel facilities and fees are offered?",
        "What was the highest placement package?",
        "Where is the central library located?",
        "How can I apply online for admission?"
      ]
    };
  }

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 5: Acknowledgements
  // -------------------------------------------------------------
  const isAck = (
    queryClean === 'ok' ||
    queryClean === 'okay' ||
    queryClean === 'k' ||
    queryClean === 'kk' ||
    queryClean === 'got it' ||
    queryClean === 'understood' ||
    queryClean === 'noted' ||
    queryClean === 'sure' ||
    queryClean === 'alright' ||
    queryClean === 'fine' ||
    queryClean === 'cool' ||
    queryClean === 'sounds good'
  );

  if (isAck) {
    return {
      status: 'acknowledgement',
      answer: "Glad that helped! 👍\n\nFeel free to ask your next question, or choose from one of the popular topics below:",
      confidence: 1.0,
      matchedEntry: { id: 'ack', question: 'Acknowledgement', category: 'General' },
      category: 'General',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Official Information',
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: [
        "What is the fee structure for B.Tech CSE DevOps?",
        "What is the eligibility for B.Tech CSE?",
        "Where is the cafeteria located on campus?",
        "What was the highest placement package?"
      ]
    };
  }

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 6: Farewell
  // -------------------------------------------------------------
  const isFarewell = (
    queryClean === 'bye' ||
    queryClean === 'goodbye' ||
    queryClean === 'see you' ||
    queryClean === 'cya' ||
    queryClean === 'exit' ||
    queryClean === 'quit' ||
    queryClean === 'take care' ||
    queryClean === 'bye bye' ||
    queryClean === 'good night'
  );

  if (isFarewell) {
    return {
      status: 'farewell',
      answer: "Goodbye! 👋 Have a wonderful day!\n\nIf you have more questions later, you can reopen this chat, visit **https://presidencyuniversity.in/**, or contact the Admissions Helpline at **+91 90220 92222** / **080 4925 5555**. Best of luck!",
      confidence: 1.0,
      matchedEntry: { id: 'farewell', question: 'Farewell', category: 'General' },
      category: 'General',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Official Portal',
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: getPopularSuggestedQuestions().slice(0, 4)
    };
  }

  // -------------------------------------------------------------
  // CONVERSATIONAL INTENT 7: Help & Instructions
  // -------------------------------------------------------------
  const isHelp = (
    queryClean === 'help' ||
    queryClean === 'how to use' ||
    queryClean === 'what can i ask' ||
    queryClean === 'guide' ||
    queryClean === 'instructions' ||
    queryClean === 'commands'
  );

  if (isHelp) {
    return {
      status: 'help',
      answer: "Here is what you can ask the **College FAQ Chatbot**:\n\n1. **Course Inquiries & Fees**: Ask \"what is the fee structure for B.Tech CSE DevOps?\", \"MBA fees\", or \"BCA course details\".\n2. **Admissions & Eligibility**: Ask \"what is the eligibility for B.Tech CSE?\", \"entrance exams accepted\", or \"how to apply online\".\n3. **Placements & Internships**: Ask \"highest package\", \"average salary\", or \"which companies hire from Presidency\".\n4. **Campus Facilities & Navigation**: Ask \"where is the cafeteria located?\", \"library timings\", \"hostel fees\", or \"bus transport routes\".\n5. **Interactive Map**: Look for the **View on Interactive Campus Map** button on location answers to see exact coordinates and floor directions!\n6. **Voice Interaction**: Tap the **Microphone** button to speak your question or the **Listen** button on any answer to hear speech narration.\n\nTry asking any question in your own words!",
      confidence: 1.0,
      matchedEntry: { id: 'help', question: 'Chatbot Help Guide', category: 'General' },
      category: 'General',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: 'Presidency University Official Portal',
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: [
        "What is the fee structure for B.Tech CSE DevOps?",
        "What is the eligibility for B.Tech CSE?",
        "Where is the cafeteria located on campus?",
        "What was the highest placement package?"
      ]
    };
  }

  let queryTokens = tokenize(query);
  const contextTokens = options.lastTopic ? tokenize(options.lastTopic) : [];

  // Contextual Follow-up Detection & Entity Resolution:
  // If the query contains follow-up indicators ("its", "it", "this", "fees for this", "what about placements", "how to apply", "where is it", "directions to it", "tell me more"):
  const queryLower = query.toLowerCase();
  const isFollowUpQuery = (
    queryLower.startsWith('what about') ||
    queryLower.startsWith('how about') ||
    queryLower.includes(' its ') ||
    queryLower.endsWith(' its') ||
    queryLower.includes(' this ') ||
    queryLower.endsWith(' this') ||
    queryLower.includes('for this') ||
    queryLower.includes('of this') ||
    queryLower.includes('tell me more') ||
    queryLower.includes('more details') ||
    queryLower.includes('how to reach') ||
    queryLower.includes('where is it') ||
    (queryTokens.length <= 3 && (
      queryTokens.includes('fees') || 
      queryTokens.includes('fee') || 
      queryTokens.includes('placement') || 
      queryTokens.includes('placements') || 
      queryTokens.includes('eligibility') || 
      queryTokens.includes('apply') || 
      queryTokens.includes('admission') ||
      queryTokens.includes('syllabus') || 
      queryTokens.includes('hostel') ||
      queryTokens.includes('location')
    ))
  );

  // If follow-up, merge prior topic tokens into the search tokens
  if (isFollowUpQuery && contextTokens.length > 0) {
    for (const ct of contextTokens) {
      if (!queryTokens.includes(ct)) {
        queryTokens.push(ct);
      }
    }
  }

  const expandedQueryTokens = expandTokensWithSynonyms(queryTokens);
  const normalizedQuery = query.toLowerCase().replace(/[^a-z0-9]/g, '');

  let bestEntry = null;
  let highestScore = -1;
  const scoredEntries = [];

  for (const entry of universityDatabase) {
    let score = 0;
    const normalizedQuestion = entry.question.toLowerCase().replace(/[^a-z0-9]/g, '');

    // 1. Exact match check (avoid substring match for very short queries like "hi" or "ok")
    if (normalizedQuestion === normalizedQuery) {
      score += 120;
    } else if (normalizedQuery.length >= 4 && normalizedQuestion.includes(normalizedQuery)) {
      score += 60;
    }

    const questionTokens = new Set(tokenize(entry.question));
    const keywordTokens = new Set([
      ...entry.keywords.map(k => k.toLowerCase()),
      ...entry.keywords.flatMap(k => tokenize(k))
    ]);

    // 2. Direct question tokens overlap (highest weight)
    let qMatchCount = 0;
    for (const token of queryTokens) {
      if (questionTokens.has(token)) {
        qMatchCount += 8; // Heavy bonus for appearing directly in the title
      } else {
        // Fuzzy token in question
        for (const qt of questionTokens) {
          if (isFuzzyMatch(token, qt)) {
            qMatchCount += 5;
            break;
          }
        }
      }
    }

    // Keyword tokens overlap
    let kwMatchCount = 0;
    for (const token of queryTokens) {
      if (keywordTokens.has(token)) {
        kwMatchCount += 4;
      } else {
        for (const kt of keywordTokens) {
          if (isFuzzyMatch(token, kt)) {
            kwMatchCount += 2.5;
            break;
          }
        }
      }
    }

    // 3. Synonym matching in question and keywords
    let synMatchCount = 0;
    for (const token of expandedQueryTokens) {
      if (!queryTokens.includes(token)) {
        if (questionTokens.has(token)) {
          synMatchCount += 4;
        } else if (keywordTokens.has(token)) {
          synMatchCount += 2;
        }
      }
    }

    score += qMatchCount + kwMatchCount + synMatchCount;

    // 4. Intent-specific matching bonus
    const queryHasFee = queryTokens.some(t => ['fee', 'fees', 'cost', 'tuition'].includes(t));
    const queryHasCourse = queryTokens.some(t => ['course', 'courses', 'program', 'programs', 'branch', 'branches', 'specialization', 'specializations'].includes(t));
    const queryHasPlacement = queryTokens.some(t => ['placement', 'placements', 'package', 'packages', 'salary', 'recruiter', 'recruiters'].includes(t));
    const queryHasHighest = queryTokens.some(t => ['highest', 'top', 'maximum'].includes(t));
    const queryHasEligibility = queryTokens.some(t => ['eligibility', 'eligible', 'criteria', 'marks', 'percentage'].includes(t));

    const qLower = entry.question.toLowerCase();
    if (queryHasFee) {
      if (qLower.includes('fee') || qLower.includes('tuition') || qLower.includes('cost')) {
        score += 25;
      }
      
      const queryLower = query.toLowerCase();
      const queryHasCSE = queryTokens.some(t => ['cse', 'computer', 'computing', 'cs'].includes(t)) || queryLower.includes('cse');
      const queryHasDevOps = queryTokens.some(t => ['devops', 'cicd'].includes(t)) || queryLower.includes('devops') || queryLower.includes('dev ops');
      const queryHasCore = queryTokens.some(t => ['core'].includes(t)) || queryLower.includes('core');
      const queryHasAI = queryTokens.some(t => ['ai', 'aiml', 'machine'].includes(t)) || queryLower.includes('ai & ml') || queryLower.includes('artificial intelligence');
      const queryHasCyber = queryTokens.some(t => ['cyber', 'security', 'hacking'].includes(t)) || queryLower.includes('cyber security');
      const queryHasData = queryTokens.some(t => ['data', 'analytics'].includes(t)) || queryLower.includes('data science');
      const queryHasEveryCore = queryTokens.some(t => ['every', 'each', 'all', 'specialization', 'specializations', 'tracks', 'branches', 'list'].includes(t)) || queryLower.includes('each and every');

      const isGeneralFee = !queryTokens.some(t => [
        'btech', 'engineering', 'cse', 'devops', 'core', 'ai', 'aiml', 'data', 'cyber', 'cloud', 'iot', 'blockchain', 'ise',
        'mba', 'law', 'llb', 'bba', 'bca', 'bcom', 'mtech', 'bdes', 
        'hostel', 'bus', 'transport', 'exam', 'application', 'mode', 'modes', 'neft', 'rtgs', 'online', 'cheque'
      ].includes(t)) && !queryHasCSE && !queryHasDevOps;

      if (isGeneralFee) {
        if (entry.id === 239 || qLower.includes('fee structure across courses')) {
          score += 100;
        } else if (qLower.includes('payment modes') || qLower.includes('refund') || qLower.includes('deadline')) {
          score -= 60;
        }
      }

      // Specific CSE Specializations & Tracks Fee Routing:
      // 1. Specific DevOps track fee:
      if (queryHasDevOps) {
        if (entry.id === 260 || qLower.includes('cse (devops / cloud & devops)')) {
          score += 190;
        } else if (entry.id === 239) {
          score -= 90;
        }
      }
      // 2. Each and every core under CSE / all CSE specializations fee breakdown:
      else if (queryHasCSE && (queryHasEveryCore || (queryHasCore && queryTokens.length <= 4 && !queryHasDevOps && !queryHasAI && !queryHasCyber && !queryHasData))) {
        if (entry.id === 261 || qLower.includes('each and every core track under b.tech cse')) {
          score += 185;
        } else if (entry.id === 239) {
          score -= 90;
        }
      }
      // 3. AI & ML track fee:
      else if (queryHasAI) {
        if (entry.id === 263 || qLower.includes('artificial intelligence & machine learning')) {
          score += 190;
        } else if (entry.id === 239) {
          score -= 90;
        }
      }
      // 4. Cyber Security track fee:
      else if (queryHasCyber) {
        if (entry.id === 264 || qLower.includes('cyber security')) {
          score += 190;
        } else if (entry.id === 239) {
          score -= 90;
        }
      }
      // 5. Data Science track fee:
      else if (queryHasData) {
        if (entry.id === 265 || qLower.includes('data science')) {
          score += 190;
        } else if (entry.id === 239) {
          score -= 90;
        }
      }
      // 6. CSE Core pure fee:
      else if (queryHasCSE && queryHasCore) {
        if (entry.id === 262 || qLower.includes('b.tech cse (core / general)')) {
          score += 180;
        } else if (entry.id === 239) {
          score -= 90;
        }
      }
      // 7. General CSE fee query (e.g. "what is cse fees", "cse fee structure"):
      else if (queryHasCSE) {
        if (entry.id === 261 || qLower.includes('each and every core track under b.tech cse')) {
          score += 160;
        } else if (entry.id === 239) {
          score -= 80;
        }
      }
    }
    if (queryHasCourse && (qLower.includes('course') || qLower.includes('program') || qLower.includes('specialization') || qLower.includes('branches'))) {
      score += 25;
    }
    if (queryHasPlacement && (qLower.includes('placement') || qLower.includes('package') || qLower.includes('salary') || qLower.includes('recruiter'))) {
      score += 25;
    }
    if (queryHasHighest && (qLower.includes('highest') || qLower.includes('top'))) {
      score += 35;
    }

    // Robotics and Mechatronics Guidance Bonus
    const queryHasRobotics = queryTokens.some(t => ['robotics', 'robot', 'robots', 'mechatronics', 'automation'].includes(t));
    if (queryHasRobotics) {
      if (entry.id === 254 || qLower.includes('interested in robotics') || qLower.includes('robotics')) {
        score += 90;
      }
    }

    // Campus Location & Visitor Navigation Intent Bonus
    const queryHasLocation = queryTokens.some(t => [
      'location', 'located', 'where', 'place', 'situated', 'address', 'directions', 
      'direction', 'reach', 'find', 'map', 'maps', 'route', 'guide', 'way', 'spot', 'navigation'
    ].includes(t));
    const queryHasCafeteria = queryTokens.some(t => [
      'cafeteria', 'canteen', 'food', 'court', 'ccd', 'mess', 'dining', 'eat', 'snacks', 'amenities'
    ].includes(t));
    const queryHasLibrary = queryTokens.some(t => ['library', 'koha', 'books', 'reading'].includes(t));
    const queryHasHostel = queryTokens.some(t => ['hostel', 'hostels', 'dorm', 'residence'].includes(t));
    const queryHasATM = queryTokens.some(t => ['atm', 'bank', 'banking', 'cash'].includes(t));
    const queryHasMedical = queryTokens.some(t => ['medical', 'health', 'clinic', 'doctor', 'hospital', 'infirmary'].includes(t));
    const queryHasSports = queryTokens.some(t => ['sports', 'gym', 'gymnasium', 'football', 'cricket', 'basketball', 'ground', 'turf'].includes(t));
    const queryHasAuditorium = queryTokens.some(t => ['auditorium', 'seminar', 'amphitheatre', 'hall'].includes(t));
    const queryHasParking = queryTokens.some(t => ['parking', 'park', 'bus', 'bay'].includes(t));

    // Check if context or query mentions a specific facility
    const contextHasFacility = contextTokens.some(t => [
      'cafeteria', 'canteen', 'food', 'library', 'hostel', 'hostels', 'atm', 
      'medical', 'health', 'clinic', 'sports', 'gym', 'auditorium', 'parking'
    ].includes(t));

    // General campus / university location query bonus (when no specific facility is asked in query or context)
    const queryHasSpecificFacility = queryHasCafeteria || queryHasLibrary || queryHasHostel || queryHasATM || queryHasMedical || queryHasSports || queryHasAuditorium || queryHasParking || contextHasFacility || queryTokens.some(t => ['admission', 'admissions', 'counselling', 'admin', 'registrar', 'office', 'layout', 'navigate', 'robotics'].includes(t));
    if (queryHasLocation && !queryHasSpecificFacility) {
      if (entry.id === 13 || qLower.includes('where is presidency university campus located')) {
        score += 150;
      }
    }

    // Cafeteria and food court location/directions bonus
    if (queryHasCafeteria && (queryHasLocation || queryTokens.length <= 2)) {
      if (entry.id === 240 || qLower.includes('cafeteria or food court located')) {
        score += 160;
      }
    }

    // Follow-up context bonus for cafeteria / location
    if (contextTokens.some(t => ['cafeteria', 'canteen', 'food'].includes(t)) && queryHasLocation) {
      if (entry.id === 240) {
        score += 140;
      }
    }
    if (queryHasLocation && queryHasLibrary) {
      if (entry.id === 241 || qLower.includes('central library located')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryTokens.some(t => ['admission', 'admissions', 'counselling', 'admin', 'registrar', 'office'].includes(t))) {
      if (entry.id === 242 || qLower.includes('admissions office and counselling')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryHasHostel) {
      if (entry.id === 247 || qLower.includes('student hostels located')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryHasATM) {
      if (entry.id === 248 || qLower.includes('atm and banking')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryHasMedical) {
      if (entry.id === 249 || qLower.includes('health care centre and medical')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryHasAuditorium) {
      if (entry.id === 250 || qLower.includes('auditorium and seminar')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryHasSports) {
      if (entry.id === 251 || qLower.includes('sports grounds')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryHasParking) {
      if (entry.id === 252 || qLower.includes('parking')) {
        score += 130;
      }
    }
    if (queryHasLocation && queryTokens.some(t => ['campus', 'layout', 'navigate', 'visitor', 'map'].includes(t))) {
      if (entry.id === 253 || qLower.includes('campus layout')) {
        score += 100;
      }
    }

    const queryHasMTech = queryTokens.includes('mtech');
    const queryHasBTech = queryTokens.includes('btech');
    if (queryHasBTech && !queryHasMTech && qLower.includes('m.tech')) {
      score -= 30;
    }
    if (queryHasMTech && !queryHasBTech && qLower.includes('b.tech') && !qLower.includes('m.tech')) {
      score -= 30;
    }

    // 5. Category matching boost (if category mentioned)
    if (entry.category.toLowerCase().includes(query.toLowerCase()) || 
        query.toLowerCase().includes(entry.category.toLowerCase())) {
      score += 15;
    }

    // 6. Context carry-over boost
    if (contextTokens.length > 0) {
      let contextMatches = 0;
      for (const cToken of contextTokens) {
        if (questionTokens.has(cToken) || keywordTokens.has(cToken)) {
          contextMatches++;
        }
      }
      score += contextMatches * 3;
    }

    // Small length normalization
    const lengthPenalty = Math.max(1, entry.question.split(' ').length / 14);
    const finalScore = score / lengthPenalty;

    if (finalScore > 0) {
      scoredEntries.push({ entry, score: finalScore });
      if (finalScore > highestScore) {
        highestScore = finalScore;
        bestEntry = entry;
      }
    }
  }

  // Sort candidates by score
  scoredEntries.sort((a, b) => b.score - a.score);

  // Confidence calculation (normalized between 0 and 1)
  const confidence = Math.min(1, Math.max(0, highestScore / 25));

  // If score is too low or no matches found, prepare a helpful fallback with official links
  if (!bestEntry || highestScore < 3.2) {
    return {
      status: 'fallback',
      answer: `I could not locate a verified record matching your exact question: **"${query}"**.\n\nPresidency University information is updated regularly. Here are some quick topics you can ask me about:\n• **Admissions & Eligibility**: Ask *"What is the eligibility for B.Tech CSE?"* or *"How to apply online?"*\n• **Course Fee Structures**: Ask *"What is the fee for B.Tech CSE DevOps?"* or *"MBA fee structure"*\n• **Hostels & Transport**: Ask *"Hostel room fees and mess"* or *"Bus transportation routes"*\n• **Placements**: Ask *"What was the highest placement package?"*\n• **Campus Directions**: Ask *"Where is the cafeteria located?"* or *"Library timings"*\n\nFor personal fee quotes or direct admission counseling, you can reach the official Admissions Office at **+91 90220 92222** / **080 4925 5555** or visit **https://presidencyuniversity.in/**.`,
      confidence: Number(confidence.toFixed(2)),
      matchedEntry: scoredEntries[0]?.entry || null,
      category: 'Helpdesk & Support',
      sourceUrl: universityMetadata.officialLinks.mainWebsite,
      sourceTitle: "Presidency University Admissions Helpdesk",
      lastVerifiedDate: universityMetadata.lastVerified,
      relatedQuestions: [
        "What is the eligibility for B.Tech CSE?",
        "What is the fee structure for B.Tech CSE DevOps?",
        "Where is the cafeteria located on campus?",
        "What was the highest placement package?"
      ]
    };
  }

  // Get related questions for suggestion pills
  const relatedQuestions = scoredEntries
    .slice(1, 5)
    .map(item => item.entry.question)
    .filter(q => q !== bestEntry.question);

  if (relatedQuestions.length < 3) {
    const categoryPeers = universityDatabase
      .filter(item => item.category === bestEntry.category && item.id !== bestEntry.id)
      .map(item => item.question)
      .slice(0, 4 - relatedQuestions.length);
    relatedQuestions.push(...categoryPeers);
  }

  // Detect if answer maps to an on-campus location waypoint
  let waypointId = null;
  const entryQ = (bestEntry.question + ' ' + (bestEntry.keywords || []).join(' ')).toLowerCase();
  if (entryQ.includes('cafeteria') || entryQ.includes('canteen') || entryQ.includes('food court') || entryQ.includes('ccd')) {
    waypointId = 'cafeteria';
  } else if (entryQ.includes('library') || entryQ.includes('kalam') || entryQ.includes('reading room')) {
    waypointId = 'central-library';
  } else if (entryQ.includes('admission office') || entryQ.includes('block a') || entryQ.includes('admin block') || entryQ.includes('reception')) {
    waypointId = 'admin-block';
  } else if (entryQ.includes('hostel') || entryQ.includes('dorm') || entryQ.includes('stay')) {
    waypointId = 'hostels';
  } else if (entryQ.includes('robotics') || entryQ.includes('workshop') || entryQ.includes('lab') || entryQ.includes('computing')) {
    waypointId = 'labs-workshop';
  } else if (entryQ.includes('sports') || entryQ.includes('gym') || entryQ.includes('ground') || entryQ.includes('turf')) {
    waypointId = 'sports-arena';
  } else if (entryQ.includes('clinic') || entryQ.includes('hospital') || entryQ.includes('atm') || entryQ.includes('medical')) {
    waypointId = 'health-atm';
  } else if (entryQ.includes('bus') || entryQ.includes('parking') || entryQ.includes('commute')) {
    waypointId = 'bus-parking';
  } else if (entryQ.includes('engineering') || entryQ.includes('block b') || entryQ.includes('block c') || entryQ.includes('classroom')) {
    waypointId = 'engineering-block';
  } else if (entryQ.includes('location') || entryQ.includes('address') || entryQ.includes('reach') || entryQ.includes('rajanakunte')) {
    waypointId = 'main-gate';
  }

  return {
    status: 'success',
    answer: bestEntry.answer,
    confidence: Number(confidence.toFixed(2)),
    matchedEntry: bestEntry,
    category: bestEntry.category,
    sourceUrl: bestEntry.sourceUrl || universityMetadata.officialLinks.mainWebsite,
    sourceTitle: bestEntry.sourceTitle || "Presidency University Official Information",
    lastVerifiedDate: bestEntry.lastVerifiedDate || universityMetadata.lastVerified,
    relatedQuestions: relatedQuestions.slice(0, 4),
    waypointId: waypointId,
    isCampusLocation: Boolean(waypointId)
  };
}

// Popular suggested questions for initial load and chips
export function getPopularSuggestedQuestions() {
  return [
    "What is the eligibility for B.Tech CSE?",
    "What are the fees for engineering programs?",
    "Are scholarships available for 90%+ students?",
    "What hostel facilities and fees are offered?",
    "Does the university provide bus transportation?",
    "What was the highest placement package?",
    "Where is the campus located in Bengaluru?",
    "How can I apply online for admission?"
  ];
}

// Get FAQ items by category
export function getFAQsByCategory(categoryName) {
  if (!categoryName || categoryName === 'All') {
    return universityDatabase;
  }
  return universityDatabase.filter(item => 
    item.category.toLowerCase() === categoryName.toLowerCase()
  );
}

// Search database directly by keyword for Quick Search Modal
export function searchKnowledgeBase(keyword, limit = 8) {
  if (!keyword || !keyword.trim()) return [];
  const tokens = tokenize(keyword);
  
  const results = [];
  for (const entry of universityDatabase) {
    const textToSearch = `${entry.question} ${entry.answer} ${entry.category} ${entry.keywords.join(' ')}`.toLowerCase();
    let matches = 0;
    for (const t of tokens) {
      if (textToSearch.includes(t)) matches++;
    }
    if (matches > 0) {
      results.push({ entry, matchScore: matches });
    }
  }

  return results
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, limit)
    .map(r => r.entry);
}
