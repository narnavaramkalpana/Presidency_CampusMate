@echo off
title College FAQ Chatbot - Local Server
echo ==============================================
echo   Presidency College FAQ Chatbot Local Server
echo ==============================================
echo Starting local development server...
echo.
npm run dev
pause
