import React, { useState } from 'react';
import { 
  Home as HomeIcon, 
  Bus, 
  ShieldCheck, 
  Wifi, 
  Coffee, 
  Sparkles, 
  CheckCircle2, 
  Search, 
  Clock, 
  MapPin, 
  Calendar,
  AlertCircle
} from 'lucide-react';

export default function HostelTransport({ onAskAI }) {
  const [routeSearch, setRouteSearch] = useState('');

  const routes = [
    { id: 1, route: 'Route 1 - Majestic & City Centre', stops: 'KSR Majestic, Anand Rao Circle, Malleshwaram, Yeshwanthpur, Hebbal, Rajanakunte Campus', timing: 'Departure 7:15 AM' },
    { id: 2, route: 'Route 2 - Hebbal & Nagawara', stops: 'Hebbal Flyover, Nagawara Ring Road, Manyata Tech Park, Kogilu Cross, Yelahanka, Campus', timing: 'Departure 7:35 AM' },
    { id: 3, route: 'Route 3 - Whitefield & KR Puram', stops: 'ITPL Whitefield, Hoodi Circle, KR Puram Railway Station, Ramamurthy Nagar, Yelahanka Bypass, Campus', timing: 'Departure 7:00 AM' },
    { id: 4, route: 'Route 4 - Banashankari & Jayanagar', stops: 'Banashankari BDA, South End Circle, Lalbagh West, Corporation, Rajajinagar, Campus', timing: 'Departure 6:50 AM' },
    { id: 5, route: 'Route 5 - Electronic City & Silk Board', stops: 'Electronic City Toll, Silk Board, BTM Layout, Dairy Circle, Shanthinagar, Hebbal, Campus', timing: 'Departure 6:45 AM' },
    { id: 6, route: 'Route 6 - Kengeri & Vijayanagar', stops: 'Kengeri Satellite Town, Nayandahalli, Vijayanagar Club, West of Chord Road, Yeshwanthpur, Campus', timing: 'Departure 7:05 AM' },
    { id: 7, route: 'Route 7 - Indiranagar & Koramangala', stops: 'Sony World Koramangala, Domlur, CMH Road Indiranagar, Ulsoor, Frazer Town, RT Nagar, Campus', timing: 'Departure 7:10 AM' },
    { id: 8, route: 'Route 8 - Yelahanka Local Shuttle', stops: 'Yelahanka New Town Bus Stand, NES Office, Kogilu, Rail Wheel Factory, Rajanakunte, Campus', timing: 'Frequency every 20 mins' }
  ];

  const filteredRoutes = routes.filter(r => 
    r.route.toLowerCase().includes(routeSearch.toLowerCase()) ||
    r.stops.toLowerCase().includes(routeSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner with Real Campus Background */}
      <div className="rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden bg-slate-950 border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/80 via-[#0a1e3b]/65 to-[#091b33]/60 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <HomeIcon className="w-3.5 h-3.5" />
            <span>Comfortable Living & Safe Mobility</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Hostels & University Transportation
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Presidency University provides secure on-campus residences with modern furnishings and dining, alongside an extensive fleet of 50+ luxury buses spanning Bengaluru.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onAskAI("What are the hostel facilities and fees at Presidency University?")}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI About Hostels</span>
            </button>
            <button
              onClick={() => onAskAI("Which areas are covered by university buses?")}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5"
            >
              <span>Ask AI About Bus Routes</span>
            </button>
          </div>
        </div>
      </div>

      {/* Hostel Housing Section */}
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider block">
              Student Housing
            </span>
            <h2 className="text-2xl font-bold text-[#091b33] font-serif">
              Hostel Accommodation & Living
            </h2>
          </div>
          <div className="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
            Annual Fees: ₹1,40,000 – ₹1,75,000 + ₹10,000 Refundable Deposit
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <HomeIcon className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Room Configurations</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Separate hostels for boys and girls offering Twin-Sharing and Triple-Sharing rooms with choices of Air-Conditioned (AC) and standard Non-AC options.
            </p>
            <ul className="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
              <li>• Ergonomic study tables and chairs</li>
              <li>• Modular personal storage wardrobes</li>
              <li>• Spring/foam comfortable mattresses</li>
            </ul>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Coffee className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Multi-Cuisine Dining Hall</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Wholesome, nutritious dining serving North Indian and South Indian vegetarian and non-vegetarian selections planned in consultation with the student food committee.
            </p>
            <ul className="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
              <li>• Four meals daily: Breakfast, Lunch, Snacks, Dinner</li>
              <li>• RO purified continuous drinking water</li>
              <li>• Special festive holiday feasts</li>
            </ul>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Safety & Amenities</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Biometric access control, full boundary CCTV surveillance, resident wardens, and 24/7 security personnel ensure complete peace of mind.
            </p>
            <ul className="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
              <li>• Curfew: 7:30 PM evening gate closure</li>
              <li>• Digital parent-permission app for outings</li>
              <li>• High-speed Wi-Fi and power backup</li>
              <li>• Weekend shopping shuttle to Yelahanka New Town</li>
            </ul>
          </div>
        </div>
      </div>

      {/* University Transportation Section */}
      <div className="space-y-6 pt-6 border-t border-slate-200">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider block">
              Daily Commute
            </span>
            <h2 className="text-2xl font-bold text-[#091b33] font-serif">
              50+ Luxury Bus Commuter Fleet
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Connecting students and faculty from all corners of Bengaluru directly to the campus gate.
            </p>
          </div>

          {/* Route Search */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={routeSearch}
              onChange={(e) => setRouteSearch(e.target.value)}
              placeholder="Search route by area (Hebbal, Majestic...)"
              className="w-full pl-10 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Bus Safety Features */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
          <div className="flex items-center gap-2 text-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>GPS Real-time Live Tracking</span>
          </div>
          <div className="flex items-center gap-2 text-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>Speed Governors & CCTV</span>
          </div>
          <div className="flex items-center gap-2 text-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>Vetted Experienced Drivers</span>
          </div>
          <div className="flex items-center gap-2 text-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>First Aid & Emergency Support</span>
          </div>
        </div>

        {/* Routes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredRoutes.map((rt) => (
            <div
              key={rt.id}
              className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-blue-300 shadow-xs transition space-y-2.5"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-[#091b33] flex items-center gap-1.5">
                  <Bus className="w-4 h-4 text-blue-600" />
                  <span>{rt.route}</span>
                </span>
                <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{rt.timing}</span>
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                <strong className="text-slate-800">Key Stops:</strong> {rt.stops}
              </p>
            </div>
          ))}
        </div>

        {filteredRoutes.length === 0 && (
          <div className="text-center py-8 text-xs text-slate-400">
            No route matching "{routeSearch}". Ask CampusMate AI for exact stop pickup locations!
          </div>
        )}
      </div>
    </div>
  );
}
