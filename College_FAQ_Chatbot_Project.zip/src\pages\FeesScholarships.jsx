import React, { useState } from 'react';
import { 
  DollarSign, 
  Award, 
  Calculator, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  ExternalLink,
  ShieldCheck,
  Building,
  Percent
} from 'lucide-react';

export default function FeesScholarships({ onAskAI, setActivePage }) {
  // Calculator state
  const [calcCourse, setCalcCourse] = useState('btech-cse');
  const [calcPercentage, setCalcPercentage] = useState(88);
  const [calcCategory, setCalcCategory] = useState('general');

  const baseFees = {
    'btech-cse': { name: 'B.Tech Computer Science & Engg', annual: 320000 },
    'btech-other': { name: 'B.Tech Core (ECE / Mech / Civil)', annual: 260000 },
    'mba': { name: 'MBA (Annual Component of 2-Yr)', annual: 375000 },
    'law': { name: '5-Year Integrated Law (BA/BBA LLB)', annual: 185000 },
    'bba': { name: 'BBA / BCA Programs', annual: 160000 },
    'allied': { name: 'B.Sc. Allied Health Sciences', annual: 140000 }
  };

  // Calculate scholarship estimate
  const currentCourse = baseFees[calcCourse];
  let scholarshipAmount = 0;
  let scholarshipReason = 'No automatic board concession';

  if (calcPercentage >= 90) {
    scholarshipAmount = 50000;
    scholarshipReason = 'Merit Concession (90%+ in 10+2 / PUC)';
  } else if (calcPercentage >= 80) {
    scholarshipAmount = 30000;
    scholarshipReason = 'Merit Concession (80% - 89.9% in 10+2 / PUC)';
  }

  if (calcCategory === 'sports') {
    scholarshipAmount = Math.max(scholarshipAmount, currentCourse.annual * 0.35);
    scholarshipReason = 'Estimated Sports Excellence Concession (~35%)';
  } else if (calcCategory === 'sibling') {
    scholarshipAmount = Math.max(scholarshipAmount, currentCourse.annual * 0.15);
    scholarshipReason = 'Sibling / Presidency Alumni Concession (15%)';
  }

  const netAnnualFee = Math.max(0, currentCourse.annual - scholarshipAmount);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-8 sm:p-12 text-white shadow-xl overflow-hidden border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/88 via-[#0d2346]/80 to-[#163e72]/75 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <Award className="w-3.5 h-3.5" />
            <span>Merit Awards & Transparent Tuition</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Fees Structure & Scholarships
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Presidency University believes in rewarding merit and expanding access to quality higher education through competitive fee concessions and transparent academic policies.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onAskAI("What are the fees for B.Tech CSE?")}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI About Course Fees</span>
            </button>
            <button
              onClick={() => onAskAI("What scholarships are available at Presidency University?")}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>Ask AI About Scholarships</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Scholarship & Fee Calculator */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-lg space-y-8">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Calculator className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#091b33] font-serif">
              Interactive Scholarship & Tuition Fee Estimator
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Estimate your annual tuition and potential merit waivers based on your academic percentage.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Controls */}
          <div className="lg:col-span-2 space-y-5 bg-slate-50 p-6 rounded-2xl border border-slate-200">
            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1.5">
                Select Academic Program:
              </label>
              <select
                value={calcCourse}
                onChange={(e) => setCalcCourse(e.target.value)}
                className="w-full text-xs sm:text-sm px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none"
              >
                <option value="btech-cse">B.Tech Computer Science & Engg / AI & ML</option>
                <option value="btech-other">B.Tech Electronics / Mechanical / Civil / Mechatronics</option>
                <option value="mba">MBA (Master of Business Administration)</option>
                <option value="law">School of Law (B.A. / B.B.A. LL.B. 5-Yr Hons)</option>
                <option value="bba">BBA / BCA Computer Applications</option>
                <option value="allied">B.Sc. Allied Health Sciences</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-800 mb-1.5">
                <span>Qualifying Examination Percentage (10+2 / PUC / Degree):</span>
                <span className="text-blue-600 font-mono text-sm">{calcPercentage}%</span>
              </div>
              <input
                type="range"
                min="45"
                max="100"
                step="0.5"
                value={calcPercentage}
                onChange={(e) => setCalcPercentage(parseFloat(e.target.value))}
                className="w-full accent-blue-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>45% Minimum</span>
                <span>80% (₹30k concession)</span>
                <span>90% (₹50k concession)</span>
                <span>100%</span>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1.5">
                Special Category (If Applicable):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  { id: 'general', label: 'Standard Merit' },
                  { id: 'sports', label: 'Sports State/National' },
                  { id: 'sibling', label: 'Sibling / PGI Alumni' }
                ].map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCalcCategory(cat.id)}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                      calcCategory === cat.id
                        ? 'bg-[#091b33] text-white border-[#091b33]'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Result Card */}
          <div className="bg-gradient-to-br from-[#091b33] to-[#163e72] rounded-2xl p-6 text-white flex flex-col justify-between shadow-md">
            <div>
              <span className="text-[10px] font-bold text-blue-300 uppercase tracking-wider block mb-1">
                Estimate Summary
              </span>
              <h3 className="text-sm font-bold text-white mb-4">
                {currentCourse.name}
              </h3>

              <div className="space-y-3 text-xs border-t border-white/10 pt-3">
                <div className="flex justify-between text-slate-300">
                  <span>Standard Annual Tuition:</span>
                  <span className="font-mono text-white">₹{currentCourse.annual.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-emerald-400 font-semibold">
                  <span>Estimated Concession:</span>
                  <span className="font-mono">- ₹{Math.round(scholarshipAmount).toLocaleString('en-IN')}</span>
                </div>
                <div className="text-[11px] text-slate-400 bg-white/5 p-2 rounded-lg">
                  {scholarshipReason}
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-white/10 mt-4">
              <span className="text-[11px] text-slate-300 block">Net Estimated Annual Tuition:</span>
              <div className="text-2xl font-black text-white font-mono mt-0.5">
                ₹{Math.round(netAnnualFee).toLocaleString('en-IN')}
                <span className="text-xs font-normal text-slate-300"> / year</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">
                *Subject to official marks verification and committee confirmation.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Official Slabs and Scholarship Policies */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            100%
          </div>
          <h3 className="text-base font-bold text-slate-900">Presidential Scholarship</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Awarded to extraordinary toppers in national/state competitive examinations or board ranks, providing up to a 100% complete waiver on tuition fees.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            ₹50K
          </div>
          <h3 className="text-base font-bold text-slate-900">Merit Concession (90%+)</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Students securing 90% and above in 10+2 / PUC receive a flat tuition waiver of ₹50,000 for their first academic year.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            ₹30K
          </div>
          <h3 className="text-base font-bold text-slate-900">Merit Concession (80-89.9%)</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Students scoring between 80% and 89.99% receive a standard tuition fee concession of ₹30,000 for their first academic year.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#163e72] flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Sports & Cultural Achievers</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            State, national, and international medalists in disciplines like Cricket, Football, Basketball, Athletics, and Arts receive 25% to 75% fee waivers.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#163e72] flex items-center justify-center">
            <Percent className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Siblings & Alumni Discount</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            A 10% to 20% discount is available for siblings of current students and alumni transitioning from Presidency Group schools and PU colleges.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#163e72] flex items-center justify-center">
            <Building className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Education Loan Tie-ups</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            The university has tie-ups with leading banks (SBI, Canara, HDFC, ICICI, Axis, Credila) to provide bonafide estimates and expedited student loan processing.
          </p>
        </div>
      </div>
    </div>
  );
}
