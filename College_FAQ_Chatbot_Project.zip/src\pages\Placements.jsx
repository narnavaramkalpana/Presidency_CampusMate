import React from 'react';
import { 
  Briefcase, 
  TrendingUp, 
  Award, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  ExternalLink,
  Building,
  Target
} from 'lucide-react';

export default function Placements({ onAskAI, setActivePage }) {
  const topRecruiters = [
    { name: 'Microsoft', sector: 'Product & Cloud', tag: 'Big Tech' },
    { name: 'Amazon', sector: 'E-Commerce & AWS', tag: 'Product Giant' },
    { name: 'Capgemini', sector: 'Consulting & IT Services', tag: 'Mass Recruiter' },
    { name: 'Infosys', sector: 'IT Services & Digital', tag: 'Global Tech' },
    { name: 'Wipro', sector: 'Technology & Cloud', tag: 'Top Recruiter' },
    { name: 'Tata Consultancy Services (TCS)', sector: 'IT Services', tag: 'Global MNC' },
    { name: 'Dell Technologies', sector: 'Enterprise Systems', tag: 'Hardware & Cloud' },
    { name: 'EY (Ernst & Young)', sector: 'Global Advisory & Audit', tag: 'Big 4' },
    { name: 'KPMG', sector: 'Tax & Advisory', tag: 'Big 4' },
    { name: 'Deloitte', sector: 'Risk & Analytics', tag: 'Big 4' },
    { name: 'ICICI Bank', sector: 'Banking & Financial', tag: 'BFSI Leader' },
    { name: 'Berger Paints', sector: 'FMCG & Paints', tag: 'Core Management' },
    { name: 'Cognizant', sector: 'Software & Digital', tag: 'Tech Giant' },
    { name: 'Tech Mahindra', sector: 'Telecom & Software', tag: 'Enterprise IT' },
    { name: 'Bosch', sector: 'Automotive & IoT', tag: 'Core Engineering' },
    { name: 'Larsen & Toubro (L&T)', sector: 'Infrastructure & Engineering', tag: 'Core Heavy' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-8 sm:p-12 text-white shadow-xl overflow-hidden border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/88 via-[#0d2346]/80 to-[#163e72]/75 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Career Resource Centre (CRC)</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Placements & Career Opportunities
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Presidency University bridges academic learning with corporate leadership through robust industry connections, continuous skill enrichment, and high-impact placement drives.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onAskAI("What was the highest placement package at Presidency University?")}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI About Highest CTC</span>
            </button>
            <button
              onClick={() => onAskAI("Who are the top recruiters visiting Presidency University?")}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5"
            >
              <span>Ask AI About Recruiters</span>
            </button>
          </div>
        </div>
      </div>

      {/* Placement Statistics Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs text-center">
          <div className="text-2xl sm:text-3xl font-black text-[#091b33] font-serif">
            ₹13.58+ LPA
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Highest CTC Offered</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Top Tech & Product Firms</div>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs text-center">
          <div className="text-2xl sm:text-3xl font-black text-[#091b33] font-serif">
            ₹5.5 - 6.0 LPA
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Average Engineering CTC</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Consistent across cohorts</div>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs text-center">
          <div className="text-2xl sm:text-3xl font-black text-[#091b33] font-serif">
            500+
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Visiting Recruiters</div>
          <div className="text-[11px] text-slate-400 mt-0.5">MNCs, Startups & Big 4</div>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs text-center">
          <div className="text-2xl sm:text-3xl font-black text-[#091b33] font-serif">
            90%+
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Placement Success Rate</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Eligible registered students</div>
        </div>
      </div>

      {/* Top Recruiters Showcase */}
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-[#091b33] font-serif">
            Prominent Recruiting Partners
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Industry giants actively recruiting from Engineering, Management, Law, and Sciences streams.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {topRecruiters.map((rec, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-4 border border-slate-200 hover:border-blue-300 shadow-xs transition flex flex-col justify-between"
            >
              <div>
                <span className="text-[9px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 uppercase tracking-wider inline-block mb-1.5">
                  {rec.tag}
                </span>
                <h4 className="text-sm font-bold text-slate-900">{rec.name}</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">{rec.sector}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pre-Placement Training Structure */}
      <div className="bg-slate-50 rounded-3xl p-6 sm:p-10 border border-slate-200 space-y-6">
        <div>
          <span className="text-xs font-bold text-blue-600 uppercase tracking-wider block">
            Career Enhancement
          </span>
          <h3 className="text-xl sm:text-2xl font-bold text-[#091b33] font-serif">
            Pre-Placement Training & Upskilling
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Commencing from the second year, the Career Resource Centre equips every student with essential technical and behavioural competencies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-xs font-bold text-slate-900 mb-2">Aptitude & Analytics</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Intensive training in quantitative mathematics, logical reasoning, data interpretation, and speed arithmetic for clearing competitive corporate screening tests.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-xs font-bold text-slate-900 mb-2">Full-Stack Coding Bootcamps</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Data Structures, Algorithms (DSA), LeetCode problem solving, full-stack web architectures, and system design challenges.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-xs font-bold text-slate-900 mb-2">Soft Skills & Communication</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Business communication, public speaking, executive presence, resume architecture, and professional email etiquette.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-xs font-bold text-slate-900 mb-2">Mock GDs & Technical PIs</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Simulation rounds conducted by corporate HR veterans and senior alumni simulating real-world job interview conditions.
            </p>
          </div>
        </div>
      </div>

      {/* Corporate Connect Callout */}
      <div className="bg-[#091b33] text-white rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-white">Are You a Corporate Recruiter?</h4>
          <p className="text-xs text-slate-300 mt-0.5">
            Connect with the Presidency University Career Resource Centre to schedule on-campus or virtual recruitment drives.
          </p>
        </div>
        <a
          href="mailto:placements@presidencyuniversity.in"
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition shadow-md whitespace-nowrap"
        >
          placements@presidencyuniversity.in
        </a>
      </div>
    </div>
  );
}
