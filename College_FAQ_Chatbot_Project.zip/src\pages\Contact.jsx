import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ExternalLink, 
  Sparkles, 
  CheckCircle2, 
  Plane, 
  Train, 
  Bus, 
  Navigation,
  Send
} from 'lucide-react';
import { universityMetadata } from '../data/universityDatabase';

export default function Contact({ onAskAI }) {
  const [visitDate, setVisitDate] = useState('');
  const [visitorName, setVisitorName] = useState('');
  const [visitorPhone, setVisitorPhone] = useState('');
  const [visitorEmail, setVisitorEmail] = useState('');
  const [booked, setBooked] = useState(false);

  const handleVisitSubmit = (e) => {
    e.preventDefault();
    if (visitorName && visitorPhone && visitDate) {
      setBooked(true);
      setTimeout(() => setBooked(false), 5000);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-8 sm:p-12 text-white shadow-xl overflow-hidden border border-slate-800">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url('/assets/presidency-campus-main.jpg')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#091b33]/88 via-[#0d2346]/80 to-[#163e72]/75 backdrop-blur-[1px]" />
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <MapPin className="w-3.5 h-3.5" />
            <span>Campus Visit & Official Contact Directory</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif">
            Contact & Campus Location
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            We invite prospective students, parents, and recruiters to experience our 65+ acre lush green campus in Rajanakunte, Yelahanka or visit our City Admissions Office in Richmond Town, Bengaluru.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onAskAI("Where is Presidency University located in Bengaluru?")}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI Campus Directions</span>
            </button>
            <a
              href="https://www.google.com/maps/search/?api=1&query=Presidency+University+Bengaluru"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Open in Google Maps</span>
              <ExternalLink className="w-3 h-3 text-blue-400" />
            </a>
          </div>
        </div>
      </div>

      {/* Campus & City Office Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Main Campus */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
                Main Academic Campus
              </span>
              <h3 className="text-lg font-bold text-slate-900">
                Presidency University Bengaluru
              </h3>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064, Karnataka, India (Off Doddaballapur Main Road, 12 km from Yelahanka New Town).
          </p>

          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs text-slate-700">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-blue-600" />
              <span>Admissions Helpline: <strong>+91 90220 92222 / 080 4925 5555</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-blue-600" />
              <span>Admissions: admission@presidencyuniversity.in</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <span>Monday – Saturday: 9:00 AM – 5:00 PM (IST)</span>
            </div>
          </div>
        </div>

        {/* City Office */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#163e72] flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
                Central City Admissions Centre
              </span>
              <h3 className="text-lg font-bold text-slate-900">
                City Office – Richmond Town
              </h3>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            University House, 8/1, King Street, Richmond Town, Bengaluru – 560025, Karnataka, India (Convenient for central Bangalore walk-ins).
          </p>

          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs text-slate-700">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#163e72]" />
              <span>City Office Desk: +91 80 4925 5555</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#163e72]" />
              <span>Inquiries: info@presidencyuniversity.in</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#163e72]" />
              <span>Monday – Saturday: 9:30 AM – 5:00 PM</span>
            </div>
          </div>
        </div>
      </div>

      {/* Transit & Distances Guide */}
      <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200 space-y-6">
        <div>
          <h3 className="text-xl font-bold text-[#091b33] font-serif">
            How to Reach Presidency University Campus
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Key distances and public transport connections to the Rajanakunte campus.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-xs">
              <Plane className="w-4 h-4 text-blue-600" />
              <span>From Kempegowda Airport (BLR)</span>
            </div>
            <div className="text-2xl font-black text-[#091b33] font-serif">~28 km</div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Approximately 35–45 minutes by taxi or airport bus via State Highway 9 / Doddaballapur bypass road.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-xs">
              <Train className="w-4 h-4 text-blue-600" />
              <span>From Majestic (KSR Railway Station)</span>
            </div>
            <div className="text-2xl font-black text-[#091b33] font-serif">~30 km</div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Direct BMTC buses ply regularly toward Rajanakunte. The university also operates daily commuter bus Route 1 from Majestic.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-xs">
              <Bus className="w-4 h-4 text-blue-600" />
              <span>From Yelahanka New Town</span>
            </div>
            <div className="text-2xl font-black text-[#091b33] font-serif">~12 km</div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Frequent BMTC bus routes (285 series) and free university shuttle connections between Rajanakunte bus stop and the main gate.
            </p>
          </div>
        </div>
      </div>

      {/* Book a Campus Tour Visit Form */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-md">
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="text-center space-y-1">
            <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded uppercase tracking-wider">
              Experience Presidency
            </span>
            <h3 className="text-2xl font-bold text-[#091b33] font-serif">
              Book an In-Person Campus Guided Tour
            </h3>
            <p className="text-xs text-slate-500">
              Walk through our academic blocks, AI research labs, sports facilities, and student dining halls with an admissions guide.
            </p>
          </div>

          {booked ? (
            <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-center space-y-1">
              <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-600 mb-2" />
              <div className="font-bold text-sm">Campus Visit Slot Reserved!</div>
              <p className="text-xs">
                We look forward to welcoming you, {visitorName}. Our admissions officer will confirm directions and pass details on {visitorPhone}.
              </p>
            </div>
          ) : (
            <form onSubmit={handleVisitSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    value={visitorName}
                    onChange={(e) => setVisitorName(e.target.value)}
                    placeholder="Full Name"
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    required
                    value={visitorPhone}
                    onChange={(e) => setVisitorPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Email Address</label>
                  <input
                    type="email"
                    value={visitorEmail}
                    onChange={(e) => setVisitorEmail(e.target.value)}
                    placeholder="student@example.com"
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Preferred Visit Date</label>
                  <input
                    type="date"
                    required
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#091b33] hover:bg-[#163e72] text-blue-400 font-bold text-xs sm:text-sm rounded-xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Confirm Campus Tour Reservation</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
