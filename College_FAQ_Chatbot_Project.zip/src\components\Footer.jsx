import React from 'react';
import PresidencyLogo from './PresidencyLogo';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ExternalLink, 
  Shield, 
  Award, 
  Globe, 
  Sparkles, 
  BookOpen, 
  HeartHandshake, 
  ArrowUpRight 
} from 'lucide-react';
import { universityMetadata } from '../data/universityDatabase';

export default function Footer({ setActivePage, onOpenAIChat, onOpenMap }) {
  const currentYear = 2026;

  const navigateTo = (pageId) => {
    setActivePage(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#091b33] text-slate-300 pt-16 pb-8 border-t-4 border-blue-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          {/* Column 1: Brand & Overview */}
          <div className="lg:col-span-2 space-y-4">
            <PresidencyLogo light={true} />
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm mt-3">
              Presidency University Bengaluru is a premier research-oriented private university established under the Presidency University Act, 2013 (Karnataka Act No. 41 of 2013). Part of the 48-year legacy of Presidency Group of Institutions (founded 1976).
            </p>

            <div className="flex flex-wrap gap-2 pt-2">
              <span className="text-[10px] bg-slate-800 text-blue-300 px-2.5 py-1 rounded border border-slate-700 font-semibold">
                UGC Approved §2(f)
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2.5 py-1 rounded border border-slate-700 font-semibold">
                AICTE Approved
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2.5 py-1 rounded border border-slate-700 font-semibold">
                BCI Approved (Law)
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2.5 py-1 rounded border border-slate-700 font-semibold">
                AIU Member
              </span>
            </div>

            {/* AI Assistant Banner */}
            <div className="bg-gradient-to-r from-slate-800/90 to-blue-950/40 p-3.5 rounded-xl border border-blue-500/30 flex items-center justify-between gap-3 max-w-md">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">College FAQ Chatbot</div>
                  <div className="text-[10px] text-slate-400">265 verified college FAQs with retrieval & safe fallback</div>
                </div>
              </div>
              <button
                onClick={onOpenAIChat}
                className="px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition whitespace-nowrap cursor-pointer shadow-sm"
              >
                Ask Now
              </button>
            </div>
          </div>

          {/* Column 2: Academic Schools */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-4 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Academic Schools</span>
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Engineering (SOE)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Management (SOM)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Law (SOL)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Design (SOD)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Computer Science
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Commerce (SOC)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Allied Health Sciences
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Media Studies
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-blue-300 transition text-left cursor-pointer">
                  School of Basic Sciences
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Quick Navigation */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-4 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" />
              <span>Explore Campus</span>
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('about')} className="hover:text-blue-300 transition cursor-pointer">
                  About the University
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('admissions')} className="hover:text-blue-300 transition cursor-pointer">
                  Admission Process 2026-27
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('fees')} className="hover:text-blue-300 transition cursor-pointer">
                  Fee Structure & Calculator
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('fees')} className="hover:text-blue-300 transition cursor-pointer">
                  Scholarships & Concessions
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('facilities')} className="hover:text-blue-300 transition cursor-pointer">
                  Campus & Research Labs
                </button>
              </li>
              {onOpenMap && (
                <li>
                  <button onClick={() => onOpenMap()} className="text-blue-400 hover:text-white transition cursor-pointer flex items-center gap-1 font-semibold">
                    <span>Interactive Campus Map</span>
                    <span className="text-[9px] bg-blue-600 text-white px-1.5 py-0.2 rounded font-mono">MAP</span>
                  </button>
                </li>
              )}
              <li>
                <button onClick={() => navigateTo('hostel')} className="hover:text-blue-300 transition cursor-pointer">
                  Student Hostels & Dining
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('hostel')} className="hover:text-blue-300 transition cursor-pointer">
                  Bus Routes & Transport
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('placements')} className="hover:text-blue-300 transition cursor-pointer">
                  Career Services & Recruiters
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('campus-life')} className="hover:text-blue-300 transition cursor-pointer">
                  Invincia Fest & Student Clubs
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('events')} className="hover:text-blue-300 transition cursor-pointer">
                  Announcements & Notices
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Official Contacts & Locations */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-4 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              <span>Contact & Locations</span>
            </h4>
            <div className="space-y-3 text-xs text-slate-300">
              <div>
                <strong className="text-white block font-semibold">Main Campus:</strong>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Presidency University, Itgalpur, Rajanakunte, Yelahanka, Bengaluru – 560064, Karnataka, India
                </p>
              </div>

              <div>
                <strong className="text-white block font-semibold">City Admissions Office:</strong>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  University House, 8/1, King Street, Richmond Town, Bengaluru – 560025
                </p>
              </div>

              <div className="pt-1 space-y-1">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Phone className="w-3 h-3 text-blue-400 flex-shrink-0" />
                  <span className="font-mono text-[11px]">+91 90220 92222 / 080 4925 5555</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Mail className="w-3 h-3 text-blue-400 flex-shrink-0" />
                  <span className="font-mono text-[11px]">admission@presidencyuniversity.in</span>
                </div>
              </div>

              {/* Official External Links */}
              <div className="pt-2 border-t border-slate-800 space-y-1">
                <a 
                  href="https://presidencyuniversity.in/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center justify-between text-[11px] text-blue-300 hover:text-blue-200 transition font-medium"
                >
                  <span>Main University Website</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
                <a 
                  href="https://share.google/aed5CNFY68y6VE8UV" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center justify-between text-[11px] text-slate-400 hover:text-slate-300 transition"
                >
                  <span>Google Reference Record</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="text-center md:text-left">
            <p>© {currentYear} Presidency University, Bengaluru. All rights reserved.</p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Statutory State Private University under Karnataka Act No. 41 of 2013 • Building a FAQ Chatbot for a College Website.
            </p>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <button onClick={() => navigateTo('events')} className="hover:text-slate-200 transition cursor-pointer">
              Anti-Ragging Policy
            </button>
            <span>•</span>
            <button onClick={() => navigateTo('fees')} className="hover:text-slate-200 transition cursor-pointer">
              UGC Refund Rules
            </button>
            <span>•</span>
            <button onClick={() => navigateTo('contact')} className="hover:text-slate-200 transition cursor-pointer">
              Campus Visit Booking
            </button>
            <span>•</span>
            <span className="text-slate-400 font-mono">
              Last Verified: {universityMetadata.lastVerified}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
